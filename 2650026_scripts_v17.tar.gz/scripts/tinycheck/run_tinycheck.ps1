# run_tinycheck.ps1 -- compile tinycheck.cpp and run the six checks. PowerShell, Windows. No timing is measured; the
# result does not depend on the machine, only the run time does (about 6 to 15 minutes in total).
# Usage:  cd to the folder holding tinycheck.cpp and this file, then   .\run_tinycheck.ps1
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
$exe = Join-Path $here "tinycheck.exe"
if (Get-Command g++ -ErrorAction SilentlyContinue) {
    & g++ -O2 -std=c++17 -o tinycheck.exe tinycheck.cpp
} elseif (Get-Command clang++ -ErrorAction SilentlyContinue) {
    & clang++ -O2 -std=c++17 -o tinycheck.exe tinycheck.cpp
} elseif (Get-Command cl -ErrorAction SilentlyContinue) {
    & cl /nologo /O2 /EHsc /std:c++17 /Fe:tinycheck.exe tinycheck.cpp
} else {
    Write-Host "No C++ compiler found (g++, clang++ or cl). Install one, e.g.:  winget install -e --id BrechtSanders.WinLibs.POSIX.UCRT   then open a NEW PowerShell window and run this again." -ForegroundColor Red
    exit 1
}
if (-not (Test-Path $exe)) { Write-Host "Compilation failed." -ForegroundColor Red; exit 1 }
$out = Join-Path $here "tinycheck_results.txt"
"tinycheck v1  $(Get-Date -Format s)  $env:COMPUTERNAME" | Set-Content $out
$runs = @(
    @("-d","2","-m","2","-s","1","-K","2","-D","2","-u","6"),
    @("-d","2","-m","3","-s","1","-K","2","-D","1","-u","7"),
    @("-d","3","-m","2","-s","1","-K","1","-D","2","-u","7"),
    @("-d","3","-m","2","-s","1","-K","2","-D","1","-u","7"),
    @("-d","3","-m","2","-s","2","-K","1","-D","1","-u","8"),
    @("-d","2","-m","2","-s","1","-K","2","-D","2","-u","6","--mutant","retry-original")
)
foreach ($r in $runs) {
    Write-Host ("=== " + ($r -join " ")) -ForegroundColor Cyan
    ("`n### " + ($r -join " ")) | Add-Content $out
    & $exe @r | Tee-Object -FilePath $out -Append
    "exit code $LASTEXITCODE" | Add-Content $out
}
Write-Host "`nDone. Please send tinycheck_results.txt back." -ForegroundColor Green
