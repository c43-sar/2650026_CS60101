// tinycheck.cpp v1 -- exhaustive model check of the proposed d-ary bounded-displacement cuckoo table with stash.
//
// A line-by-line mirror of BoundedCuckoo::insertInner / incrementalRehashStash / lookup in bench.cpp (v5.6), run on
// a TINY table (a few cells) so that EVERY possibility can be enumerated:
//   * every assignment of hash positions to the u keys (up to renaming the keys),
//   * every order in which the keys are inserted (breadth-first over the reachable configurations; each
//     configuration is expanded once),
//   * every outcome of the random eviction choice (bench.cpp draws rng()%d; here every value 0..d-1 is tried).
// No timing, no random numbers, no files: it checks correctness only, so the answer is the same on any machine.
//
// Checked after every insertion, on every branch:
//   P1 key conservation (paper Lemma conserve): the keys held in cells + stash + fallback are exactly the keys
//      inserted so far, each once, and the counter n equals their number;
//   P2 lookup finds every held key; a key in the cells or stash is found within d+s slot reads (paper Theorem
//      worst_case_latency (i)); a key in the fallback after d+s+|fallback| reads;
//   P3 RehashStash cannot overflow (paper Lemma nested): no insertion issued from inside RehashStash reaches the
//      overflow branch;
//   P4 round bound (paper Corollary rounds): one top-level insertion that does not trip the depth guard performs
//      at most K(1+D(s+1)) rounds;
//   P5 inserting a key that is already held changes nothing and costs no round.
// It also prints reach counts, so that "no violation" is not read as "the interesting cases never happened".
//
// --mutant retry-original re-runs the check with the RETIRED defect (the retry re-inserts the original key x instead
// of the carried key cur). The checker must then report violations (exit code 0 means it did); if it reports none, the
// checker itself is broken.
//
// Build (any C++11 compiler):
//   g++ -O2 -std=c++17 -o tinycheck tinycheck.cpp          (MinGW-w64 / MSYS2 / Linux)
//   cl /O2 /EHsc /std:c++17 tinycheck.cpp                   (Visual Studio "x64 Native Tools" prompt)
// Run:  ./tinycheck -d 2 -m 2 -s 1 -K 2 -D 2 -u 6
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <set>
#include <string>
#include <vector>
using namespace std;

struct Cfg { int d = 2, m = 2, s = 1, K = 2, D = 2, u = 6; bool mutant = false; };

// A configuration: d*m cells, s stash slots, then the fallback list; -1 = empty. Stored as a string of int8.
typedef string Conf;

struct Run {
    // outputs
    long rounds = 0, ovf = 0, ovfInRehash = 0, stashed = 0; int maxDepth = 0; bool tripped = false; long n = 0;
    int pos = 0;                       // choice points consumed
};

struct Mc {
    Cfg c;
    vector<vector<int>> h;             // h[key][i] = position of key in sub-table i
    // per-run mutable state
    vector<int8_t> T;                  // d*m cells
    vector<int8_t> stash;
    vector<int8_t> spill;
    Run st;
    vector<int>* pick = nullptr;       // replayed eviction picks
    vector<int>* arity = nullptr;

    int choice() {
        int i = st.pos++;
        if (i < (int)pick->size()) return (*pick)[i];
        pick->push_back(0); arity->push_back(c.d);
        return 0;
    }
    int lookup(int k) const {
        for (int i = 0; i < c.d; i++) if (T[i * c.m + h[k][i]] == k) return i + 1;
        for (int j = 0; j < c.s; j++) if (stash[j] == k) return c.d + 1;
        for (size_t j = 0; j < spill.size(); j++) if (spill[j] == k) return c.d + 2;
        return -1;
    }
    void insertInner(int key, int depth, bool inRehash) {
        if (lookup(key) > 0) return;
        if (depth > st.maxDepth) st.maxDepth = depth;
        int cur = key;
        for (int r = 0; r < c.K; r++) {
            st.rounds++;
            for (int i = 0; i < c.d; i++) {
                int p = i * c.m + h[cur][i];
                if (T[p] < 0) { T[p] = (int8_t)cur; st.n++; return; }
            }
            int i = choice();
            int p = i * c.m + h[cur][i];
            int ev = T[p]; T[p] = (int8_t)cur; cur = ev;
        }
        for (int j = 0; j < c.s; j++)
            if (stash[j] < 0) { stash[j] = (int8_t)cur; st.n++; st.stashed++; return; }
        st.ovf++;
        if (inRehash) st.ovfInRehash++;
        if (depth >= c.D) { st.tripped = true; spill.push_back((int8_t)cur); st.n++; return; }
        // RehashStash: empty the stash, reinsert its keys, then retry the carried key
        vector<int> S;
        for (int j = 0; j < c.s; j++) if (stash[j] >= 0) S.push_back(stash[j]);
        for (int j = 0; j < c.s; j++) stash[j] = -1;
        st.n -= (long)S.size();
        for (size_t q = 0; q < S.size(); q++) insertInner(S[q], depth + 1, true);
        insertInner(c.mutant ? key : cur, depth + 1, inRehash);
    }
    // run one insertion from configuration `start`; returns the resulting configuration
    Conf runOne(const Conf& start, int key, vector<int>& pk, vector<int>& ar) {
        int cells = c.d * c.m;
        T.assign(start.begin(), start.begin() + cells);
        stash.assign(start.begin() + cells, start.begin() + cells + c.s);
        spill.assign(start.begin() + cells + c.s, start.end());
        st = Run();
        st.n = 0;
        for (int v : T) if (v >= 0) st.n++;
        for (int v : stash) if (v >= 0) st.n++;
        st.n += (long)spill.size();
        pick = &pk; arity = &ar;
        insertInner(key, 0, false);
        Conf out; out.reserve(cells + c.s + spill.size());
        out.append((const char*)T.data(), T.size());
        out.append((const char*)stash.data(), stash.size());
        out.append((const char*)spill.data(), spill.size());
        return out;
    }
    vector<int> stored(const Conf& cf) const {
        vector<int> v;
        for (size_t i = 0; i < cf.size(); i++) if ((int8_t)cf[i] >= 0) v.push_back((int8_t)cf[i]);
        return v;
    }
    // slot reads needed to find key k in configuration cf (-1: absent)
    int probes(const Conf& cf, int k) const {
        for (int i = 0; i < c.d; i++) if ((int8_t)cf[i * c.m + h[k][i]] == k) return i + 1;
        int base = c.d * c.m;
        for (int j = 0; j < c.s; j++) if ((int8_t)cf[base + j] == k) return c.d + j + 1;
        for (size_t j = base + c.s; j < cf.size(); j++) if ((int8_t)cf[j] == k) return c.d + c.s + (int)(j - base - c.s) + 1;
        return -1;
    }
};

int main(int argc, char** argv) {
    Mc mc; Cfg& c = mc.c; int show = 3; long maxAssign = 0;
    for (int i = 1; i < argc; i++) {
        string a = argv[i];
        auto next = [&]() -> int { if (i + 1 >= argc) { fprintf(stderr, "missing value after %s\n", a.c_str()); exit(2); } return atoi(argv[++i]); };
        if (a == "-d") c.d = next(); else if (a == "-m") c.m = next(); else if (a == "-s") c.s = next();
        else if (a == "-K") c.K = next(); else if (a == "-D") c.D = next(); else if (a == "-u") c.u = next();
        else if (a == "--show") show = next(); else if (a == "--max-assign") maxAssign = next();
        else if (a == "--mutant") { if (i + 1 < argc && string(argv[++i]) == "retry-original") c.mutant = true; else { fprintf(stderr, "--mutant retry-original\n"); return 2; } }
        else { fprintf(stderr, "usage: tinycheck [-d D] [-m CELLS] [-s STASH] [-K MAXKICKS] [-D GUARD] [-u KEYS] [--mutant retry-original]\n"); return 2; }
    }
    if (c.u > 100 || c.d * c.m + c.s + 64 > 120) { fprintf(stderr, "configuration too large for a tiny check\n"); return 2; }
    long bound = (long)c.K * (1 + (long)c.D * (c.s + 1));
    int cells = c.d * c.m;
    auto t0 = chrono::steady_clock::now();
    // all position tuples of one key
    int nTup = 1; for (int i = 0; i < c.d; i++) nTup *= c.m;
    vector<vector<int>> tup(nTup, vector<int>(c.d));
    for (int t = 0; t < nTup; t++) { int x = t; for (int i = 0; i < c.d; i++) { tup[t][i] = x % c.m; x /= c.m; } }
    // Cells inside one sub-table are interchangeable, so an assignment is checked only if no renaming of the
    // positions (m! per sub-table) gives a smaller sorted list of position tuples.
    vector<vector<int>> perms;                       // all permutations of 0..m-1
    { vector<int> pm(c.m); for (int i = 0; i < c.m; i++) pm[i] = i; do perms.push_back(pm); while (next_permutation(pm.begin(), pm.end())); }
    auto canonical = [&](const vector<int>& av) -> bool {
        long combos = 1; for (int i = 0; i < c.d; i++) combos *= (long)perms.size();
        for (long z = 1; z < combos; z++) {
            vector<int> mp(c.d); long zz = z;
            for (int i = 0; i < c.d; i++) { mp[i] = (int)(zz % perms.size()); zz /= perms.size(); }
            vector<int> img(av.size());
            for (size_t k = 0; k < av.size(); k++) {
                int idx = 0, mul = 1;
                for (int i = 0; i < c.d; i++) { idx += perms[mp[i]][tup[av[k]][i]] * mul; mul *= c.m; }
                img[k] = idx;
            }
            sort(img.begin(), img.end());
            if (img < av) return false;
        }
        return true;
    };
    long assigns = 0, skipped = 0, confs = 0, ins = 0, paths = 0, noop = 0, reachStash = 0, reachOvf = 0, reachTrip = 0, viol = 0;
    long vP[6] = {0, 0, 0, 0, 0, 0};
    long maxRoundsNT = 0, maxRoundsT = 0;
    vector<long> depthHist(c.D + 2, 0);
    int shown = 0;
    // keys are interchangeable: enumerate non-decreasing tuple-index sequences
    vector<int> av(c.u, 0);
    bool more = true;
    while (more) {
        if (!canonical(av)) {
            skipped++;
            int i = c.u - 1;
            while (i >= 0 && av[i] == nTup - 1) i--;
            if (i < 0) { more = false; break; }
            av[i]++; for (int j = i + 1; j < c.u; j++) av[j] = av[i];
            continue;
        }
        assigns++;
        if (assigns % 200 == 0) { fprintf(stderr, "  ... %ld assignments done (%.0f s)\n", assigns, chrono::duration<double>(chrono::steady_clock::now() - t0).count()); }
        if (maxAssign && assigns > maxAssign) break;
        mc.h.assign(c.u, vector<int>());
        for (int k = 0; k < c.u; k++) mc.h[k] = tup[av[k]];
        Conf empty(cells + c.s, (char)-1);
        set<Conf> level; level.insert(empty);
        for (int nk = 0; nk < c.u; nk++) {
            set<Conf> nxt;
            for (const Conf& conf : level) {
                vector<int> heldV = mc.stored(conf);
                vector<char> held(c.u, 0); for (int k : heldV) held[k] = 1;
                confs++;
                for (int k : heldV) {   // P5
                    vector<int> pk, ar;
                    Conf c2 = mc.runOne(conf, k, pk, ar); noop++;
                    if (c2 != conf || mc.st.rounds != 0) { vP[5]++; viol++; }
                }
                for (int k = 0; k < c.u; k++) {
                    if (held[k]) continue;
                    ins++;
                    vector<int> pk, ar;
                    while (true) {
                        Conf c2 = mc.runOne(conf, k, pk, ar);
                        const Run& r = mc.st;
                        paths++;
                        bool bad[6] = {false, false, false, false, false, false};
                        vector<int> sv = mc.stored(c2);
                        vector<int> want = heldV; want.push_back(k);
                        vector<int> a1 = sv, b1 = want; sort(a1.begin(), a1.end()); sort(b1.begin(), b1.end());
                        if (a1 != b1 || r.n != (long)sv.size()) bad[1] = true;
                        else for (int x : sv) {
                            if (mc.probes(c2, x) < 0) bad[2] = true;   // not at one of its own d positions, nor in stash/fallback
                        }
                        if (r.ovfInRehash) bad[3] = true;
                        if (r.rounds > bound && !r.tripped) bad[4] = true;
                        if (r.stashed) reachStash++;
                        if (r.ovf) reachOvf++;
                        depthHist[min(r.maxDepth, c.D + 1)]++;
                        if (r.tripped) { reachTrip++; maxRoundsT = max(maxRoundsT, r.rounds); }
                        else maxRoundsNT = max(maxRoundsNT, r.rounds);
                        for (int b = 1; b <= 5; b++) if (bad[b]) { vP[b]++; viol++; }
                        if ((bad[1] || bad[2] || bad[3] || bad[4]) && shown < show) {
                            shown++;
                            printf("VIOLATION (P1=%d P2=%d P3=%d P4=%d): key positions per key:", (int)bad[1], (int)bad[2], (int)bad[3], (int)bad[4]);
                            for (int q = 0; q < c.u; q++) { printf(" k%d(", q); for (int i = 0; i < c.d; i++) printf("%d%s", mc.h[q][i], i + 1 < c.d ? "," : ""); printf(")"); }
                            printf("; inserting key %d into [", k);
                            for (size_t q = 0; q < conf.size(); q++) printf("%d ", (int)(int8_t)conf[q]);
                            printf("]; eviction picks:");
                            for (int q = 0; q < r.pos; q++) printf(" %d", pk[q]);
                            printf("; result [");
                            for (size_t q = 0; q < c2.size(); q++) printf("%d ", (int)(int8_t)c2[q]);
                            printf("] rounds=%ld\n", r.rounds);
                        }
                        nxt.insert(c2);
                        // next eviction-choice path: depth-first over the replayed picks
                        pk.resize(r.pos); ar.resize(r.pos);
                        int i = (int)pk.size() - 1;
                        while (i >= 0 && pk[i] == ar[i] - 1) i--;
                        if (i < 0) break;
                        pk[i]++; pk.resize(i + 1); ar.resize(i + 1);
                    }
                }
            }
            level.swap(nxt);
        }
        // next non-decreasing sequence
        int i = c.u - 1;
        while (i >= 0 && av[i] == nTup - 1) i--;
        if (i < 0) more = false;
        else { av[i]++; for (int j = i + 1; j < c.u; j++) av[j] = av[i]; }
    }
    double secs = chrono::duration<double>(chrono::steady_clock::now() - t0).count();
    printf("\n=== tinycheck: d=%d m=%d s=%d K=%d D=%d u=%d  mutant=%s ===\n", c.d, c.m, c.s, c.K, c.D, c.u, c.mutant ? "retry-original" : "none");
    printf("hash assignments checked (up to renaming of keys and of the cells inside a sub-table): %ld  (skipped as equivalent: %ld)\n", assigns - (maxAssign && assigns > maxAssign ? 1 : 0), skipped);
    printf("configurations expanded: %ld   insertions (config x key): %ld   eviction-choice paths: %ld   re-insert checks: %ld\n", confs, ins, paths, noop);
    printf("reach: paths reaching the stash %ld, the overflow branch %ld, the depth guard %ld\n", reachStash, reachOvf, reachTrip);
    printf("reach: deepest nesting level per path (0..D):");
    for (int q = 0; q <= c.D; q++) printf(" %ld", depthHist[q]);
    printf("\n");
    printf("round bound K(1+D(s+1)) = %ld; largest rounds found: %ld without the guard, %ld with it\n", bound, maxRoundsNT, maxRoundsT);
    printf("violations: %ld   (P1 conservation %ld, P2 lookup %ld, P3 nested overflow %ld, P4 round bound %ld, P5 re-insert %ld)\n", viol, vP[1], vP[2], vP[3], vP[4], vP[5]);
    printf("seconds: %.1f\n", secs);
    printf("RESULT: %s\n", viol == 0 ? "PASS" : "FAIL");
    if (c.mutant) printf("(mutant run: FAIL is the expected result; PASS would mean the checker cannot see the defect)\n");
    return ((viol == 0) == !c.mutant) ? 0 : 1;
}
