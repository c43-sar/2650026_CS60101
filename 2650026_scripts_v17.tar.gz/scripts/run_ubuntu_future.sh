#!/usr/bin/env bash
# run_ubuntu_future.sh -- the deferred runs of the paper (future work), for a Linux PC with about 32 GB of RAM (written for Ubuntu LTS, bash).
#
#   (1) exact whole-trace churn model of the MAWI trace (one entry per distinct flow in memory): exact peak and 99th-percentile occupancy,
#       and a check of the flow-sampled run of the paper (residence-time distribution and mean occupancy should agree);
#   (2) the benchmark at N = 10^7 (`bench main`, run_all.sh stage `big`), which the paper does not report.
# Nothing here is a paper number until it has been run and added to the paper. Latencies from this machine are not comparable with the test platform.
#
# Usage:   bash run_ubuntu_future.sh                 all stages in order
#          bash run_ubuntu_future.sh trace churn      only the named stages (setup trace churn big pack)
#          FORCE=1 bash run_ubuntu_future.sh          redo stages whose output already exists
# Environment (all optional):
#   W=$HOME/<EMPLOYEE CODE>  work folder (default: $HOME/$EMPLOYEE_CODE) (mawi/, tools/, adsa/ below it)      MEM_LIMIT_MB=28000   pcap2flows stops (exit 3, nothing written) above this
#   BIG_N=10000000           N of the big stage                               BIG_CAP=0            wall-clock cap in seconds, 0 = none
#   APT=1                    let the setup stage run `sudo apt install` (default: only print the command)
# Files expected before the stages run (from the repository https://github.com/c43-sar/2650026_CS60101):
#   $W/tools/pcap2flows.py (v6)      $W/adsa/{bench.cpp,run_all.sh,run_sweep.sh,perf_summarize.py,plot_sweep.py}
# Disk: 6.1 GB for the downloaded trace (read as it is, never unzipped; delete it after the pack stage). Download: one 6.1 GB file, resumable (wget -c).
# Output: $W/ubuntu_future_results.tar.gz  (results_big.tar.gz, churn.txt, churn_res.txt, whole_stats.txt, trace.sha256, mem.log, sysinfo.txt, SHA256SUMS)
# Then, on the test laptop, the exact residence times feed the SDN churn stage (RES=churn_res.txt, tag churn_trace_exact; see RUN_GUIDE_1 part D).
set -uo pipefail
W="${W:-$HOME/${EMPLOYEE_CODE:?set EMPLOYEE_CODE=<your employee code> (the work folder is ~/<code>)}}"; MEM_LIMIT_MB="${MEM_LIMIT_MB:-28000}"; BIG_N="${BIG_N:-10000000}"; BIG_CAP="${BIG_CAP:-0}"; FORCE="${FORCE:-0}"
URL="http://mawi.nezu.wide.ad.jp/mawi/samplepoint-F/2026/202610181400.pcap.gz"; TRACE="202610181400.pcap.gz"
STAGES=("$@"); [ ${#STAGES[@]} -eq 0 ] && STAGES=(setup trace churn big pack)
mkdir -p "$W/mawi" "$W/tools" "$W/adsa"
declare -A STATUS
have() { [ -s "$1" ] && [ "$FORCE" != 1 ]; }
need() { for f in "$@"; do [ -e "$f" ] || { echo "missing file: $f"; return 1; }; done; }

stage_setup() {
  local cmd="sudo apt update && sudo apt install -y build-essential g++ python3 python3-pandas python3-matplotlib tmux wget"
  if [ "${APT:-0}" = 1 ]; then eval "$cmd"; else echo "run once (or set APT=1):  $cmd"; fi
  need "$W/tools/pcap2flows.py" "$W/adsa/bench.cpp" "$W/adsa/run_all.sh" || return 1
  df -h "$W" | tail -1
  { echo "# $(date -Is)"; lsb_release -a 2>/dev/null; uname -r; lscpu | head -20; free -m; } > "$W/sysinfo.txt"
}
stage_trace() {
  cd "$W/mawi" || return 1
  if have "$TRACE.done"; then echo "trace already downloaded"; return 0; fi
  wget -c "$URL" && sha256sum "$TRACE" | tee trace.sha256 && date -Is > "$TRACE.done"
}
stage_churn() {
  cd "$W/mawi" || return 1
  need "$TRACE" "$W/tools/pcap2flows.py" || return 1
  if have churn_res.txt; then echo "churn_res.txt exists (FORCE=1 to redo)"; return 0; fi
  ( while true; do date -Is; free -m | sed -n 2p; sleep 10; done ) > mem.log 2>&1 & local MEM=$!
  # exact mode = no --flow-sample: one entry per distinct flow; idle timeouts 5, 15, 30, 60 s
  python3 "$W/tools/pcap2flows.py" "$TRACE" --out /dev/null --churn 5,15,30,60 --mem-limit-mb "$MEM_LIMIT_MB" \
      --churn-out churn.txt --res-out churn_res.txt 2>&1 | tee whole_stats.txt
  local rc=${PIPESTATUS[0]}; kill "$MEM" 2>/dev/null
  [ "$rc" = 3 ] && echo "memory limit reached: nothing written. Raise MEM_LIMIT_MB or keep the flow-sampled result (--flow-sample)."
  return "$rc"
}
stage_big() {
  cd "$W/adsa" || return 1
  need run_all.sh bench.cpp || return 1
  if have results_big.tar.gz; then echo "results_big.tar.gz exists (FORCE=1 to redo)"; return 0; fi
  BIG=1 BIG_N="$BIG_N" BIG_CAP="$BIG_CAP" OUT=results_big systemd-inhibit --what=sleep:idle bash run_all.sh big 2>&1 | tee big.log
  [ -s results_big.tar.gz ]
}
stage_pack() {
  cd "$W" || return 1
  local f=(); for x in adsa/results_big.tar.gz adsa/big.log mawi/churn.txt mawi/churn_res.txt mawi/whole_stats.txt mawi/trace.sha256 mawi/mem.log sysinfo.txt; do [ -s "$x" ] && f+=("$x"); done
  [ ${#f[@]} -gt 0 ] || { echo "nothing to pack"; return 1; }
  sha256sum "${f[@]}" > SHA256SUMS && tar czf ubuntu_future_results.tar.gz "${f[@]}" SHA256SUMS && ls -l ubuntu_future_results.tar.gz
  echo "the trace file $W/mawi/$TRACE can be deleted now (6.1 GB)"
}
RC=0
for s in "${STAGES[@]}"; do
  echo "=== stage $s ($(date -Is))"
  if declare -F "stage_$s" >/dev/null; then "stage_$s"; STATUS[$s]=$?; else echo "unknown stage $s"; STATUS[$s]=2; fi
  [ "${STATUS[$s]}" -ne 0 ] && RC=1
done
echo; echo "=== summary"; for s in "${STAGES[@]}"; do printf '%-8s %s\n' "$s" "$([ "${STATUS[$s]}" = 0 ] && echo ok || echo "FAILED (${STATUS[$s]})")"; done
exit $RC
