#!/usr/bin/env python3
"""make_tables_dscan.py -- second part: d=4/5 scan, rehash cost, window, hypergraph, retry defect, layout, classical rehash timing, MAWI-key sweep.
usage: python3 make_tables_dscan.py RESULTS_FULL_DIR RESULTS_DSCAN_DIR OUT_DIR"""
import sys, os, re, math, pandas as pd, numpy as np
R, D, O = sys.argv[1], sys.argv[2], sys.argv[3]
def w(n, s): open(os.path.join(O, n + '.tex'), 'w', encoding='utf-8', newline='\n').write(s)
f = lambda x: format(int(round(x)), ',').replace(',', '{,}')
def sci(x, n=2):
    if x == 0: return '$0$'
    if abs(x) >= 0.01: return '%.4f' % x if abs(x) < 0.1 else '%.3f' % x
    e = int(math.floor(math.log10(abs(x)))); return '$%.*f\\times10^{%d}$' % (n, x / 10 ** e, e)
def tab(spec, hdr, rows, rs='\\columnwidth'):
    return '\\resizebox{%s}{!}{%%\n\\begin{tabular}{%s}\n\\hline\n%s \\\\ \\hline\n%s\\end{tabular}%%\n}\n' % (rs, spec, hdr, ''.join(r + ' \\\\ \\hline\n' for r in rows))
facts = []
# ---------------- d scan: sensitivity
rows = []
for d, alphas in ((3, (0.80, 0.88)), (4, (0.80, 0.88, 0.94, 0.96)), (5, (0.80, 0.88, 0.95, 0.98))):
    E = pd.read_csv(os.path.join(R if d == 3 else D, 'sens.csv' if d == 3 else 'sens_d%d.csv' % d))
    A = E[E.block == 'A']
    for a in alphas:
        for mk in (4, 16, 64):
            g = A[(np.isclose(A.alpha, a)) & (A.maxKicks == mk)]
            n = g.N.iloc[0]; ph = g.routedFrac.mean(); ov = g.overflowEvents.mean() / n
            rows.append('$%d$ & $%.2f$ & $%d$ & %s & %s & %s & $%d$ & $%d$ & $%d/%d$ & $%.2f$' % (d, a, mk, sci(ph), sci(ov), ('%s' % f(1 / ov)) if ov > 0 else '--', g.guardTrips.sum(), g.missing.sum(), g.maxInsIters.max(), mk * 101, g.meanItersPerInsert.mean()))
    facts.append('dscan sens d=%d: rows %d, missing %d, loads %s' % (d, len(E), E.missing.sum(), sorted(set(round(x, 6) for x in E.loadAchieved))))
w('dscan_sens', tab('|c|c|c|c|c|c|c|c|c|c|', '\\textbf{$d$} & \\textbf{$\\alpha$} & \\textbf{$\\mathtt{MaxKicks}$} & \\textbf{$\\hat p$} & \\textbf{Overflow rate} & \\textbf{Ins./ovf.} & \\textbf{Guard trips} & \\textbf{Missing} & \\textbf{Worst/bound} & \\textbf{Iters/ins.}', rows))
# ---------------- d scan: sweep means, tail
rows = []; rt = []
for d, alphas in ((3, (80, 88)), (4, (80, 88, 94, 96)), (5, (80, 88, 95, 98))):
    S = pd.read_csv(os.path.join(R if d == 3 else D, 'sweep.csv' if d == 3 else 'sweep_d%d.csv' % d)); L = pd.read_csv(os.path.join(R if d == 3 else D, 'sweep_latency.csv' if d == 3 else 'sweep_d%d_latency.csv' % d))
    for a in alphas:
        sc = 'proposed_d%d_K16_s4_a%d' % (d, a)
        m = lambda df, N, c: df[(df.scheme == sc) & (df.N == N)][c].mean()
        rows.append('$%d$ & $0.%02d$ & %.3f & %.3f & %.3f & %.0f & %.0f & %.0f & %.0f' % (d, a, m(S, 10**6, 'cellsPerKey'), m(S, 10**6, 'insItersPerOp'), m(S, 10**6, 'lookItersPerOp'), m(L, 10**5, 'insNsPerOp'), m(L, 10**5, 'lookNsPerOp'), m(L, 10**6, 'insNsPerOp'), m(L, 10**6, 'lookNsPerOp')))
    T = pd.read_csv(os.path.join(R if d == 3 else D, 'tail.csv' if d == 3 else 'tail_d%d.csv' % d))
    for a in alphas:
        sc = 'proposed_d%d_K16_s4_a%d' % (d, a)
        t = T[(T.scheme == sc) & (T.N == 100000)].iloc[0]
        rt.append('$%d$ & $0.%02d$ & %s & %s & %s' % (d, a, f(t.rehashOrOverflowEvents), f(t.worstSingleInsertIters), f(t.guardTrips)))
    P_ = S[S.scheme.str.startswith('proposed')]
    facts.append('dscan sweep d=%d proposed rows: missingMax=%d, maxInsIters max=%d, guardTrips total=%.0f' % (d, P_.missingMax.max(), P_.maxInsIters.max(), (P_.guardTripsPerRun * P_.reps).sum()))
w('dscan_sweep', tab('|c|c|c|c|c|c|c|c|c|', '\\textbf{$d$} & \\textbf{$\\alpha$} & \\textbf{Cells/key} & \\textbf{Ins.\\ iters} & \\textbf{Look.\\ iters} & \\textbf{Ins.\\ ns, $10^5$} & \\textbf{Look.\\ ns, $10^5$} & \\textbf{Ins.\\ ns, $10^6$} & \\textbf{Look.\\ ns, $10^6$}', rows))
w('dscan_tail', tab('|c|c|c|c|c|', '\\textbf{$d$} & \\textbf{$\\alpha$} & \\textbf{Overflow events} & \\textbf{Worst insert} & \\textbf{Guard trips}', rt))
facts.append('dscan tail builds N=1e5: 2000 per scheme')
# ---------------- rehash cost (d=3,4,5)
rows = []
def rc(path):
    out = []
    t = open(path).read()
    for blk in re.split(r'\[REHASHCOST alpha=', t)[1:]:
        a = float(blk.split(']')[0])
        ev = re.search(r'events=(\d+) \(overflow events in the builds: (\d+)\)', blk)
        rs = re.search(r'RehashStash: ns p50=([\d.]+) p99=([\d.]+) max=([\d.]+)\s+rounds p50=([\d.]+) max=([\d.]+)\s+extraNestingDepth max=([\d.]+)', blk)
        fr = re.search(r'FullRebuild: ns p50=([\d.]+) p99=([\d.]+) max=([\d.]+)\s+rounds p50=([\d.]+)', blk)
        ra = re.search(r'ratio: p50=([\d.]+) min=([\d.]+) max=([\d.]+)', blk)
        if not (rs and fr and ra):
            facts.append('rehashcost %s alpha=%.2f: %s' % (os.path.basename(path), a, blk.strip().splitlines()[0][:160])); continue
        out.append((a, ev.groups(), rs.groups(), fr.groups(), ra.groups()))
    return out
for d, p in ((3, 'report_rehashcost.txt'), (4, 'report_rehashcost_d4.txt'), (5, 'report_rehashcost_d5.txt')):
    for a, ev, rs, fr, ra in rc(os.path.join(R if d == 3 else D, p)):
        if ev[0] == '0': rows.append('$%d$ & $%.2f$ & 0 & -- & -- & -- & --' % (d, a)); continue
        rows.append('$%d$ & $%.2f$ & %s & %s / %s / %s & %s & %s & %s / %s / %s' % (d, a, ev[0], f(float(rs[0])), f(float(rs[1])), f(float(rs[2])), f(float(rs[3])) , '%.1f' % (float(fr[0]) / 1e6), '%.0f' % float(ra[0]), '%.0f' % float(ra[1]), '%.0f' % float(ra[2])))
        facts.append('rehashcost d=%d a=%.2f events=%s extraNestingDepthMax=%s rebuildRoundsP50=%s' % (d, a, ev[0], rs[5], fr[3]))
w('rehashcost', tab('|c|c|c|c|c|c|c|', '\\textbf{$d$} & \\textbf{$\\alpha$} & \\textbf{Events} & \\textbf{\\textsc{RehashStash} ns p50/p99/max} & \\textbf{Rounds p50} & \\textbf{Rebuild ms p50} & \\textbf{Rebuild/\\textsc{RehashStash} p50/min/max}', rows))
# ---------------- window model (d=3)
rows = []
t = open(os.path.join(R, 'report_window.txt')).read()
for m in re.finditer(r'\[WINDOW alpha=([\d.]+) seg=(\w+)\s+W=(\d+)\] windows=(\d+) phat=([\d.]+) meanPerWindow=([\d.]+) disp=([\d.]+) obsFracOver=([\d.]+) binom=([\d.]+) chernoff=([\d.]+)', t):
    a, seg, W, nw, ph, mp, dp, ob, bi, ch = m.groups()
    if int(W) in (64, 256, 1024):
        rows.append('$%.2f$ & %s & $%s$ & %s & %.2f & %.1f & %s & %s & %s' % (float(a), 'all' if seg == 'all' else 'last fifth', W, sci(float(ph)), float(mp), float(dp), sci(float(ob)), sci(float(bi)), sci(float(ch))))
w('window', tab('|c|c|c|c|c|c|c|c|c|', '\\textbf{$\\alpha$} & \\textbf{Segment} & \\textbf{$W$} & \\textbf{$\\hat p$} & \\textbf{Mean/window} & \\textbf{Disp.} & \\textbf{Observed $\\Pr[X>s]$} & \\textbf{Binomial} & \\textbf{Chernoff}', rows))
# ---------------- hypergraph (d=3)
rows = []
t = open(os.path.join(R, 'report_hyper.txt')).read()
for blk in re.split(r'\[HYPER alpha=', t)[1:]:
    a = float(blk.split(']')[0])
    for m in re.finditer(r'density\s+([<\d.\-]+): inserts=(\d+) meanRounds=([\d.]+) maxRounds=(\d+) routedToStashFrac=([\d.]+)', blk):
        rows.append('$%.2f$ & $%s$ & %s & %.2f & %s & %s' % (a, m.group(1).replace('<', '{<}'), f(int(m.group(2))), float(m.group(3)), m.group(4), sci(float(m.group(5)))))
    de = re.search(r'offline minimum stash \(deficiency\) mean=([\d.]+) max=(\d+)\s+stash\+spill actually used mean=([\d.]+) max=(\d+)\s+seeds where the scheme used more than the offline minimum: (\d)/(\d)', blk)
    facts.append('hyper a=%.2f deficiency mean=%s max=%s; used mean=%s max=%s; more-than-minimum seeds %s/%s' % ((a,) + de.groups()))
    gm = re.search(r'final graph \(mean over seeds\): components=([\d.]+) componentsWithE>V=([\d.]+) largestComponentSlots\(max\)=(\d+) maxComponentDensity=([\d.]+)', blk)
    facts.append('hyper a=%.2f final graph components=%s E>V=%s largestSlots=%s maxDensity=%s' % ((a,) + gm.groups()))
w('hyper_bins', tab('|c|c|c|c|c|c|', '\\textbf{$\\alpha$} & \\textbf{Density $E/V$} & \\textbf{Insertions} & \\textbf{Mean rounds} & \\textbf{Max rounds} & \\textbf{Fraction to stash}', rows))
rows = []
for blk in re.split(r'\[HYPER alpha=', t)[1:]:
    a = float(blk.split(']')[0])
    de = re.search(r'offline minimum stash \(deficiency\) mean=([\d.]+) max=(\d+)\s+stash\+spill actually used mean=([\d.]+) max=(\d+)\s+seeds where the scheme used more than the offline minimum: (\d)/(\d)', blk)
    gm = re.search(r'maxComponentDensity=([\d.]+)', blk)
    rows.append('$%.2f$ & %s & %s & %s & %s/%s & %s' % (a, de.group(1), de.group(2), de.group(3), de.group(5), de.group(6), gm.group(1)))
w('hyper_deficiency', tab('|c|c|c|c|c|c|', '\\textbf{$\\alpha$} & \\textbf{Offline min.\\ stash (mean)} & \\textbf{(max)} & \\textbf{Stash+spill used (mean)} & \\textbf{Seeds above min.} & \\textbf{Max component density}', rows))
# ---------------- retry defect
rows = []
for m in re.finditer(r'retrybug d=3 alpha=([\d.]+) MaxKicks=(\d+) s=4 retry=(\w+)\(.*?\) meanMissing=([\d.]+) minMissing=(\d+) maxMissing=(\d+) meanOverflowEvents=([\d.]+) meanDepthGuardTrips=([\d.]+) meanStoredCount=([\d.]+)', open(os.path.join(R, 'report_retrybug.txt')).read()):
    a, mk, kind, mm, mn, mx, ov, gt, st = m.groups()
    rows.append('$%.2f$ & $%s$ & %s & %s & %s--%s & %s & %s' % (float(a), mk, 'carried key' if kind == 'CORRECT' else 'original key (retired)', f(float(mm)), f(int(mn)), f(int(mx)), f(float(ov)), f(float(st))))
w('retrybug', tab('|c|c|l|c|c|c|c|', '\\textbf{$\\alpha$} & \\textbf{$\\mathtt{MaxKicks}$} & \\textbf{Retry of} & \\textbf{Keys missing (mean)} & \\textbf{(min--max)} & \\textbf{Overflow events} & \\textbf{Keys stored of $2\\times10^5$}', rows))
# ---------------- layout (merge)
rows = []
for m in re.finditer(r'\[MERGE alpha=([\d.]+)\] identicalBehaviour=(\w+) missing\(sep/merged\)=(\d+)/(\d+) stashRouted=(\d+) \| positive ns: separate min=([\d.]+) med=([\d.]+)\s+merged min=([\d.]+) med=([\d.]+) \| negative ns: separate min=([\d.]+) med=([\d.]+)\s+merged min=([\d.]+) med=([\d.]+)', open(os.path.join(R, 'report_merge.txt')).read()):
    g = m.groups(); a = float(g[0])
    rows.append('$%.2f$ & %s & %.1f & %.1f & %.1f & %.1f & %.1f & %.1f' % (a, g[1], float(g[6]), float(g[8]), 100 * (1 - float(g[8]) / float(g[6])), float(g[10]), float(g[12]), 100 * (1 - float(g[12]) / float(g[10]))))
w('layout', tab('|c|c|c|c|c|c|c|c|', '\\textbf{$\\alpha$} & \\textbf{Same behaviour} & \\textbf{Pos.\\ separate ns} & \\textbf{Pos.\\ merged ns} & \\textbf{Saving \\%} & \\textbf{Neg.\\ separate ns} & \\textbf{Neg.\\ merged ns} & \\textbf{Saving \\%}', rows))
# ---------------- classical rehash timing
rows = []; C = []
for m in re.finditer(r'\[REHASHCLASSICAL (short|prescribed) maxLoop=(\d+)\] alpha=([\d.]+) seed=(\d) rehashes=(\d+) outermost=(\d+) nested=(\d+) nesting=(\d+) depthHist=\[.*?\] totalInsertSec=([\d.]+) outermostRehashShare=([\d.]+) maxSingleInsertMs=([\d.]+) maxOutermostInclMs=([\d.]+) maxExclMs=([\d.]+) meanKeysPerRehash=([\d.]+)', open(os.path.join(R, 'report_rehash_classical.txt')).read()):
    C.append(m.groups())
df = pd.DataFrame(C, columns=['loop', 'ml', 'a', 'seed', 'rh', 'out', 'nest', 'nesting', 'tot', 'share', 'maxins', 'maxincl', 'maxexcl', 'keys']).astype({'ml': int, 'a': float, 'rh': int, 'out': int, 'nest': int, 'nesting': int, 'tot': float, 'share': float, 'maxins': float, 'maxincl': float, 'maxexcl': float, 'keys': float})
for (lp, a, ml), g in df.groupby(['loop', 'a', 'ml'], sort=False):
    rows.append('%s ($\\mathtt{MaxLoop}{=}%s$) & $%.3f$ & %s & %s & %s & %s & %.1f & %s & %.0f' % (lp.capitalize(), f(ml), a, '/'.join(str(x) for x in g.rh), '/'.join(str(x) for x in g.out), '/'.join(str(x) for x in g.nesting), '%.0f' % g.maxincl.max() if g.maxincl.max() > 0 else '0', g.tot.mean(), ('%.0f' % g.maxexcl.max()) if g.maxexcl.max() > 0 else '0', 100 * g.share.mean()))
w('rehash_classical', tab('|l|c|c|c|c|c|c|c|c|', '\\textbf{Loop} & \\textbf{$\\alpha$} & \\textbf{Rehashes (3 seeds)} & \\textbf{Outermost} & \\textbf{Max nesting} & \\textbf{Max outermost incl.\\ ms} & \\textbf{Insert time s (mean)} & \\textbf{Max rehash excl.\\ ms} & \\textbf{Outermost share \\%}', rows))
df.to_csv(os.path.join(O, 'rehash_classical_summary.csv'), index=False)
# ---------------- MAWI-key sweep vs synthetic sweep at N=1e6
rows = []
SR = pd.read_csv(os.path.join(R, 'sweep_real.csv')); LR = pd.read_csv(os.path.join(R, 'sweep_real_latency.csv')); S = pd.read_csv(os.path.join(R, 'sweep.csv')); L = pd.read_csv(os.path.join(R, 'sweep_latency.csv'))
names = [('linear_probing', 'Linear probing ($\\alpha{=}0.70$)'), ('chained', 'Chained ($\\alpha{=}1.00$)'), ('classical_short', 'Classical, short loop ($\\alpha{=}0.45$)'), ('classical_prescribed', 'Classical, prescribed loop ($\\alpha{=}0.45$)'),
         ('proposed_d3_K16_s4_a45', 'Proposed ($\\alpha{=}0.45$)'), ('proposed_d3_K16_s4_a80', 'Proposed ($\\alpha{=}0.80$)'), ('proposed_d3_K16_s4_a88', 'Proposed ($\\alpha{=}0.88$)')]
mean = lambda df, sc, N, c: df[(df.scheme == sc) & (df.N == N)][c].mean()
for sc, lab in names:
    rows.append('%s & %.3f / %.3f & %.3f / %.3f & %.0f / %.0f & %.0f / %.0f & %s / %s' % (lab, mean(S, sc, 10**6, 'insItersPerOp'), mean(SR, sc, 10**6, 'insItersPerOp'), mean(S, sc, 10**6, 'lookItersPerOp'), mean(SR, sc, 10**6, 'lookItersPerOp'),
        mean(L, sc, 10**6, 'insNsPerOp'), mean(LR, sc, 10**6, 'insNsPerOp'), mean(L, sc, 10**6, 'lookNsPerOp'), mean(LR, sc, 10**6, 'lookNsPerOp'), f(S[(S.scheme == sc) & (S.N == 10**5)].maxInsIters.max()), f(SR[(SR.scheme == sc) & (SR.N == 10**5)].maxInsIters.max())))
w('real_sweep', tab('|l|c|c|c|c|c|', '\\textbf{Scheme} & \\textbf{Insert iters} & \\textbf{Lookup iters} & \\textbf{Insert ns} & \\textbf{Lookup ns} & \\textbf{Worst insert, $N{=}10^5$}', rows))
facts.append('real sweep: rows %d, missingMax %d, guardTrips total %.0f ; synthetic guard trips total %.0f' % (len(SR), SR.missingMax.max(), (SR.guardTripsPerRun * SR.reps).sum(), (S.guardTripsPerRun * S.reps).sum()))
for sc, lab in names[4:]:
    g = SR[SR.scheme == sc]; gt = g[g.guardTripsPerRun > 0]
    facts.append('real sweep %s guard trips %.0f at sizes %s; max maxInsIters %d' % (sc, (g.guardTripsPerRun * g.reps).sum(), sorted(gt.N.unique().tolist()), g.maxInsIters.max()))
open(os.path.join(O, 'facts_main2.txt'), 'w').write('\n'.join(facts) + '\n'); print('\n'.join(facts))
