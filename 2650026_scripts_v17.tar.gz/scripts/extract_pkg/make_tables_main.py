#!/usr/bin/env python3
"""make_tables_main.py -- build every benchmark table of the paper from the results_full run (kernel 7.2.11).
usage: python3 make_tables_main.py RESULTS_FULL_DIR RESULTS_DSCAN_DIR OUT_DIR
Every number in the tables is computed here from the CSV/report files; nothing is typed by hand."""
import sys, os, re, math, pandas as pd, numpy as np
R, D, O = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(O, exist_ok=True)
def w(name, s): open(os.path.join(O, name + '.tex'), 'w', encoding='utf-8', newline='\n').write(s)
def ns(x):  # ns -> readable
    x = float(x)
    if x >= 1e9: return '%.2f s' % (x / 1e9)
    if x >= 1e6: return '%.1f ms' % (x / 1e6)
    if x >= 1e3: return '%.1f $\\mu$s' % (x / 1e3)
    return '%d ns' % round(x)
def sci(x, n=2):
    if x == 0: return '0'
    e = int(math.floor(math.log10(abs(x))))
    m = x / 10 ** e
    if -2 <= e <= 0: return ('%.' + str(max(0, 3 - e if e < 0 else 3)) + 'f') % x if abs(x) >= 0.01 else '%.*f\\times10^{%d}' % (n, m, e)
    return '$%.*f\\times10^{%d}$' % (n, m, e)
def tex(tabspec, header, rows, resize=True):
    s = ''
    if resize: s += '\\resizebox{\\columnwidth}{!}{%\n'
    s += '\\begin{tabular}{' + tabspec + '}\n\\hline\n' + header + ' \\\\ \\hline\n'
    for r in rows: s += r + ' \\\\ \\hline\n'
    s += '\\end{tabular}%\n' + ('}\n' if resize else '')
    return s
facts = []
# ------------------------------------------------------------------ Table: comparative microbenchmarks (report_main / report_real_main)
def parse_main(path):
    t = open(path).read(); out = {}
    cur = None
    for l in t.splitlines():
        m = re.match(r'\[(.+?)\] (.*)', l)
        if not m: continue
        key, rest = m.group(1), m.group(2)
        d = out.setdefault(key, {})
        if 'insertLatencyNs' in rest:
            d['ins'] = {k: int(v) for k, v in re.findall(r'(p50|p99|p999|max)=(\d+)', rest)}
        elif 'lookupLatencyNs' in rest:
            d['look'] = {k: int(v) for k, v in re.findall(r'(p50|p99|p999|max)=(\d+)', rest)}
        elif rest.startswith('kicks'):
            pass
        else:
            for k, v in re.findall(r'([A-Za-z()=_ ,]+?)=([0-9.]+)(?=\s|$)', ' ' + rest):
                pass
            d['raw'] = rest
    return out
def num(raw, name):
    m = re.search(re.escape(name) + r'=([0-9.]+)', raw); return float(m.group(1)) if m else None
for tag, path, name in (('synthetic', 'report_main.txt', 'comparative_synth'), ('MAWI keys', 'report_real_main.txt', 'comparative_real')):
    P = parse_main(os.path.join(R, path))
    # attach proposed latencies
    pk = [k for k in P if k.startswith('Proposed d=')][0]
    P[pk]['ins'] = P['Proposed']['ins']; P[pk]['look'] = P['Proposed']['look']
    rowsl = []
    def row(label, key, dd):
        d = P[key]; raw = d['raw']
        load = num(raw, 'load'); lp = num(raw, 'avgLookupProbes') or num(raw, 'avgLookupProbes(table only)')
        i = d['ins']
        mk = num(raw, 'maxInsertProbes') or num(raw, 'maxKicksObserved') or num(raw, 'maxChainLen(=maxInsertProbes)')
        rh = num(raw, 'fullRehashes')
        so = num(raw, 'stashOverflowEvents')
        rr = ('%d' % rh) if rh is not None else (('0 (%s \\textsc{RehashStash})' % format(int(so), ',').replace(',', '{,}')) if so is not None else '0')
        return '%s & %s & %.3f & %.3f & %d/%d/%d ns & %s & %s & %s' % (label, dd, load, lp, i['p50'], i['p99'], i['p999'], ns(i['max']), ('--' if mk is None else '%d' % mk), rr)
    rowsl.append(row('Linear probing', 'LinearProbing', 'N/A'))
    rowsl.append(row('Chained hashing', 'Chained', 'N/A'))
    for a in ('0.33', '0.49', '0.495'):
        k = 'ClassicalCuckoo short a=' + a
        rowsl.append(row('Classical, short loop ($\\mathtt{MaxLoop}{=}%d$)' % num(P[k]['raw'], 'maxLoopParam'), k, '2'))
    for a in ('0.33', '0.49', '0.495'):
        k = 'ClassicalCuckoo prescribed a=' + a
        rowsl.append(row('Classical, prescribed loop ($\\mathtt{MaxLoop}{=}%s$)' % format(int(num(P[k]['raw'], 'maxLoopParam')), ',').replace(',', '{,}'), k, '2'))
    rowsl.append(row('\\textbf{Proposed} ($\\mathtt{MaxKicks}{=}16$, $s{=}4$)', pk, '3'))
    hdr = '\\textbf{Scheme} & \\textbf{$d$} & \\textbf{Load $\\alpha$} & \\textbf{Lookup probes} & \\textbf{Insert p50/p99/p999} & \\textbf{Insert max} & \\textbf{Max kicks/probes} & \\textbf{Full rehashes}'
    w(name, tex('|l|c|c|c|c|c|c|c|', hdr, rowsl, resize=False).replace('\\begin{tabular}', '\\resizebox{\\linewidth}{!}{%\n\\begin{tabular}', 1).replace('\\end{tabular}%\n', '\\end{tabular}%\n}\n'))
    raw = P[pk]['raw']
    facts.append('%s proposed: %s' % (name, raw))
# ------------------------------------------------------------------ Table: shared-load comparison (report_ext)
t = open(os.path.join(R, 'report_ext.txt')).read(); rows = []
def pm(a, b, f='%.1f'): return (f + '$\\pm$' + f) % (a, b)
for l in t.splitlines():
    m = re.match(r'\[EXT classical (short|prescribed) maxLoop=(\d+)\] alpha=([0-9.]+) fullRehashes=([0-9.]+)\+-([0-9.]+) maxKicksOrLoop=([0-9.]+)\+-([0-9.]+) maxInsertMs=([0-9.]+)\+-([0-9.]+)', l)
    if m:
        k, ml, a, rh, rhs, wk, wks, mi, mis = m.groups()
        mi, mis = float(mi), float(mis)
        f = '%.3f' if mi < 10 else '%.0f'
        rows.append(('c', k, int(ml), float(a), 'Classical, %s loop ($\\mathtt{MaxLoop}{=}%d$) & %.2f & %s & %s & %s' % (k, int(ml), float(a), pm(float(rh), float(rhs)), pm(float(wk), float(wks)), (f + '$\\pm$' + f) % (mi, mis))))
    m = re.match(r'\[EXT proposed d=3 s=4\] alpha=([0-9.]+) MaxKicks=16 routingProb=([0-9.]+)\+-([0-9.]+) overflowEvents=([0-9.]+)\+-([0-9.]+) .* maxInsertMs=([0-9.]+)\+-([0-9.]+)', l)
    if m:
        a, rp, rps, ov, ovs, mi, mis = m.groups(); mi, mis = float(mi), float(mis)
        rows.append(('p', '', 0, float(a), 'Proposed ($\\mathtt{MaxKicks}{=}16$, $s{=}4$) & %.2f & %s & -- & %s' % (float(a), pm(float(ov), float(ovs)), '%.3f$\\pm$%.3f' % (mi, mis))))
rowsl = [r[4] for r in sorted(rows, key=lambda r: (r[0] == 'p', r[1] != 'short', r[3]))]
w('ext', tex('|l|c|c|c|c|', '\\textbf{Scheme} & \\textbf{$\\alpha$} & \\textbf{Rehashes} & \\textbf{Longest walk} & \\textbf{Max insert (ms)}', rowsl))
# ------------------------------------------------------------------ sweep tables
S = pd.read_csv(os.path.join(R, 'sweep.csv')); L = pd.read_csv(os.path.join(R, 'sweep_latency.csv'))
names = [('linear_probing', 'Linear probing ($\\alpha{=}0.70$)'), ('chained', 'Chained ($\\alpha{=}1.00$)'), ('classical_short', 'Classical, short loop ($\\alpha{=}0.45$)'),
         ('classical_prescribed', 'Classical, prescribed loop ($\\alpha{=}0.45$)'), ('proposed_d3_K16_s4_a45', 'Proposed ($\\alpha{=}0.45$)'),
         ('proposed_d3_K16_s4_a80', 'Proposed ($\\alpha{=}0.80$)'), ('proposed_d3_K16_s4_a88', 'Proposed ($\\alpha{=}0.88$)')]
def mean_at(df, sch, N, col): return df[(df.scheme == sch) & (df.N == N)][col].mean()
rows = []
for sch, lab in names:
    rows.append('%s & %.3f & %.3f & %.3f & %.0f & %.0f & %.0f & %.0f' % (lab, mean_at(S, sch, 10**6, 'cellsPerKey'), mean_at(S, sch, 10**6, 'insItersPerOp'), mean_at(S, sch, 10**6, 'lookItersPerOp'),
        mean_at(L, sch, 10**5, 'insNsPerOp'), mean_at(L, sch, 10**5, 'lookNsPerOp'), mean_at(L, sch, 10**6, 'insNsPerOp'), mean_at(L, sch, 10**6, 'lookNsPerOp')))
w('sweep_means', '\\resizebox{\\linewidth}{!}{%\n' + tex('|l|c|c|c|c|c|c|c|', '\\textbf{Scheme} & \\textbf{Cells/key} & \\textbf{Insert iters} & \\textbf{Lookup iters} & \\textbf{Ins.\\ ns, $10^5$} & \\textbf{Look.\\ ns, $10^5$} & \\textbf{Ins.\\ ns, $10^6$} & \\textbf{Look.\\ ns, $10^6$}', rows, resize=False) + '}\n')
# worst single insert
rows = []
for sch, lab in names:
    v = [int(S[(S.scheme == sch) & (S.N == n)].maxInsIters.max()) for n in (100, 1000, 10000, 100000)]
    rows.append('%s & %s' % (lab, ' & '.join(format(x, ',').replace(',', '{,}') for x in v)))
b = [int((S[(S.scheme == names[0][0]) & (S.N == n)].reps).sum()) for n in (100, 1000, 10000, 100000)]
rows.append('\\textit{Builds sampled} & ' + ' & '.join(format(x, ',').replace(',', '{,}') for x in b))
w('sweep_worst', tex('|l|c|c|c|c|', '\\textbf{Scheme} & \\textbf{$N{=}10^2$} & \\textbf{$N{=}10^3$} & \\textbf{$N{=}10^4$} & \\textbf{$N{=}10^5$}', rows))
facts.append('sweep builds sampled per N=100,1e3,1e4,1e5 (reps summed over seeds, linear scheme): %s' % b)
facts.append('sweep total builds per scheme: %d' % int(S[S.scheme == 'linear_probing'].reps.sum()))
# tail
T = pd.read_csv(os.path.join(R, 'tail.csv')); rows = []
tn = [('classical_short', 'Classical, short loop ($\\alpha{=}0.45$)'), ('classical_prescribed', 'Classical, prescribed loop ($\\alpha{=}0.45$)'),
      ('proposed_d3_K16_s4_a45', 'Proposed ($\\alpha{=}0.45$)'), ('proposed_d3_K16_s4_a80', 'Proposed ($\\alpha{=}0.80$)'), ('proposed_d3_K16_s4_a88', 'Proposed ($\\alpha{=}0.88$)')]
f = lambda x: format(int(x), ',').replace(',', '{,}')
for sch, lab in tn:
    c = []
    for n in (1000, 10000, 100000):
        r = T[(T.scheme == sch) & (T.N == n)].iloc[0]
        ev = r.guardTrips if sch.startswith('proposed') else r.rehashOrOverflowEvents
        c += [f(ev), f(r.worstSingleInsertIters)]
    rows.append(lab + ' & ' + ' & '.join(c))
hdr2 = ' & \\multicolumn{2}{c|}{$N{=}10^3$} & \\multicolumn{2}{c|}{$N{=}10^4$} & \\multicolumn{2}{c|}{$N{=}10^5$} \\\\ \\hline\n\\textbf{Scheme} & \\textbf{Events} & \\textbf{Worst} & \\textbf{Events} & \\textbf{Worst} & \\textbf{Events} & \\textbf{Worst}'
w('tail', tex('|l|cc|cc|cc|', hdr2, rows))
facts.append('tail builds: ' + str(T.groupby('N').builds.first().to_dict()))
# stash behaviour
rows = []; gtot = int(S[S.scheme == 'linear_probing'].reps.sum())
for a, sch in ((0.45, 'proposed_d3_K16_s4_a45'), (0.80, 'proposed_d3_K16_s4_a80'), (0.88, 'proposed_d3_K16_s4_a88')):
    g = S[S.scheme == sch]
    ph = lambda n: g[g.N == n].stashRoutedPerRun.mean() / n
    ov = g[g.N == 10**6].overflowPerRun.mean() / 10**6
    gt = int(round((g.guardTripsPerRun * g.reps).sum()))
    rows.append('$%.2f$ & %s & %s & %s & %s & %s of %s' % (a, sci(ph(1000)), sci(ph(10000)), sci(ph(10**6)), sci(ov) if ov > 0 else '$0$', f(gt), f(gtot)))
w('stash_behavior', tex('|c|c|c|c|c|c|', '\\textbf{$\\alpha$} & \\textbf{$\\hat p$, $N{=}10^3$} & \\textbf{$\\hat p$, $N{=}10^4$} & \\textbf{$\\hat p$, $N{=}10^6$} & \\textbf{Overflows} & \\textbf{Guard trips / builds}', rows))
for a, sch in ((0.45, 'proposed_d3_K16_s4_a45'), (0.80, 'proposed_d3_K16_s4_a80'), (0.88, 'proposed_d3_K16_s4_a88')):
    g = S[S.scheme == sch]
    gt = g[g.guardTripsPerRun > 0]
    facts.append('guard trips %s: total %.0f; sizes with trips: %s; worstLook max %s; maxLookProbes max=%d' % (sch, (g.guardTripsPerRun * g.reps).sum(), sorted(gt.N.unique().tolist()), '', g.maxLookProbes.max()))
# sat
Z = pd.read_csv(os.path.join(R, 'sat.csv')); rows = []
for a in (0.80, 0.88, 0.90):
    for mk in (4, 16, 64):
        z = Z[(np.isclose(Z.alpha, a)) & (Z.maxKicks == mk) & (Z.stash == 4)].sort_values('m')
        pl = z[z.m >= 4096]; plat = (pl.routedFrac * pl.N * pl.builds).sum() / (pl.N * pl.builds).sum()
        st = None
        for i in range(len(z)):
            rest = z.iloc[i:]
            if all(abs(r / plat - 1) <= 0.05 for r in rest.routedFrac) and plat > 0: st = int(z.iloc[i].m); break
        g = lambda m: z[z.m == m].routedFrac.iloc[0]
        rows.append('$%.2f$ & $%d$ & %s & %s & %s & %s & %s & %s' % (a, mk, sci(g(4)), sci(g(64)), sci(g(1024)), sci(g(4096)), sci(plat), ('$%d$' % st) if st else '--'))
w('sat', tex('|c|c|c|c|c|c|c|c|', '\\textbf{$\\alpha$} & \\textbf{$\\mathtt{MaxKicks}$} & \\textbf{$m{=}4$} & \\textbf{$m{=}64$} & \\textbf{$m{=}1024$} & \\textbf{$m{=}4096$} & \\textbf{Plateau} & \\textbf{Settles}', rows))
facts.append('sat: builds per size m: ' + str(Z[(Z.alpha < 0.81) & (Z.maxKicks == 4)][['m', 'builds']].drop_duplicates().set_index('m').builds.to_dict()))
# perf
P = pd.read_csv(os.path.join(R, 'perf/perf_summary.csv')); rows = []
pn = [('linear', 'Linear probing ($\\alpha{=}0.70$)'), ('chained', 'Chained ($\\alpha{=}1.00$)'), ('classical', 'Classical cuckoo ($\\alpha{=}0.45$)'), ('p45', 'Proposed ($\\alpha{=}0.45$)'), ('p80', 'Proposed ($\\alpha{=}0.80$)'), ('p88', 'Proposed ($\\alpha{=}0.88$)')]
def fz(x): return '%.3f' % x if abs(x) >= 0.0005 else '0'
for n, ns_ in ((10**5, '$10^5$'), (2 * 10**6, '$2\\times10^6$')):
    for sch, lab in pn:
        r = P[(P.scheme == sch) & (P.N == n)].iloc[0]
        rows.append('%s & %s & %.1f & %.0f & %.1f & %.2f & %s & %s & %.2f' % (lab, ns_, r.ns_per_lookup, r.cycles_per_lookup, r.instructions_per_lookup, r['L1-dcache-load-misses_per_lookup'], fz(r['LLC-load-misses_per_lookup']), fz(r['dTLB-load-misses_per_lookup']), r.ipc))
w('perf', tex('|l|c|c|c|c|c|c|c|c|', '\\textbf{Scheme} & \\textbf{$N$} & \\textbf{ns} & \\textbf{Cycles} & \\textbf{Instr.} & \\textbf{L1 miss} & \\textbf{LLC miss} & \\textbf{dTLB miss} & \\textbf{IPC}', rows))
# sens
E = pd.read_csv(os.path.join(R, 'sens.csv')); rows = []
A = E[E.block == 'A']; B = E[E.block == 'B']
def srow(a, mk, s, g):
    n = g.N.iloc[0]
    ph = g.routedFrac.mean(); ov = g.overflowEvents.mean() / n
    return ('$%.2f$ & $%d$ & $%d$ & %s & %s & $%.1f$ & $%d$ & $%d$ & $%d/%d$') % (a, mk, s, ('%.4f' % ph) if ph >= 0.001 else sci(ph, 2), sci(ov, 2) if ov < 0.01 else '%.4f' % ov, 1 / ov if ov > 0 else float('inf'),
        g.guardTrips.sum(), g.missing.sum(), g.maxInsIters.max(), mk * (1 + 20 * (s + 1)))
for a in (0.80, 0.88):
    for mk in (4, 8, 12):
        rows.append(srow(a, mk, 4, A[(np.isclose(A.alpha, a)) & (A.maxKicks == mk)]))
    for s in (1, 2, 4, 8):
        g = (B if s != 4 else A)
        rows.append(srow(a, 16, s, g[(np.isclose(g.alpha, a)) & (g.maxKicks == 16) & (g.stash == s)]))
    for mk in (24, 32, 48, 64):
        rows.append(srow(a, mk, 4, A[(np.isclose(A.alpha, a)) & (A.maxKicks == mk)]))
w('sensitivity', tex('|c|c|c|c|c|c|c|c|c|', '\\textbf{$\\alpha$} & \\textbf{$\\mathtt{MaxKicks}$} & \\textbf{$s$} & \\textbf{$\\hat p$} & \\textbf{Overflow rate} & \\textbf{Ins./ovf.} & \\textbf{Guard trips} & \\textbf{Missing} & \\textbf{Worst/bound}', rows))
facts.append('sens: rows A=%d B=%d, total missing=%d, achieved loads %s' % (len(A), len(B), E.missing.sum(), sorted(set(round(x, 7) for x in E.loadAchieved))))
facts.append('sens mean iters per insert by alpha: ' + str(E.groupby('alpha').meanItersPerInsert.agg(['min', 'max']).round(4).to_dict()))
# ratio overflow/arrival check
facts.append('sens overflow/arrivals ratio range: %.3f..%.3f (arrivals = routedFrac*N)' % (((E.overflowEvents) / (E.routedFrac * E.N)).min(), ((E.overflowEvents) / (E.routedFrac * E.N)).max()))
open(os.path.join(O, 'facts_main.txt'), 'w').write('\n'.join(facts) + '\n')
print('ok'); print('\n'.join(facts))
