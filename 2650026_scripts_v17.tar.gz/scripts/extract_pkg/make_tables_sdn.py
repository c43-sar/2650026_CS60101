#!/usr/bin/env python3
"""make_tables_sdn.py -- every SDN table and figure of the paper, from results_sdn/results.jsonl.
usage: python3 make_tables_sdn.py results_sdn/results.jsonl OUT_DIR      (needs pandas, matplotlib)
Linear axes only. Means over the 3 seeds."""
import sys, os, json, math, pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
SRC, OUT = sys.argv[1], sys.argv[2]
TD, FD = os.path.join(OUT, 'tables'), os.path.join(OUT, 'figs'); os.makedirs(TD, exist_ok=True); os.makedirs(FD, exist_ok=True)
rows = [json.loads(l) for l in open(SRC) if l.strip()]
for r in rows:
    s = r.get('stats') if isinstance(r.get('stats'), dict) else {}
    for k in ('insert_ns_n', 'insert_ns_sum', 'insert_ns_max', 'max_rebuild_ns', 'rebuilds', 'max_probes', 'resizes', 'resize_stw_ns', 'mem_peak_bytes', 'cells', 'max_ins_rounds', 'selfbench_hit_ns', 'selfbench_miss_ns', 'mem_bytes_per_flow', 'migrate_fail', 'rebuild_fail', 'guard_trips', 'peak_flows', 'first_fail_load', 'max_migrate_ns'):
        r['s_' + k] = s.get(k)
df = pd.DataFrame(rows)
df['mean_ins_ns'] = df.s_insert_ns_sum / df.s_insert_ns_n
def nf(fmt, x, scale=1.0):
    return '--' if (x is None or (isinstance(x, float) and math.isnan(x))) else fmt % (x * scale)
facts = []
def w(n, s): open(os.path.join(TD, n + '.tex'), 'w', encoding='utf-8', newline='\n').write(s)
def tab(spec, hdr, rows_, rs='\\columnwidth'):
    return '\\resizebox{%s}{!}{%%\n\\begin{tabular}{%s}\n\\hline\n%s \\\\ \\hline\n%s\\end{tabular}%%\n}\n' % (rs, spec, hdr, ''.join(r + ' \\\\ \\hline\n' for r in rows_))
f = lambda x: '--' if (x is None or (isinstance(x, float) and math.isnan(x))) else format(int(round(x)), ',').replace(',', '{,}')
NAME = {'stock': 'stock', 'hash2': 'hash2', 'classic': 'classic', 'linprobe': 'linprobe', 'chained': 'chained', 'proposed': '\\textbf{proposed}'}
ORDER = ['stock', 'hash2', 'classic', 'linprobe', 'chained', 'proposed']
pct = lambda x: '--' if (isinstance(x, float) and math.isnan(x)) else (('%.1f' % (100 * x)) if x >= 0.0005 else '0')
facts.append('rows %d; per tag: %s' % (len(df), df.tag.value_counts().to_dict()))
facts.append('all ok: %s; seeds %s' % (bool(df.ok.all()), sorted(df.seed.unique())))
# ------------- S1/S2 compare + trace (single topology)
AL = [0.5, 0.7, 0.8, 0.9, 0.95, 0.98]
c = df[(df.tag == 'compare') & (df.topo == 'single')]; t = df[(df.tag == 'trace') & (df.topo == 'single')]
rows_ = []
for b in ORDER:
    rows_.append(NAME[b] + ' & ' + ' & '.join(pct(c[(c.backend == b) & (c.alpha == a)].reject_frac.mean()) for a in AL))
w('compare', tab('|l|' + 'c|' * 6, '\\textbf{Backend} & ' + ' & '.join('$%.2f$' % a for a in AL), rows_))
rows_ = []
for b in ORDER:
    rows_.append(NAME[b] + ' & ' + ' & '.join(pct(c[(c.backend == b) & (c.alpha == a)].reject_frac.mean()) for a in (0.9, 0.95, 0.98)) + ' & ' + ' & '.join(pct(t[(t.backend == b) & (t.alpha == a)].reject_frac.mean()) for a in (0.9, 0.95, 0.98)))
w('trace', tab('|l|ccc|ccc|', ' & \\multicolumn{3}{c|}{random flows} & \\multicolumn{3}{c|}{MAWI flows} \\\\ \\hline\n\\textbf{Backend} & $0.90$ & $0.95$ & $0.98$ & $0.90$ & $0.95$ & $0.98$', rows_))
# topology comparison facts
cc = df[df.tag == 'compare']; tt = df[df.tag == 'trace']
for nm, g in (('compare', cc), ('trace', tt)):
    pv = g.pivot_table(index=['backend', 'alpha'], columns='topo', values='reject_frac', aggfunc='mean')
    facts.append('%s: max |linear4-tree| over backend,alpha = %.6f ; max |single-linear4| = %.4f' % (nm, (pv.linear4 - pv.tree).abs().max(), (pv.single - pv.linear4).abs().max()))
    facts.append('%s: F_per_switch single %s linear4 %s tree %s ; switches %s' % (nm, sorted(g[g.topo == 'single'].F_per_switch.unique())[:3], sorted(g[g.topo == 'linear4'].F_per_switch.unique())[:3], sorted(g[g.topo == 'tree'].F_per_switch.unique())[:3], g.groupby('topo').n_switches.first().to_dict()))
pv = pd.concat([c.pivot_table(index='backend', columns='alpha', values='reject_frac'), t.pivot_table(index='backend', columns='alpha', values='reject_frac')], keys=['syn', 'trace'])
facts.append('max |synthetic - MAWI| rejection (single): %.4f' % max((c.pivot_table(index='backend', columns='alpha', values='reject_frac') - t.pivot_table(index='backend', columns='alpha', values='reject_frac')).abs().max()))
# ------------- S3 switch-side metrics at 0.95 and 0.90
rows_ = []
for a in (0.9, 0.95):
    g = c[c.alpha == a]
    for b in ORDER:
        h = g[g.backend == b]
        mx = h.s_insert_ns_max.max()
        rows_.append('$%.2f$ & %s & %s & %s & %s & %s & %s & %s & %s' % (a, NAME[b], pct(h.reject_frac.mean()), nf('%.2f', h.mean_ins_ns.mean(), 1e-3), (nf('%.1f', mx, 1e-3) if (mx != mx or mx < 1e5) else f(mx / 1e3)), nf('%.1f', h.s_rebuilds.mean()), f(h.s_max_probes.max()), (nf('%.0f', h.s_selfbench_hit_ns.mean()) + ' / ' + nf('%.0f', h.s_selfbench_miss_ns.mean())), nf('%.1f', h.s_mem_peak_bytes.mean() / max(1, h.accepted.mean()))))
w('switch', tab('|c|l|c|c|c|c|c|c|c|', '\\textbf{$\\alpha$} & \\textbf{Backend} & \\textbf{Rejected \\%} & \\textbf{Mean insert $\\mu$s} & \\textbf{Max insert $\\mu$s} & \\textbf{Rebuilds} & \\textbf{Max probes/lookup} & \\textbf{Hit/miss ns} & \\textbf{Peak bytes/flow}', rows_))
facts.append('switch table: single topology compare rows, switch-side counters (stats): insert_ns_*; max_probes = most cells read by one lookup; selfbench_* = in-switch lookup self-benchmark; peak bytes per accepted flow = mem_peak_bytes/accepted')
for a in (0.9, 0.95):
    g = c[(c.alpha == a)]
    facts.append('alpha %.2f max insert us by backend: %s' % (a, (g.groupby('backend').s_insert_ns_max.max() / 1000).round(1).to_dict()))
    facts.append('alpha %.2f max_probes by backend: %s ; rebuilds mean %s' % (a, g.groupby('backend').s_max_probes.max().to_dict(), g.groupby('backend').s_rebuilds.mean().round(2).to_dict()))
    facts.append('alpha %.2f flow_mods_per_s mean by backend: %s ; batch_ms_max mean %s' % (a, g.groupby('backend').flow_mods_per_s.mean().round(0).to_dict(), g.groupby('backend').batch_ms_max.mean().round(2).to_dict()))
pr = df[df.probe.map(lambda p: isinstance(p, dict) and (p['during']['n'] > 0 or p['idle']['n'] > 0))]
facts.append('probe stream: rows with a probe record %d ; rows with any sample %d (tags %s); during-install sample counts %s' % (df.probe.map(lambda p: isinstance(p, dict)).sum(), len(pr), pr.tag.value_counts().to_dict(), sorted(pr.probe.map(lambda p: p['during']['n']).tolist())[-5:]))
# ------------- S4 sweeps
def sw(tag, col, vals, lab):
    g = df[df.tag == tag]; r_ = []
    for v in vals:
        h = g[g[col] == v]
        r_.append('%s & %s & %s & %s' % (lab(v), pct(h[h.alpha == 0.9].reject_frac.mean()), pct(h[h.alpha == 0.95].reject_frac.mean()), f(h[h.alpha == 0.95].flow_mods_per_s.mean())))
    return r_
hdr = '\\textbf{Value} & \\textbf{Rejected \\%, $\\alpha{=}0.90$} & \\textbf{Rejected \\%, $\\alpha{=}0.95$} & \\textbf{flow\\_mods/s, $\\alpha{=}0.95$}'
w('sweep_d', tab('|c|c|c|c|', hdr, sw('sweep_d', 'd', [2, 3, 4, 5, 6], lambda v: '$d{=}%d$' % v)))
w('sweep_K', tab('|c|c|c|c|', hdr, sw('sweep_K', 'K', [1, 2, 4, 8, 16, 32, 64], lambda v: '$K{=}%d$' % v)))
w('sweep_s', tab('|c|c|c|c|', hdr, sw('sweep_s', 's', [0, 1, 2, 4, 8], lambda v: '$s{=}%d$' % v)))
w('sweep_m', tab('|c|c|c|c|', hdr, sw('sweep_m', 'cells', [1024, 2048, 4096, 8192], lambda v: '%s cells' % f(v))))
g = df[df.tag == 'sweep_cycle']; r_ = []
for md in (0, 1, 2, 3):
    for K in (4, 16):
        h = g[(g.cycle == md) & (g.K == K)]
        r_.append('$%d$ & $%d$ & %s & %s & %s & %s' % (md, K, pct(h[h.alpha == 0.9].reject_frac.mean()), pct(h[h.alpha == 0.95].reject_frac.mean()), pct(h[h.alpha == 0.98].reject_frac.mean()), f(h[h.alpha == 0.95].flow_mods_per_s.mean())))
w('sweep_cycle', tab('|c|c|c|c|c|c|', '\\textbf{\\texttt{OFT\\_CYCLE}} & \\textbf{$K$} & \\textbf{Rej.\\ \\% $0.90$} & \\textbf{Rej.\\ \\% $0.95$} & \\textbf{Rej.\\ \\% $0.98$} & \\textbf{flow\\_mods/s, $0.95$}', r_))
# ------------- S6 ceiling
cs = {3: 0.91794, 4: 0.97677, 5: 0.99244}
AC = [0.88, 0.90, 0.92, 0.94, 0.96, 0.97, 0.98, 0.99]
r_ = []
for a in AC:
    cel = []
    for tag in ('ceiling_d', 'ceiling_trace'):
        g = df[df.tag == tag]
        for d in (3, 4, 5): cel.append(pct(g[(g.d == d) & (g.alpha == a)].reject_frac.mean()))
    r_.append('$%.2f$ & ' % a + ' & '.join(cel))
r_.append('$c^*_d$ (offline) & $0.918$ & $0.977$ & $0.992$ & $0.918$ & $0.977$ & $0.992$')
w('ceiling', tab('|c|ccc|ccc|', ' & \\multicolumn{3}{c|}{random flows} & \\multicolumn{3}{c|}{MAWI flows} \\\\ \\hline\n\\textbf{$\\alpha$} & $d{=}3$ & $d{=}4$ & $d{=}5$ & $d{=}3$ & $d{=}4$ & $d{=}5$', r_))
for tag in ('ceiling_d', 'ceiling_trace'):
    g = df[df.tag == tag]
    for d in (3, 4, 5):
        h = g[g.d == d]; ok_ = h.groupby('alpha').rejected.sum(); first = ok_[ok_ > 0].index.min()
        facts.append('%s d=%d: cells %s, first alpha with a rejection in any seed %s, highest alpha with none %s' % (tag, d, h.cells.iloc[0], first, ok_[ok_ == 0].index.max()))
# ------------- S7 resize
def rs_row(lab, h):
    return '%s & %s & %s & %s & %s & %s' % (lab, pct(h.reject_frac.mean()), '%.1f' % h.batch_ms_max.max(), '%.1f' % (h.s_resize_stw_ns.max() / 1e6) if h.s_resize_stw_ns.max() > 0 else '0', '%.1f' % h.s_resizes.mean(), f(h.s_cells.mean()))
r_ = []
for tag, nm in (('resize', ''), ('resize_big', ' (large)')):
    g = df[df.tag == tag]
    for a in sorted(g.alpha.unique()):
        h0 = g[(g.alpha == a)]
        for md, lab in ((0, 'no resize'), (1, 'incremental'), (2, 'stop-the-world')):
            hh = h0[h0.resize == md]
            if md and tag == 'resize': hh = hh[hh.alpha_hi_spec == '0.85']
            if len(hh): r_.append('%s%s, $%.1f\\times$ & %s' % (lab, nm, a, rs_row('', hh).split(' & ', 1)[1]))
w('resize', tab('|l|c|c|c|c|c|', '\\textbf{Mode, offered load} & \\textbf{Rejected \\%} & \\textbf{Max batch ms} & \\textbf{Stop-the-world ms} & \\textbf{Resizes} & \\textbf{Final cells}', r_))
facts.append('resize rows: tag resize alpha_hi 0.85 only in table; other alpha_hi (0.7, 0.9) rejections all zero: %s' % df[(df.tag == 'resize') & (df.resize > 0)].groupby(['resize', 'alpha_hi_spec']).rejected.sum().to_dict())
r_ = []
for tag, nm in (('resize_d', 'random'), ('resize_trace', 'MAWI')):
    g = df[df.tag == tag]
    for d in (3, 4, 5):
        h0 = g[(g.d == d) & (g.resize == 0)]
        r_.append('%s & $%d$ & off & %s & %s & %s & %s' % (nm, d, pct(h0.reject_frac.mean()), '%.1f' % h0.batch_ms_max.max(), '0', f(h0.s_cells.mean())))
        for m in ('auto:0.01', 'auto:0.02', 'auto:0.05', 'auto:0.10'):
            h = g[(g.d == d) & (g.alpha_hi_spec == m) & (g.resize == 1)]
            r_.append('%s & $%d$ & $c^*_d-%s$ & %s & %s & %.1f & %s' % (nm, d, m.split(':')[1], pct(h.reject_frac.mean()), '%.1f' % h.batch_ms_max.max(), h.s_resizes.mean(), f(h.s_cells.mean())))
w('resize_d', tab('|l|c|c|c|c|c|c|', '\\textbf{Flows} & \\textbf{$d$} & \\textbf{Trigger} & \\textbf{Rejected \\%} & \\textbf{Max batch ms} & \\textbf{Resizes} & \\textbf{Final cells}', r_))
facts.append('resize_d/resize_trace: offered load 2.0x of 2520 cells; rejections with resize: %s' % df[(df.tag.isin(['resize_d', 'resize_trace'])) & (df.resize == 1)].rejected.sum())
# ------------- S9 reactive
def rx(tag):
    g = df[df.tag == tag]; r_ = []
    for b in ORDER:
        cell = []
        for tp in ('tree', 'ring6'):
            for a in (0.8, 0.9, 0.95):
                h = g[(g.backend == b) & (g.topo == tp) & (g.alpha == a)]
                cell.append('%s (%.1f)' % (f(h.rejected.mean()), 100 * h.slowpath_frac.mean()))
        r_.append(NAME[b] + ' & ' + ' & '.join(cell))
    return tab('|l|ccc|ccc|', ' & \\multicolumn{3}{c|}{tree (4 switches)} & \\multicolumn{3}{c|}{6-switch ring} \\\\ \\hline\n\\textbf{Backend} & $0.80$ & $0.90$ & $0.95$ & $0.80$ & $0.90$ & $0.95$', r_, rs='\\linewidth')
w('reactive', rx('reactive')); w('reactive_trace', rx('reactive_trace'))
facts.append('reactive: pkts_delivered is %s in every reactive row (field not usable); n_flows mean tree %.0f ring %.0f' % (df[df.tag == 'reactive'].pkts_delivered.unique().tolist(), df[(df.tag == 'reactive') & (df.topo == 'tree')].n_flows.mean(), df[(df.tag == 'reactive') & (df.topo == 'ring6')].n_flows.mean()))
# ------------- S10 churn
df['variant'] = df.apply(lambda r: r.backend + (' d=%d' % r.d if r.backend == 'proposed' else '') + (' +rs' if r.resize else ''), axis=1)
V = [('stock', 'stock'), ('hash2', 'hash2'), ('classic', 'classic'), ('linprobe', 'linprobe'), ('chained', 'chained'), ('proposed d=3', '\\textbf{proposed} $d{=}3$'), ('proposed d=4', '\\textbf{proposed} $d{=}4$'), ('proposed d=5', '\\textbf{proposed} $d{=}5$'), ('proposed d=3 +rs', '\\textbf{proposed} $d{=}3$ + resize')]
r_ = []
for v, lab in V:
    cell = []
    for tag in ('churn', 'churn_trace'):
        g = df[df.tag == tag]
        for a in (0.7, 0.9, 0.95):
            cell.append(pct(g[(g.variant == v) & (g.alpha == a)].reject_frac.mean()))
    r_.append(lab + ' & ' + ' & '.join(cell))
w('churn', tab('|l|ccc|ccc|', ' & \\multicolumn{3}{c|}{exponential lifetimes (mean 5~s)} & \\multicolumn{3}{c|}{MAWI residence times ($T{=}15$~s, cap 30~s)} \\\\ \\hline\n\\textbf{Variant} & $0.70$ & $0.90$ & $0.95$ & $0.70$ & $0.90$ & $0.95$', r_))
r_ = []
for v, lab in V:
    cell = []
    for tag in ('churn',):
        g = df[df.tag == tag]
        for a in (0.7, 0.9, 0.95):
            h = g[(g.variant == v) & (g.alpha == a)]
            cell.append('%.2f / %.2f' % (h.occ_mean_alpha.mean(), h.occ_max_alpha.max()))
    r_.append(lab + ' & ' + ' & '.join(cell))
w('churn_occ', tab('|l|c|c|c|', '\\textbf{Variant} & $0.70$ & $0.90$ & $0.95$', r_))
g = df[df.tag == 'churn']
facts.append('churn: cells %s mean lifetime %s s offered alpha 0.7/0.9/0.95 arrivals %s ; duration %.1f s warmup %.1f s' % (g.cells.unique().tolist(), g.churn_mean.unique().tolist(), g.groupby('alpha').arrivals.mean().round(0).to_dict(), g.churn_duration.mean(), g.churn_warmup.mean()))
facts.append('churn_trace: cap %s ; trace %s; arrivals %s' % (df[df.tag == 'churn_trace'].churn_cap.unique().tolist(), df[df.tag == 'churn_trace'].trace.unique().tolist(), df[df.tag == 'churn_trace'].groupby('alpha').arrivals.mean().round(0).to_dict()))
facts.append('churn barrier p99 ms range %.3f..%.3f' % (g.barrier_p99_ms.min(), g.barrier_p99_ms.max()))
open(os.path.join(OUT, 'facts_sdn.txt'), 'w').write('\n'.join(facts) + '\n')
# ------------- figures (linear axes only)
PAL = {'stock': ('#52514e', 'x', ':'), 'hash2': ('#e87ba4', 's', '--'), 'classic': ('#eb6834', '^', '-.'), 'linprobe': ('#1baf7a', 'v', '--'), 'chained': ('#6250d6', 'D', ':'), 'proposed': ('#2a78d6', 'o', '-')}
plt.rcParams.update({'font.size': 8, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.grid': True, 'grid.color': '#e4e3df', 'grid.linewidth': 0.5, 'axes.axisbelow': True, 'pdf.fonttype': 42})
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.6), sharey=True)
for k, (src, ttl) in enumerate(((c, 'random flows'), (t, 'MAWI flows'))):
    for b in ORDER:
        s_ = src[src.backend == b].groupby('alpha').reject_frac.mean() * 100
        ax[k].plot(s_.index, s_.values, color=PAL[b][0], marker=PAL[b][1], ls=PAL[b][2], lw=1.6 if b == 'proposed' else 1.1, ms=4, label=b)
    ax[k].set_title(ttl, fontsize=8); ax[k].set_xlabel('offered load $\\alpha$')
ax[0].set_ylabel('flow_mods rejected (%)'); ax[1].legend(frameon=False, fontsize=7, loc='upper left')
fig.tight_layout(); fig.savefig(os.path.join(FD, 'reject_vs_load.pdf')); plt.close(fig)
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.6), sharey=True)
COL = {3: '#2a78d6', 4: '#eb6834', 5: '#1baf7a'}; MK = {3: 'o', 4: '^', 5: 's'}
for k, (tag, ttl) in enumerate((('ceiling_d', 'random flows'), ('ceiling_trace', 'MAWI flows'))):
    g = df[df.tag == tag]
    for d in (3, 4, 5):
        s_ = g[g.d == d].groupby('alpha').reject_frac.mean() * 100
        ax[k].plot(s_.index, s_.values, color=COL[d], marker=MK[d], lw=1.4, ms=4, label='d=%d' % d)
        ax[k].axvline(cs[d], color=COL[d], lw=0.8, ls=':')
    ax[k].set_title(ttl, fontsize=8); ax[k].set_xlabel('offered load $\\alpha$')
ax[0].set_ylabel('flow_mods rejected (%)'); ax[1].legend(frameon=False, fontsize=7, loc='upper left', title='dotted: $c^*_d$', title_fontsize=7)
fig.tight_layout(); fig.savefig(os.path.join(FD, 'ceiling.pdf')); plt.close(fig)
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.6), sharey=True)
CV = [('stock', 'stock'), ('hash2', 'hash2'), ('classic', 'classic'), ('linprobe', 'linprobe'), ('chained', 'chained'), ('proposed d=3', 'proposed d=3'), ('proposed d=5', 'proposed d=5'), ('proposed d=3 +rs', 'proposed d=3 + resize')]
CS = {'stock': PAL['stock'], 'hash2': PAL['hash2'], 'classic': PAL['classic'], 'linprobe': PAL['linprobe'], 'chained': PAL['chained'], 'proposed d=3': ('#2a78d6', 'o', '-'), 'proposed d=5': ('#184f95', 's', '-'), 'proposed d=3 +rs': ('#e34948', 'P', '-')}
for k, (tag, ttl) in enumerate((('churn', 'exponential lifetimes (mean 5 s)'), ('churn_trace', 'MAWI residence times (T=15 s, cap 30 s)'))):
    g = df[df.tag == tag]
    for v, lab in CV:
        s_ = g[g.variant == v].groupby('alpha').reject_frac.mean() * 100
        ax[k].plot(s_.index, s_.values, color=CS[v][0], marker=CS[v][1], ls=CS[v][2], lw=1.2, ms=4, label=lab)
    ax[k].set_title(ttl, fontsize=8); ax[k].set_xlabel('offered load $\\alpha$'); ax[k].set_xticks([0.7, 0.9, 0.95])
ax[0].set_ylabel('flow_mods rejected (%)'); ax[1].legend(frameon=False, fontsize=6.5, loc='upper left')
fig.tight_layout(); fig.savefig(os.path.join(FD, 'churn.pdf')); plt.close(fig)
print('\n'.join(facts))
