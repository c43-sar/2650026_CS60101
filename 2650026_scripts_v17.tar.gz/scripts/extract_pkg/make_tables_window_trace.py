#!/usr/bin/env python3
"""make_tables_window_trace.py -- the two tables that are not made by the other generators:
  window_nb.tex     observed Pr[X>s] against binomial, moment-matched negative binomial and the Cantelli bound (s=4), from report_window.txt
  trace_stats.tex   whole-trace churn model, from the report of the flow-sampled pass (whole_stats_sample8.txt)
usage: python3 make_tables_window_trace.py RESULTS_FULL_DIR WHOLE_STATS_FILE OUT_DIR       (either input may be '-' to skip it)
Negative binomial: mean mu = meanPerWindow, variance D*mu with D = the measured dispersion index (needs D>1): r = mu/(D-1), success probability 1/D.
Cantelli bound: sigma^2/(sigma^2+(s-mu)^2) with sigma^2 = D*mu, only for mu < s."""
import sys, os, re
from math import lgamma, exp, log
R, T, O = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(O, exist_ok=True)
def sci(x):
    if x < 0.01: e = int('%d' % __import__('math').floor(__import__('math').log10(x))); return '$%.2f\\times10^{%d}$' % (x / 10 ** e, e)
    return ('%.4f' % x) if x < 0.1 else ('%.3f' % x)
def nb_tail(mu, D, s):                      # P(X > s), X ~ NB(r, p) with mean mu and variance D*mu
    r = mu / (D - 1.0); p = 1.0 / D; q = 1.0 - p; cdf = 0.0
    for k in range(s + 1): cdf += exp(lgamma(k + r) - lgamma(r) - lgamma(k + 1) + r * log(p) + k * log(q))
    return 1.0 - cdf
if R != '-':
    t = open(os.path.join(R, 'report_window.txt')).read(); rows = []; s = 4
    for m in re.finditer(r'\[WINDOW alpha=([\d.]+) seg=(\w+)\s+W=(\d+)\] windows=\d+ phat=[\d.]+ meanPerWindow=([\d.]+) disp=([\d.]+) obsFracOver=([\d.]+) binom=([\d.]+) chernoff=[\d.]+', t):
        al, seg, W, mu, D, obs, bi = float(m.group(1)), m.group(2), int(m.group(3)), float(m.group(4)), float(m.group(5)), float(m.group(6)), float(m.group(7))
        if W not in (64, 256, 1024): continue
        nb = nb_tail(mu, D, s); sg = D * mu
        cant = '%.3f' % (sg / (sg + (s - mu) ** 2)) if mu < s else '--'
        f = lambda x: sci(x) if x < 0.01 else '%.3f' % x
        rows.append('$%.2f$ & %s & $%d$ & %s & %s & %s & %s' % (al, 'all' if seg == 'all' else 'last fifth', W, f(obs), f(bi), f(nb), cant))
    open(os.path.join(O, 'window_nb.tex'), 'w', newline='\n').write('\\begin{tabular}{|c|l|c|c|c|c|c|}\n\\hline\n$\\alpha$ & Segment & $W$ & Observed & Binomial & Neg.\\ binomial & Cantelli \\\\ \\hline\n' + ''.join(r + ' \\\\ \\hline\n' for r in rows) + '\\end{tabular}\n')
if T != '-':
    t = open(T, errors='replace').read(); rows = []
    for m in re.finditer(r'T=(\d+) s: entries (\d+)\s+lambda ([\d.e+]+) /s\s+T_res mean ([\d.]+) median [\d.]+ p90 [\d.]+ p99 [\d.]+ max [\d.]+ s\s+lambda\*E\[T_res\] [\d.e+]+\s+occupancy per second after 61 s warm-up: mean (\d+)\s+p99 (\d+)\s+peak (\d+)', t):
        T_, ent, lam, tm, mo, p99, pk = m.groups()
        g = lambda v: format(int(v), ',').replace(',', '{,}')
        lm = '%.2e' % float(lam); mant, ex = lm.split('e')
        rows.append('$%s$ & $%s$ & $%.2f\\times10^{%d}$ & $%s$ & $%s$ & $%s$ & $%s$' % (T_, g(ent), float(mant), int(ex), tm, g(mo), g(p99), g(pk)))
    open(os.path.join(O, 'trace_stats.tex'), 'w', newline='\n').write('\\begin{tabular}{|c|c|c|c|c|c|c|}\n\\hline\n\\textbf{$T$ (s)} & \\textbf{Entries} & \\textbf{$\\lambda$ (/s)} & \\textbf{$\\mathbb{E}[T_{\\mathrm{res}}]$ (s)} & \\textbf{Mean occ.} & \\textbf{$p_{99}$ occ.\\ (ub)} & \\textbf{Peak (ub)} \\\\ \\hline\n' + ''.join(r + ' \\\\ \\hline\n' for r in rows) + '\\end{tabular}\n')
