#!/usr/bin/env python3
"""prose_values.py -- recompute from the raw run files the numbers that the paper quotes in its text and that are not in a table.
Used by extract_results.py; can also be run alone:
    python3 prose_values.py --full results_full --dscan results_dscan --sdn results_sdn --trace flows_stats.txt whole_stats_sample8.txt --out text_values.csv
Every row: id, what, value, unit, source file(s), method.  Nothing is typed by hand except the formula parameters of the journal size."""
import os, re, json, argparse, glob
import numpy as np, pandas as pd

ROWS = []
def add(i, what, value, unit, source, method):
    if isinstance(value, (np.floating, float)): value = float(value)
    elif isinstance(value, (np.integer,)): value = int(value)
    ROWS.append(dict(id=i, what=what, value=value, unit=unit, source=source, method=method))

def rd(path):
    return pd.read_csv(path) if os.path.exists(path) else None

def benchmarks(R):
    sw, sl = rd(f'{R}/sweep.csv'), rd(f'{R}/sweep_latency.csv')
    if sw is not None and sl is not None:
        add('sweep.rows', 'rows of the size sweep (counting build)', len(sw), 'rows', 'sweep.csv', 'row count')
        add('sweep.sizes', 'distinct sizes N in the sweep', sw.N.nunique(), 'sizes', 'sweep.csv', 'distinct N')
        add('sweep.missing_max', 'largest number of keys not found in any row', sw.missingMax.max(), 'keys', 'sweep.csv', 'max of missingMax')
        for col, nm in (('insItersPerOp', 'insert'), ('lookItersPerOp', 'lookup')):
            g = sw.groupby(['scheme', 'alpha', 'N'])[col].mean().reset_index()
            a = g[g.N == 100000].set_index(['scheme', 'alpha'])[col]; b = g[g.N == 1000000].set_index(['scheme', 'alpha'])[col]
            add(f'sweep.iters_1e5_vs_1e6.{nm}', f'largest |mean {nm} iterations at 1e5 - at 1e6| over schemes', (a - b).abs().max(), 'iterations', 'sweep.csv', 'seed means, max over scheme/load')
        prop = sl[sl.scheme.str.startswith('proposed')]
        for (s, al), g in prop.groupby(['scheme', 'alpha']):
            g = g[(g.N >= 100000) & (g.N <= 1000000)].groupby('N')[['insNsPerOp', 'lookNsPerOp']].mean().reset_index()
            for c, nm in (('lookNsPerOp', 'lookup'), ('insNsPerOp', 'insert')):
                x = g.N.values / 1e5; y = g[c].values
                k, ic = np.polyfit(x, y, 1); r2 = 1 - ((y - (k * x + ic)) ** 2).sum() / ((y - y.mean()) ** 2).sum()
                add(f'sweep.slope.{nm}.a{al}', f'least-squares slope of {nm} latency over 1e5<=N<=1e6, {s}', k, 'ns per 1e5 keys', 'sweep_latency.csv', 'seed means, 10 sizes')
                add(f'sweep.r2.{nm}.a{al}', f'R^2 of that fit, {s}', r2, '', 'sweep_latency.csv', '1-SSE/SST')
        for (s, al), g in sl.groupby(['scheme', 'alpha']):
            m = g.groupby('N')[['lookNsPerOp', 'cells']].mean().reset_index()
            pl = m[(m.N >= 100) & (m.N <= 10000)].lookNsPerOp.mean()
            c = m[(m.lookNsPerOp > 1.5 * pl) & (m.N > 10000)]
            if len(c):
                n0 = int(c.iloc[0].N); cells = float(g[g.N == n0].cells.iloc[0])
                add(f'sweep.cache_cross.{s}', f'first N with lookup latency > 1.5x plateau (mean over 100<=N<=1e4), {s}', n0, 'keys', 'sweep_latency.csv', 'first N>1e4')
                add(f'sweep.cache_cross_MB.{s}', f'array size (cells x 9 B) at that N, {s}', cells * 9 / 1e6, 'MB', 'sweep_latency.csv', 'cells*9/1e6')
                add(f'sweep.cache_cross_MiB.{s}', f'array size (cells x 9 B) at that N, {s}', cells * 9 / 2 ** 20, 'MiB', 'sweep_latency.csv', 'cells*9/2^20')
        mm = sw.merge(sl, on=['scheme', 'alpha', 'N', 'seed'], suffixes=('_c', '_l')); mm = mm[mm.N >= 1000]
        mm['ins'] = (mm.insNsPerOp_c / mm.insNsPerOp_l - 1) * 100; mm['look'] = (mm.lookNsPerOp_c / mm.lookNsPerOp_l - 1) * 100
        for s, g in mm.groupby('scheme'):
            add(f'sweep.overhead.insert.{s}', f'median instrumentation overhead on insertion (N>=1000), {s}', g.ins.median(), '%', 'sweep.csv, sweep_latency.csv', 'counting vs clean build')
            add(f'sweep.overhead.lookup.{s}', f'median instrumentation overhead on lookup (N>=1000), {s}', g.look.median(), '%', 'sweep.csv, sweep_latency.csv', 'counting vs clean build')
        cv = []
        for _, g in sl.groupby(['scheme', 'alpha', 'N']):
            for c in ('insNsPerOp', 'lookNsPerOp'):
                v = g[c].values
                if len(v) > 1 and v.mean() > 0: cv.append(v.std(ddof=1) / v.mean() * 100)
        cv = np.array(cv)
        add('sweep.cv.median', 'coefficient of variation of the clean latencies over seeds, median', np.median(cv), '%', 'sweep_latency.csv', 'sample sd/mean per scheme,load,N,operation')
        add('sweep.cv.p90', '... 90th percentile', np.percentile(cv, 90), '%', 'sweep_latency.csv', 'same')
        add('sweep.cv.max', '... maximum', cv.max(), '%', 'sweep_latency.csv', 'same')
    sat = rd(f'{R}/sat.csv')
    if sat is not None:
        for (al, k), g in sat[sat.m >= 4096].groupby(['alpha', 'maxKicks']):
            add(f'sat.plateau_iters.a{al:.2f}.K{k}', f'mean iterations per insertion at the plateau (m>=4096), alpha={al:.2f}, MaxKicks={k}', g.meanItersPerInsert.mean(), 'iterations', 'sat.csv', 'mean over m>=4096')
        for al in (0.8, 0.88, 0.9):
            g = sat[np.isclose(sat.alpha, al) & (sat.maxKicks == 64)]
            if len(g):
                add(f'sat.K64.peak.a{al}', f'largest routing probability, MaxKicks=64, alpha={al}', g.routedFrac.max(), '', 'sat.csv', 'max over m')
                add(f'sat.K64.peak_m.a{al}', '... at table size m', int(g.loc[g.routedFrac.idxmax(), 'm']), 'buckets', 'sat.csv', 'argmax')
                add(f'sat.K64.last.a{al}', f'routing probability at the largest m, MaxKicks=64, alpha={al}', g.routedFrac.iloc[-1], '', 'sat.csv', 'last row')
        g = sat[np.isclose(sat.alpha, 0.8) & (sat.maxKicks == 64) & (sat.m >= 512)]
        arr = (g.routedFrac * g.N * g.builds)
        add('sat.K64.a0.80.arrivals_min', 'stash arrivals per size, MaxKicks=64, alpha=0.80, m>=512, minimum', arr.min(), 'arrivals', 'sat.csv', 'routedFrac*N*builds')
        add('sat.K64.a0.80.arrivals_max', '... maximum', arr.max(), 'arrivals', 'sat.csv', 'same')
    se = rd(f'{R}/sens.csv')
    if se is not None:
        add('sens.builds', 'builds of the sensitivity sweep', len(se), 'builds', 'sens.csv', 'row count')
        r = se.overflowEvents * se.stash / (se.routedFrac * se.N)
        add('sens.overflow_ratio_min', 'overflow events x s / stash arrivals, minimum over builds', r.min(), '', 'sens.csv', 'overflowEvents*stash/(routedFrac*N)')
        add('sens.overflow_ratio_max', '... maximum', r.max(), '', 'sens.csv', 'same')
        for al in (0.8, 0.88):
            g = se[np.isclose(se.alpha, al) & (se.stash == 4)].groupby('maxKicks').routedFrac.agg(['min', 'max'])
            ks = sorted(g.index); ok = all(g.loc[ks[i], 'min'] > g.loc[ks[i + 1], 'max'] for i in range(len(ks) - 1))
            add(f'sens.nonoverlap.a{al}', f'seed ranges of the routing probability do not overlap between neighbouring MaxKicks (s=4), alpha={al}', bool(ok), 'bool', 'sens.csv', 'min of k > max of k+1')
    rc = rd(f'{R}/rehashcost.csv')
    return sw, rc

def rehashcost(R, D):
    parts = []
    p3 = rd(f'{R}/rehashcost.csv')
    if p3 is not None: parts.append(p3.assign(d=3))
    for d in (4, 5):
        p = rd(f'{D}/rehashcost_d{d}.csv') if D else None
        if p is not None: parts.append(p.assign(d=d))
    if not parts: return
    a = pd.concat(parts); a['ratio'] = a.rebuildNs / a.rehashStashNs
    g = a.groupby(['d', 'alpha'])
    add('rehashcost.events', 'timed RehashStash events, all d and loads', len(a), 'events', 'rehashcost*.csv', 'row count')
    for (d, al), n in g.size().items():
        if n < 150: add(f'rehashcost.events.d{d}.a{al}', f'events at d={d}, alpha={al} (fewer than 150)', int(n), 'events', 'rehashcost*.csv', 'row count')
    add('rehashcost.stash_us_median_min', 'median RehashStash time over (d,alpha), smallest', g.rehashStashNs.median().min() / 1e3, 'us', 'rehashcost*.csv', 'median per group')
    add('rehashcost.stash_us_median_max', '... largest', g.rehashStashNs.median().max() / 1e3, 'us', 'rehashcost*.csv', 'median per group')
    add('rehashcost.stash_us_max', 'longest RehashStash over all events', a.rehashStashNs.max() / 1e3, 'us', 'rehashcost*.csv', 'max')
    add('rehashcost.rounds_median_min', 'median RehashStash rounds, smallest group', g.rehashStashRounds.median().min(), 'rounds', 'rehashcost*.csv', 'median per group')
    add('rehashcost.rounds_median_max', '... largest group', g.rehashStashRounds.median().max(), 'rounds', 'rehashcost*.csv', 'median per group')
    add('rehashcost.rebuild_ms_median_min', 'median full rebuild time, smallest group', g.rebuildNs.median().min() / 1e6, 'ms', 'rehashcost*.csv', 'median per group')
    add('rehashcost.rebuild_ms_median_max', '... largest group', g.rebuildNs.median().max() / 1e6, 'ms', 'rehashcost*.csv', 'median per group')
    add('rehashcost.rebuild_rounds_median_min', 'median rebuild rounds, smallest group', g.rebuildRounds.median().min(), 'rounds', 'rehashcost*.csv', 'median per group')
    add('rehashcost.rebuild_rounds_median_max', '... largest group', g.rebuildRounds.median().max(), 'rounds', 'rehashcost*.csv', 'median per group')
    add('rehashcost.ratio_median_min', 'median rebuild/RehashStash time ratio, smallest group', g.ratio.median().min(), '', 'rehashcost*.csv', 'median per group (the report files give 3590 for d=3, alpha=0.80, from their own quantile rule)')
    add('rehashcost.ratio_median_max', '... largest group', g.ratio.median().max(), '', 'rehashcost*.csv', 'median per group')
    add('rehashcost.ratio_min', 'smallest ratio over all events', a.ratio.min(), '', 'rehashcost*.csv', 'min')
    add('rehashcost.ratio_max', 'largest ratio over all events', a.ratio.max(), '', 'rehashcost*.csv', 'max')
    add('rehashcost.nesting_max', 'largest extra nesting depth inside RehashStash', a.extraNestingDepth.max(), 'levels', 'rehashcost*.csv', 'max')
    a3 = a[a.d == 3]
    add('rehashcost.d3.stash_us_over_load', 'median RehashStash time at d=3, alpha 0.80/0.88/0.90', '/'.join('%.2f' % (v / 1e3) for v in a3.groupby('alpha').rehashStashNs.median()), 'us', 'rehashcost.csv', 'median per load')

def rehash_classical(R):
    p = f'{R}/report_rehash_classical.txt'
    if not os.path.exists(p): return
    t = open(p).read(); rows = []
    for m in re.finditer(r'\[REHASHCLASSICAL (\w+) maxLoop=(\d+)\] alpha=([\d.]+) seed=(\d) rehashes=(\d+) outermost=(\d+) nested=(\d+) nesting=(\d+) .*?totalInsertSec=([\d.]+) outermostRehashShare=([\d.]+) maxSingleInsertMs=([\d.]+) maxOutermostInclMs=([\d.]+) maxExclMs=([\d.]+)', t):
        v = m.groups(); rows.append(dict(variant=v[0], alpha=float(v[2]), seed=int(v[3]), rehashes=int(v[4]), outermost=int(v[5]), nesting=int(v[7]), total=float(v[8]), share=float(v[9]), maxSingle=float(v[10]), maxOuter=float(v[11]), maxExcl=float(v[12])))
    d = pd.DataFrame(rows)
    for al, g in d[(d.variant == 'short') & d.alpha.isin([0.49, 0.495])].groupby('alpha'):
        add(f'rehashclassical.a{al}.rehashes', f'full rehashes per seed (short loop, alpha={al})', '/'.join(map(str, g.rehashes)), 'rehashes', 'report_rehash_classical.txt', 'per seed')
        add(f'rehashclassical.a{al}.outermost', 'outermost rehashes per seed', '/'.join(map(str, g.outermost)), 'rehashes', 'report_rehash_classical.txt', 'per seed')
        add(f'rehashclassical.a{al}.nesting', 'maximum nesting depth per seed', '/'.join(map(str, g.nesting)), 'levels', 'report_rehash_classical.txt', 'per seed')
        add(f'rehashclassical.a{al}.longest_outermost_s', 'longest outermost rehash, nested included', g.maxOuter.max() / 1e3, 's', 'report_rehash_classical.txt', 'max over seeds')
        add(f'rehashclassical.a{al}.gap_ms', 'largest gap between the longest single insertion and the longest outermost rehash', (g.maxSingle - g.maxOuter).abs().max(), 'ms', 'report_rehash_classical.txt', 'max |diff| over seeds')
        add(f'rehashclassical.a{al}.longest_excl_ms', 'longest rehash with nested rehashes excluded', g.maxExcl.max(), 'ms', 'report_rehash_classical.txt', 'max over seeds')
        add(f'rehashclassical.a{al}.share', 'share of insertion time spent in outermost rehashes (mean of seeds)', g.share.mean() * 100, '%', 'report_rehash_classical.txt', 'mean')
        add(f'rehashclassical.a{al}.mean_insert_s', 'mean insertion time of a run', g.total.mean(), 's', 'report_rehash_classical.txt', 'mean')

def dscan(R, D):
    if not D: return
    for d, src in ((3, f'{R}/sweep.csv'), (4, f'{D}/sweep_d4.csv'), (5, f'{D}/sweep_d5.csv')):
        s = rd(src)
        if s is None: continue
        p = s[s.scheme.str.startswith('proposed')]
        add(f'dscan.d{d}.guard_trips', f'depth-guard trips over the proposed rows of the size sweep, d={d}', (p.guardTripsPerRun * p.reps).sum(), 'trips', os.path.basename(src), 'sum of guardTripsPerRun*reps')
        add(f'dscan.d{d}.max_ins_iters', f'largest single insertion (iterations), d={d}', p.maxInsIters.max(), 'iterations', os.path.basename(src), 'max')
        add(f'dscan.d{d}.missing_max', f'keys not found, d={d}', p.missingMax.max(), 'keys', os.path.basename(src), 'max')
    for d in (4, 5):
        t = rd(f'{D}/tail_d{d}.csv')
        if t is not None: add(f'dscan.d{d}.tail_builds', f'builds per scheme in the d={d} tail experiment', int(t.builds.iloc[0]), 'builds', f'tail_d{d}.csv', 'first row')

def trace(files):
    for p in files:
        if not os.path.exists(p): continue
        b = os.path.basename(p); t = open(p, errors='replace').read()
        for key, pat in (('top1pct_share', r'top 1% of flows carry\s+([\d.]+)%'), ('single_packet_pct', r'single-packet flows\s+([\d.]+)%'), ('span_s', r'trace time span\s+([\d.]+) s'), ('packets', r'packets read\s+(\d+)'), ('usable', r'usable \(IPv4 TCP/UDP\)\s+(\d+)'), ('flows', r'distinct flows seen\s+(\d+)')):
            m = re.search(pat, t)
            if m: add(f'trace.{b}.{key}', f'{key} in {b}', float(m.group(1)), '', b, 'regex on the report')
        for m in re.finditer(r'T=(\d+) s: entries (\d+)\s+lambda ([\d.e+]+) /s\s+T_res mean ([\d.]+) median ([\d.]+) p90 ([\d.]+) p99 ([\d.]+) max ([\d.]+) s\s+lambda\*E\[T_res\] ([\d.e+]+)\s+occupancy per second after 61 s warm-up: mean (\d+)\s+p99 (\d+)\s+peak (\d+)', t):
            T = m.group(1)
            for nm, i in (('lambda', 3), ('Tres_mean', 4), ('Tres_p99', 7), ('little', 9), ('occ_mean', 10), ('occ_p99', 11), ('occ_peak', 12)):
                add(f'trace.T{T}.{nm}', f'{nm} at idle timeout {T} s', float(m.group(i)), '', b, 'regex on the report')

def sdn(S):
    if not S: return
    path = S if S.endswith('.jsonl') else os.path.join(S, 'results.jsonl')
    if not os.path.exists(path): return
    r = [json.loads(l) for l in open(path) if l.strip()]; df = pd.DataFrame(r)
    add('sdn.rows', 'rows of results.jsonl', len(df), 'runs', 'results.jsonl', 'row count')
    add('sdn.all_ok', 'every run ok', bool(df.ok.all()), 'bool', 'results.jsonl', 'all(ok)')
    add('sdn.first_time', 'first run started', df.time.min(), '', 'results.jsonl', 'min(time)')
    add('sdn.last_time', 'last run started', df.time.max(), '', 'results.jsonl', 'max(time)')
    isd = lambda p: isinstance(p, dict)
    n_rec = df.probe.apply(isd).sum()
    n_samp = df.probe.apply(lambda p: isd(p) and ((p.get('idle', {}).get('n') or 0) + (p.get('during', {}).get('n') or 0)) > 0).sum()
    add('sdn.probe_records', 'runs with a probe record', int(n_rec), 'runs', 'results.jsonl', 'count')
    add('sdn.probe_samples', 'runs with at least one probe sample', int(n_samp), 'runs', 'results.jsonl', 'count')
    for tag in ('reactive', 'reactive_trace'):
        g = df[df.tag == tag]
        for topo, h in g.groupby('topo'):
            add(f'sdn.{tag}.{topo}.flows', f'mean flows per run, {tag}, {topo}', h.n_flows.mean(), 'flows', 'results.jsonl', 'mean of n_flows')
    ch = df[df.tag.isin(['churn', 'churn_trace'])]
    for (tag, a), h in ch.groupby(['tag', 'offered_alpha']):
        a = round(a, 2)
        add(f'sdn.{tag}.a{a}.arrivals', f'mean arrivals per run, {tag}, offered load {a}', h.arrivals.mean(), 'flows', 'results.jsonl', 'mean')
        add(f'sdn.{tag}.a{a}.duration', 'arrival period', h.churn_duration.mean(), 's', 'results.jsonl', 'mean')
        add(f'sdn.{tag}.a{a}.warmup', 'warm-up inside it', h.churn_warmup.mean(), 's', 'results.jsonl', 'mean')
    add('sdn.barrier_p99_min', 'barrier round trip, 99th percentile, smallest over churn runs', ch.barrier_p99_ms.min(), 'ms', 'results.jsonl', 'min')
    add('sdn.barrier_p99_max', '... largest', ch.barrier_p99_ms.max(), 'ms', 'results.jsonl', 'max')
    rz = df[df.tag.isin(['resize', 'resize_big'])]
    add('sdn.resize.alpha_hi_values', 'alpha_hi values used in the resize stages', ','.join(sorted(map(str, rz.alpha_hi_spec.unique()))), '', 'results.jsonl', 'distinct')
    def rate(tag, **kw):
        g = df[df.tag == tag]
        for k, v in kw.items(): g = g[np.isclose(g[k], v)] if isinstance(v, float) else g[g[k] == v]
        return g.flow_mods_per_s.mean()
    add('sdn.rate.cycle_stage', 'install rate, d=3 K=16 s=4 alpha=0.95, cycle stage (mode 0)', rate('sweep_cycle', K=16, cycle=0, alpha=0.95), 'flow_mods/s', 'results.jsonl', 'mean of 3 seeds')
    add('sdn.rate.sweep_K', 'same configuration in the K sweep', rate('sweep_K', K=16, alpha=0.95), 'flow_mods/s', 'results.jsonl', 'mean of 3 seeds')
    add('sdn.rate.sweep_s', 'same configuration in the s sweep', rate('sweep_s', s=4, alpha=0.95), 'flow_mods/s', 'results.jsonl', 'mean of 3 seeds')
    add('sdn.rate.sweep_d', 'same configuration in the d sweep', rate('sweep_d', d=3, alpha=0.95), 'flow_mods/s', 'results.jsonl', 'mean of 3 seeds')
    add('sdn.rate.sweep_m', 'same configuration in the cells sweep (2048 cells)', rate('sweep_m', cells=2048, alpha=0.95), 'flow_mods/s', 'results.jsonl', 'mean of 3 seeds')
    # --- per-run switch counters (runs/<run_id>/s1.stats): lower-load work bound and the machine-speed proxy ---
    base = os.path.dirname(path)
    def stats(run_id):
        f = os.path.join(base, 'runs', run_id, 's1.stats')
        if not os.path.exists(f): return None
        return {k: v for k, v in (l.strip().split('=', 1) for l in open(f) if '=' in l)}
    pr = df[(df.backend == 'proposed') & (df.exp == 'bulk') & (df.topo == 'single') & (df.tag == 'compare')]
    for a, h in pr.groupby('alpha'):
        st = [x for x in (stats(i) for i in h.run_id) if x]
        if not st: continue
        add(f'sdn.lowload.a{a:.2f}.runs', f'runs, compare stage, proposed table, single switch, alpha {a:.2f}', len(st), 'runs', 'runs/*/s1.stats', 'count')
        add(f'sdn.lowload.a{a:.2f}.rebuilds', 'rebuilds over those runs', sum(int(x['rebuilds']) for x in st), 'rebuilds', 'runs/*/s1.stats', 'sum of rebuilds')
        add(f'sdn.lowload.a{a:.2f}.max_insert_us', 'largest insertion', max(int(x.get('insert_ns_max', 0)) for x in st) / 1000, 'us', 'runs/*/s1.stats', 'max of insert_ns_max / 1000')
        add(f'sdn.lowload.a{a:.2f}.max_rounds', 'most walk rounds in one insertion', max(int(x['max_ins_rounds']) for x in st), 'rounds', 'runs/*/s1.stats', 'max of max_ins_rounds')
    add('sdn.R_values', 'values of R used by the proposed table', ','.join(map(str, sorted(df[df.backend == 'proposed'].R.unique()))), '', 'results.jsonl', 'distinct R')
    for tag, h in df[df.backend == 'proposed'].groupby('tag'):
        ck = [float(x['selfbench_clock_ns']) for x in (stats(i) for i in h.run_id) if x and 'selfbench_clock_ns' in x]
        if ck:
            add(f'sdn.clock_ns.{tag}', f'median cost of reading the clock in the switch self-benchmark, stage {tag} (machine-speed proxy; about 17 ns on a normal machine)', float(np.median(ck)), 'ns', 'runs/*/s1.stats', 'median of selfbench_clock_ns')
    c = df[(df.tag == 'compare') & (df.backend == 'proposed') & (df.topo == 'single') & np.isclose(df.alpha, 0.95)]
    add('sdn.rate.compare', 'same configuration in the comparison stage', c.flow_mods_per_s.mean(), 'flow_mods/s', 'results.jsonl', 'mean of 3 seeds')

def journal(K=16, D=20, s=4, cells=2048, alpha=0.90):
    ent = (D + 2) * (K + 2) * (s + 2) + 64
    add('journal.entries', 'journal entries (D+2)(K+2)(s+2)+64', ent, 'entries', 'formula (Section IV)', f'K={K}, D={D}, s={s}')
    add('journal.bytes', 'journal bytes, two 8-byte pointers per entry', ent * 16, 'bytes', 'formula', 'entries*16')
    add('journal.bytes_per_flow', f'journal bytes per flow at {cells} cells and alpha={alpha}', ent * 16 / round(cells * alpha), 'bytes/flow', 'formula', 'bytes / round(cells*alpha)')

def compute(full=None, dscan=None, sdn_path=None, trace_files=()):
    ROWS.clear()
    if full:
        benchmarks(full); rehashcost(full, dscan); rehash_classical(full); dscan_(full, dscan)
    trace(trace_files); sdn(sdn_path); journal()
    return pd.DataFrame(ROWS)

dscan_ = dscan

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--full'); ap.add_argument('--dscan'); ap.add_argument('--sdn'); ap.add_argument('--trace', nargs='*', default=[]); ap.add_argument('--out', default='text_values.csv')
    a = ap.parse_args()
    df = compute(a.full, a.dscan, a.sdn, a.trace); df.to_csv(a.out, index=False); print(len(df), 'values ->', a.out)
