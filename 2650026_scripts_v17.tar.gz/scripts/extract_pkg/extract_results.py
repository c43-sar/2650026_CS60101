#!/usr/bin/env python3
"""extract_results.py -- rebuild every table and every quoted number of the paper from the extracted run archives.

usage (Linux / Windows PowerShell alike):
  python3 extract_results.py --full  PATH/results_full  --dscan PATH/results_dscan  --sdn PATH/results_sdn \
                             --tinycheck PATH/tinycheck_results.txt \
                             --trace PATH/flows_stats.txt PATH/whole_stats_sample8.txt PATH/churn_res_sample8.txt \
                             --out OUT_DIR
  Each path is the folder that results_full.tar.gz / results_dscan.tar.gz / sdn_results_all.tar.gz unpacks to
  (results_sdn may also be given as the path of results.jsonl).  Every argument but --out is optional: what is missing is skipped and reported.

writes
  OUT_DIR/csv/<table>.csv      one CSV per table of the paper (LaTeX markup removed; thousands separators removed; ``a x 10^-3`` written as a e-3)
  OUT_DIR/csv/text_values.csv  the numbers quoted in the text that are not in a table, with their source file and method
  OUT_DIR/paper_values.xlsx    Excel workbook: one sheet per table with numeric cells as numbers, a sheet ``text_values``, a sheet ``facts`` (checks printed by the generators)
  OUT_DIR/tex/                 the LaTeX tables exactly as the paper includes them;  OUT_DIR/sdn/figs/  the three SDN figures (linear axes)
Needs: python3, pandas, numpy, matplotlib, openpyxl.  Nothing is typed in by hand; the stage THP/AnonHugePages does not exist any more (a thp/ folder in an old archive is ignored)."""
import os, re, sys, glob, argparse, subprocess, shutil
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import prose_values

ap = argparse.ArgumentParser()
ap.add_argument('--full'); ap.add_argument('--dscan'); ap.add_argument('--sdn'); ap.add_argument('--tinycheck')
ap.add_argument('--trace', nargs='*', default=[]); ap.add_argument('--out', required=True)
a = ap.parse_args()
O = os.path.abspath(a.out); TEX = os.path.join(O, 'tex'); CSV = os.path.join(O, 'csv'); SDN = os.path.join(O, 'sdn')
for d in (TEX, CSV, SDN): os.makedirs(d, exist_ok=True)
log = []
def run(script, *args):
    p = subprocess.run([sys.executable, os.path.join(HERE, script), *args], capture_output=True, text=True)
    if p.returncode != 0: log.append(f'FAILED {script}: {p.stderr.strip().splitlines()[-1] if p.stderr.strip() else p.returncode}')
    return p.stdout

# 1. LaTeX tables from the existing generators
if a.full and a.dscan:
    run('make_tables_main.py', a.full, a.dscan, TEX); run('make_tables_dscan.py', a.full, a.dscan, TEX)
elif a.full or a.dscan:
    log.append('benchmark tables need both --full and --dscan; skipped')
if a.sdn:
    src = a.sdn if a.sdn.endswith('.jsonl') else os.path.join(a.sdn, 'results.jsonl')
    run('make_tables_sdn.py', src, SDN)
    for f in glob.glob(os.path.join(SDN, 'tables', '*.tex')): shutil.copy(f, TEX)
if a.full or a.trace:
    ts = a.trace[1] if len(a.trace) > 1 else '-'
    run('make_tables_window_trace.py', a.full or '-', ts, TEX)
if a.tinycheck: run('make_tables_tinycheck.py', a.tinycheck, os.path.join(TEX, 'tinycheck.tex'))

# 2. LaTeX tabular -> CSV
def clean(c):
    c = c.strip()
    c = re.sub(r'\\multicolumn\{\d+\}\{[^}]*\}\{(.*)\}$', r'\1', c)
    c = re.sub(r'\\textbf\{(.*?)\}', r'\1', c); c = re.sub(r'\\textit\{(.*?)\}', r'\1', c); c = re.sub(r'\\texttt\{(.*?)\}', r'\1', c)
    c = re.sub(r'\\textsc\{(.*?)\}', r'\1', c); c = re.sub(r'\\emph\{(.*?)\}', r'\1', c)
    c = re.sub(r'(\d+(?:\.\d+)?)\\times ?10\^\{(-?\d+)\}', r'\1e\2', c)
    c = c.replace('\\ ', ' ').replace('\\lambda', 'lambda').replace('\\mathbb{E}', 'E')
    c = c.replace('{,}', '').replace('\\%', '%').replace('\\_', '_').replace('\\mu', 'u').replace('\\,', ' ').replace('~', ' ')
    c = c.replace('$', '').replace('\\allowbreak', '').replace('{}', '')
    c = re.sub(r'\\(?:alpha|geq|ge|le|leq|pm)\b', lambda m: {'alpha': 'alpha', 'geq': '>=', 'ge': '>=', 'le': '<=', 'leq': '<=', 'pm': '+-'}[m.group(0)[1:]], c)
    c = re.sub(r'\\[a-zA-Z]+', '', c); c = c.replace('{', '').replace('}', '')
    return re.sub(r'\s+', ' ', c).strip()
def tabulars(tex):
    for m in re.finditer(r'\\begin\{tabular\}\{[^}]*\}(.*?)\\end\{tabular\}', tex, flags=re.S):
        body = re.sub(r'\\hline|\\addlinespace\[[^\]]*\]', '', m.group(1))
        rows = [r for r in re.split(r'\\\\', body) if r.strip()]
        out = []
        for r in rows:
            cells = [clean(c) for c in r.split('&')]
            mc = re.findall(r'\\multicolumn\{(\d+)\}', r)
            if mc and len(cells) == 1 + 0 and False: pass
            out.append(cells)
        w = max(len(r) for r in out) if out else 0
        yield [r + [''] * (w - len(r)) for r in out]
tables = {}
for f in sorted(glob.glob(os.path.join(TEX, '*.tex'))):
    name = os.path.splitext(os.path.basename(f))[0]
    tabs = list(tabulars(open(f, encoding='utf-8').read()))
    for i, rows in enumerate(tabs):
        nm = name if len(tabs) == 1 else f'{name}_{i + 1}'
        df = pd.DataFrame(rows[1:], columns=[h or f'col{j}' for j, h in enumerate(rows[0])]) if len(rows) > 1 else pd.DataFrame(rows)
        df.to_csv(os.path.join(CSV, nm + '.csv'), index=False, encoding='utf-8'); tables[nm] = df
if os.path.exists(os.path.join(HERE, '..', 'rehash_classical_summary.csv')): pass
rcs = os.path.join(TEX, 'rehash_classical_summary.csv')
if os.path.exists(rcs): shutil.copy(rcs, CSV)

# 3. numbers quoted in the text
tv = prose_values.compute(a.full, a.dscan, a.sdn, a.trace)
tv.to_csv(os.path.join(CSV, 'text_values.csv'), index=False)

# 4. Excel
facts = []
for fp in (os.path.join(TEX, 'facts_main.txt'), os.path.join(TEX, 'facts_main2.txt'), os.path.join(SDN, 'facts_sdn.txt')):
    if os.path.exists(fp): facts += [dict(file=os.path.basename(fp), line=l.rstrip('\n')) for l in open(fp, encoding='utf-8') if l.strip()]
def num(x):
    try:
        s = str(x).replace(',', '')
        return float(s) if re.fullmatch(r'[-+]?\d+(\.\d+)?(e[-+]?\d+)?', s) else x
    except Exception: return x
with pd.ExcelWriter(os.path.join(O, 'paper_values.xlsx'), engine='openpyxl') as xw:
    tv.to_excel(xw, sheet_name='text_values', index=False)
    pd.DataFrame(facts).to_excel(xw, sheet_name='facts', index=False) if facts else None
    for nm, df in tables.items():
        df.apply(lambda col: col.map(num)).to_excel(xw, sheet_name=nm[:31], index=False)
print('tables (csv):', len(tables), '| text values:', len(tv), '| facts lines:', len(facts))
for l in log: print('NOTE', l)
print('written to', O)
