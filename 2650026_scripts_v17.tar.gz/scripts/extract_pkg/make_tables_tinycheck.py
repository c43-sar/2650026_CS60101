#!/usr/bin/env python3
"""make_tables_tinycheck.py -- model-check table of the paper from tinycheck_results.txt (mixed UTF-16/UTF-8 lines are decoded line by line).
usage: python3 make_tables_tinycheck.py tinycheck_results.txt OUT.tex"""
import sys, re
raw = open(sys.argv[1], encoding='utf-8', errors='replace').read()
def score(s): return sum(32 <= ord(c) < 127 for c in s) / max(1, len(s))
L = []
for line in raw.split('\n'):
    if any(ord(c) > 0x2000 for c in line):
        try: line = line.encode('utf-16le').decode('utf-8', 'replace')
        except Exception: pass
    L.append(line)
txt = '\n'.join(L).replace('\r', '\n').replace('\x00', '')
blocks = re.split(r'(?m)^=== tinycheck: ', txt)[1:]
rows = []; hdr = re.search(r'tinycheck v1\s+(\S+)\s+(\S+)', txt)
def g(p, b, i=1):
    m = re.search(p, b); return m.group(i) if m else None
f = lambda x: format(int(x), ',').replace(',', '{,}')
for b in blocks:
    d, m, s, K, D, u = re.match(r'd=(\d+) m=(\d+) s=(\d+) K=(\d+) D=(\d+) u=(\d+)\s+mutant=(\S+)', b).groups()[:6]
    mut = re.match(r'.*mutant=(\S+)', b).group(1)
    ha = g(r'checked \(up to renaming[^)]*\): (\d+)', b)
    cf = g(r'configurations expanded: (\d+)', b); ph = g(r'eviction-choice paths: (\d+)', b)
    rb = re.search(r'round bound K\(1\+D\(s\+1\)\) = (\d+); largest rounds found: (\d+) without the guard, (\d+) with it', b)
    v = re.search(r'violations: (\d+)\s+\(P1 conservation (\d+), P2 lookup (\d+), P3 nested overflow (\d+), P4 round bound (\d+), P5 re-insert (\d+)\)', b)
    sec = g(r'seconds: ([\d.]+)', b); res = g(r'RESULT: (\w+)', b)
    lab = '$(%s,%s,%s,%s,%s,%s)$' % (d, m, s, K, D, u) + (' retired retry' if mut != 'none' else '')
    rows.append('%s & %s & %s & %s & %s/%s & %s & %.0f & %s' % (lab, f(ha), f(cf), f(ph), rb.group(2), rb.group(1), f(v.group(1)) if mut != 'none' else '0', float(sec), res))
    print(lab, v.groups(), res)
s = '\\resizebox{\\linewidth}{!}{%\n\\begin{tabular}{|l|c|c|c|c|c|c|c|}\n\\hline\n\\textbf{$(d,m,s,K,D,u)$} & \\textbf{Hash assignments} & \\textbf{Configurations} & \\textbf{Eviction paths} & \\textbf{Max rounds / bound} & \\textbf{Violations} & \\textbf{Seconds} & \\textbf{Result} \\\\ \\hline\n'
s += ''.join(r + ' \\\\ \\hline\n' for r in rows) + '\\end{tabular}%\n}\n'
open(sys.argv[2], 'w', newline='\n').write(s)
print('host/date header:', hdr.groups() if hdr else None)
