#!/usr/bin/env python3
"""pcap2flows.py - turn a packet trace into the list of distinct exact-match microflows (IPv4 TCP/UDP 5-tuples).

  python3 pcap2flows.py trace.pcap.gz --out flows.txt [--keys keys.bin] [--max 200000] [--max-packets N] [--min-packets 1]
  python3 pcap2flows.py - ...            reads the trace from standard input (e.g.  zcat x.pcap.gz | python3 pcap2flows.py - ...)
  python3 pcap2flows.py trace.pcap.gz --out flows.txt --churn 5,15,30,60 --churn-out churn.txt     (v3; needs the WHOLE trace, not --max)

Input   classic pcap (micro- or nanosecond, either byte order) or pcapng, optionally gzip-compressed (detected by content).
        Link types: Ethernet (with up to two VLAN tags), raw IP, Linux cooked v1/v2, BSD loopback.  Standard library only.
Flow    the DIRECTIONAL 5-tuple (protocol, source IP, destination IP, source port, destination port) of IPv4 TCP and UDP
        packets that carry a port pair (non-first fragments, ICMP, IPv6, ARP, truncated headers are counted and skipped).
        An OpenFlow 1.0 exact-match entry is directional, so a flow and its reverse are two entries.
Output  --out FILE   one flow per line, first-seen order:  proto src_ip dst_ip sport dport   (proto 6/17, dotted-quad IPs)
        --keys FILE  the same flows as little-endian 64-bit keys (mix64 of the 5-tuple), for key-file benchmarks
        statistics (packets, flows, packets-per-flow distribution, duration) go to standard error.
Churn   --churn T1,T2,..  (seconds; v3) models an idle timeout of T seconds on every flow: an ENTRY is a maximal run of packets of one flow
        whose gaps are all <= T; it is installed at its first packet and removed T seconds after its last one (hard timeouts and the
        scan period are ignored). For every T the report gives: entries, arrival rate lambda = entries / trace span, the residence
        time T_res of an entry (mean, median, p90, p99, max), the mean occupancy lambda * E[T_res] (Little) and the occupancy counted
        per second (mean after a warm-up of max(T) seconds, p99, peak). The first and last seconds of a capture are censored (entries
        that began before the capture are not seen), so read the warm-up-free mean and the peak, not the first seconds.
        The peak occupancy divided by alpha_op is the table size (d*m) the trace needs.
Residence distribution  --res-out FILE (v4, with --churn): the T_res distribution of every T as 100 quantiles, one line 'T<TAB>q1,...,q100'. sdn_run.py --exp churn
        --churn-dist trace:FILE:T draws the lifetime of every arriving flow from it (hard timeout = the drawn residence time, rounded up to whole seconds).
Streaming (v5)  the trace is never unzipped and need not be stored: `curl -sS -L URL | python3 pcap2flows.py - ...` reads the gzip stream from standard input
        (gzip is detected by content). With --max the program stops reading once enough flows were seen, which ends the download early.
Compact churn (v5)  --compact keeps one 64-bit hash per flow instead of the 5-tuple and writes no flow list (measured on a synthetic 300,000-flow trace with four timeouts: about 270 instead of about 550 bytes per flow; the real trace's flow count is not known);
        --flow-sample R (R >= 2, implies --compact) tracks only the flows whose 64-bit hash is divisible by R, a uniform 1/R sample of the flows. The residence-time
        distribution of a flow sample is unbiased; entries, lambda and the occupancy MEAN are scaled by R. The occupancy PEAK and p99 of a sample are also scaled by R, so they
        OVERESTIMATE the true ones (the sampling noise is multiplied by R); the report prints them marked so. --mem-limit-mb N stops with exit code 3 and writes nothing
        before the machine runs out of memory (checked every 1,000,000 packets). Progress and memory go to standard error every 10,000,000 packets.
Anonymised traces (e.g. MAWI, whose addresses are scrambled) work unchanged: only the 5-tuple identity matters here.
"""
import argparse, gzip, io, os, socket, struct, sys, time, zlib
import urllib.request, urllib.error, http.client
from array import array

MASK = (1 << 64) - 1


def mix64(x):
    x = (x + 0x9E3779B97F4A7C15) & MASK
    x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & MASK
    x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & MASK
    return x ^ (x >> 31)


def key64(proto, src, dst, sport, dport):
    h = mix64(proto)
    h = mix64(h ^ src)
    h = mix64(h ^ dst)
    return mix64(h ^ (sport << 16) ^ dport)


class HttpStream(io.RawIOBase):
    """(v6) A URL read as a byte stream that resumes by itself: when the connection drops (curl error 18 and the like) it asks the server for
    'Range: bytes=<position>-' and carries on, so a 6 GB trace can be streamed without storing it. Nothing is written to disk."""
    def __init__(self, url, retries=40, timeout=60):
        self.url, self.retries, self.timeout = url, retries, timeout
        self.pos, self.total, self.resp, self.fails, self.resumes = 0, None, None, 0, 0

    def readable(self):
        return True

    def _open(self):
        req = urllib.request.Request(self.url, headers={"Range": "bytes=%d-" % self.pos} if self.pos else {})
        r = urllib.request.urlopen(req, timeout=self.timeout)
        if self.pos and r.status != 206:
            raise OSError("server does not support resuming (HTTP %d for a Range request); use a download to disk with 'curl -C -' instead" % r.status)
        if self.total is None:
            cl = r.headers.get("Content-Length")
            self.total = int(cl) if cl else -1
        self.resp = r

    def readinto(self, b):
        while True:
            try:
                if self.resp is None:
                    self._open()
                n = self.resp.readinto(b)
                if n:
                    self.pos += n
                    self.fails = 0
                    return n
                if self.total is not None and self.total > 0 and self.pos < self.total:
                    raise http.client.IncompleteRead(b"")             # the server closed early
                return 0
            except (OSError, http.client.HTTPException) as e:
                if isinstance(e, OSError) and "does not support resuming" in str(e):
                    raise
                self.fails += 1
                self.resumes += 1
                try:
                    self.resp.close()
                except Exception:
                    pass
                self.resp = None
                if self.fails > self.retries:
                    raise
                sys.stderr.write("[connection lost at byte %d (%s); resuming, attempt %d]\n" % (self.pos, type(e).__name__, self.fails))
                time.sleep(min(60, 2 ** min(self.fails, 6)))


def open_trace(path):
    if path.startswith(("http://", "https://")):
        raw = io.BufferedReader(HttpStream(path), buffer_size=1 << 20)
    else:
        raw = sys.stdin.buffer if path == "-" else open(path, "rb")
    f = io.BufferedReader(raw) if not hasattr(raw, "peek") else raw
    if f.peek(2)[:2] == b"\x1f\x8b":
        f = gzip.GzipFile(fileobj=f)
    return f


def read_exact(f, n):
    b = f.read(n)
    while len(b) < n:
        more = f.read(n - len(b))
        if not more:
            break
        b += more
    return b


def pcap_packets(f, magic):
    """yields (linktype, ts_seconds, caplen, data) from a classic pcap whose 4-byte magic was already read."""
    big = magic in (b"\xa1\xb2\xc3\xd4", b"\xa1\xb2\x3c\x4d")
    nano = magic in (b"\xa1\xb2\x3c\x4d", b"\x4d\x3c\xb2\xa1")
    e = ">" if big else "<"
    hdr = read_exact(f, 20)
    if len(hdr) < 20:
        return
    _vmaj, _vmin, _tz, _sig, _snap, link = struct.unpack(e + "HHiIII", hdr)
    div = 1e9 if nano else 1e6
    while True:
        ph = read_exact(f, 16)
        if len(ph) < 16:
            return
        sec, frac, caplen, _orig = struct.unpack(e + "IIII", ph)
        if caplen > (1 << 24):
            return                                           # corrupt record
        data = read_exact(f, caplen)
        if len(data) < caplen:
            return
        yield link & 0xFFFF, sec + frac / div, caplen, data


def pcapng_packets(f):
    """minimal pcapng reader: section header, interface description, enhanced and simple packet blocks."""
    ifaces, e = [], "<"
    while True:
        head = read_exact(f, 8)
        if len(head) < 8:
            return
        btype = head[:4]
        if btype == b"\x0a\x0d\x0d\x0a":                       # section header: byte order is announced inside it
            body0 = read_exact(f, 4)
            e = "<" if body0 == b"\x4d\x3c\x2b\x1a" else ">"
            length = struct.unpack(e + "I", head[4:8])[0]
            read_exact(f, length - 12)
            ifaces = []
            continue
        btype_i, length = struct.unpack(e + "II", head)
        body = read_exact(f, length - 8)
        if len(body) < length - 8:
            return
        if btype_i == 1:                                      # interface description
            link, _res, _snap = struct.unpack(e + "HHI", body[:8])
            tsres = 1e6
            opts = body[8:-4]
            while len(opts) >= 4:
                code, olen = struct.unpack(e + "HH", opts[:4])
                if code == 0:
                    break
                if code == 9 and olen >= 1:                   # if_tsresol
                    v = opts[4]
                    tsres = float(2 ** (v & 0x7F)) if v & 0x80 else float(10 ** (v & 0x7F))
                opts = opts[4 + ((olen + 3) & ~3):]
            ifaces.append((link, tsres))
        elif btype_i == 6 and len(body) >= 20:                # enhanced packet
            ifid, th, tl, caplen, _orig = struct.unpack(e + "IIIII", body[:20])
            link, tsres = ifaces[ifid] if ifid < len(ifaces) else (1, 1e6)
            yield link, ((th << 32) | tl) / tsres, caplen, body[20:20 + caplen]
        elif btype_i == 3 and len(body) >= 4 and ifaces:      # simple packet
            _orig = struct.unpack(e + "I", body[:4])[0]
            yield ifaces[0][0], 0.0, len(body) - 4, body[4:]


def trace_packets(f):
    magic = f.peek(4)[:4]
    if magic == b"\x0a\x0d\x0d\x0a":
        yield from pcapng_packets(f)
        return
    magic = read_exact(f, 4)
    if magic not in (b"\xa1\xb2\xc3\xd4", b"\xd4\xc3\xb2\xa1", b"\xa1\xb2\x3c\x4d", b"\x4d\x3c\xb2\xa1"):
        raise SystemExit("not a pcap/pcapng file (magic %r)" % magic)
    yield from pcap_packets(f, magic)


def ip_offset(link, d):
    """returns (offset of the IP header, kind) kind in 'ip4','ip6','other'."""
    n = len(d)
    if link == 1:                                              # Ethernet
        if n < 14:
            return None, "short"
        et, off = struct.unpack("!H", d[12:14])[0], 14
        for _ in range(2):
            if et in (0x8100, 0x88A8) and n >= off + 4:
                et = struct.unpack("!H", d[off + 2:off + 4])[0]
                off += 4
        return off, ("ip4" if et == 0x0800 else "ip6" if et == 0x86DD else "other")
    if link in (101, 12, 14, 228, 229):                        # raw IP
        if n < 1:
            return None, "short"
        v = d[0] >> 4
        return 0, ("ip4" if v == 4 else "ip6" if v == 6 else "other")
    if link == 113:                                            # Linux cooked v1
        if n < 16:
            return None, "short"
        et = struct.unpack("!H", d[14:16])[0]
        return 16, ("ip4" if et == 0x0800 else "ip6" if et == 0x86DD else "other")
    if link == 276:                                            # Linux cooked v2
        if n < 20:
            return None, "short"
        et = struct.unpack("!H", d[0:2])[0]
        return 20, ("ip4" if et == 0x0800 else "ip6" if et == 0x86DD else "other")
    if link == 0:                                              # BSD loopback
        if n < 4:
            return None, "short"
        fam = struct.unpack("<I", d[:4])[0]
        return 4, ("ip4" if fam == 2 else "ip6" if fam in (10, 24, 28, 30) else "other")
    return None, "linktype"


def parse_flow(link, d):
    off, kind = ip_offset(link, d)
    if kind != "ip4":
        return None, kind
    if len(d) < off + 20:
        return None, "short"
    vihl = d[off]
    ihl = (vihl & 15) * 4
    if (vihl >> 4) != 4 or ihl < 20:
        return None, "bad_ip"
    proto = d[off + 9]
    if proto not in (6, 17):
        return None, "not_tcp_udp"
    fragoff = struct.unpack("!H", d[off + 6:off + 8])[0] & 0x1FFF
    if fragoff:
        return None, "fragment"
    if len(d) < off + ihl + 4:
        return None, "short"
    src, dst = struct.unpack("!II", d[off + 12:off + 20])
    sport, dport = struct.unpack("!HH", d[off + ihl:off + ihl + 4])
    return (proto, src, dst, sport, dport), "ok"


def safe_packets(f, state, allow):
    """(v6) with --allow-truncated a cut-off input ends the packet loop instead of killing the program; the report then says so."""
    try:
        yield from trace_packets(f)
    except (EOFError, zlib.error, OSError, http.client.HTTPException) as e:
        if not allow:
            raise
        state["trunc"] = "%s: %s" % (type(e).__name__, e)


def ip(x):
    return socket.inet_ntoa(struct.pack("!I", x))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("trace")
    ap.add_argument("--out", required=True, help="flow list; with --compact the flow list is not written (use /dev/null)")
    ap.add_argument("--keys")
    ap.add_argument("--max", type=int, default=0, help="stop once this many distinct flows were seen (0 = read the whole trace)")
    ap.add_argument("--max-packets", type=int, default=0)
    ap.add_argument("--churn", help="comma list of idle timeouts in seconds, e.g. 5,15,30,60: report arrival rate, residence time and occupancy (needs the whole trace)")
    ap.add_argument("--res-out", help="(v4) with --churn: write the residence-time distribution of every T (100 quantiles per line, 'T<TAB>q1,..,q100' in seconds) "
                                      "for sdn_run.py --churn-dist trace:FILE:T")
    ap.add_argument("--compact", action="store_true", help="(v5) with --churn: one 64-bit hash per flow, no flow list, no packets-per-flow statistics")
    ap.add_argument("--flow-sample", type=int, default=1, help="(v5) with --churn: track 1 flow in R (hash divisible by R); implies --compact; the report scales by R")
    ap.add_argument("--mem-limit-mb", type=int, default=0, help="(v5) stop with exit code 3 above this many MB of memory (checked every 1,000,000 packets)")
    ap.add_argument("--allow-truncated", action="store_true", help="(v6) if the input ends early (broken download), finish with what was read and mark the report TRUNCATED instead of failing")
    ap.add_argument("--churn-out", help="write the churn report here as well as to standard error")
    ap.add_argument("--min-packets", type=int, default=1, help="keep only flows with at least this many packets (needs the whole trace)")
    a = ap.parse_args()
    if a.min_packets > 1 and a.max:
        sys.exit("--min-packets needs the whole trace: do not combine it with --max")
    taus = []
    if a.churn:
        if a.max or a.max_packets:
            sys.exit("--churn needs the whole trace: do not combine it with --max or --max-packets")
        taus = [float(x) for x in a.churn.split(",") if x.strip()]
    R = max(1, a.flow_sample)
    compact = bool(a.compact or R > 1)
    if compact and not taus:
        sys.exit("--compact / --flow-sample need --churn")
    slot, clast, cstart = {}, array("d"), [array("d") for _ in taus]   # compact mode: key64 -> index; last timestamp; start of the current entry per T
    usable = sampled = 0
    t_wall = time.time()

    def rss_mb():
        try:
            with open("/proc/self/statm") as fh:
                return int(fh.read().split()[1]) * os.sysconf("SC_PAGE_SIZE") / 1048576.0
        except Exception:
            return 0.0

    st = {}                                                    # flow -> [last_ts, start_of_entry(tau_0), start_of_entry(tau_1), ...] (only with --churn)
    res = [array("f") for _ in taus]                           # residence time of every closed entry
    starts = [{} for _ in taus]                                # second -> entries installed
    ends = [{} for _ in taus]                                  # second -> entries removed
    f = open_trace(a.trace)
    order, count = [], {}
    skipped = {}
    npk = 0
    t0 = t1 = None
    tstate = {}
    for link, ts, _cap, data in safe_packets(f, tstate, a.allow_truncated):
        npk += 1
        if a.max_packets and npk > a.max_packets:
            npk -= 1
            break
        if t0 is None:
            t0 = ts
        t1 = ts
        fl, why = parse_flow(link, data)
        if fl is None:
            skipped[why] = skipped.get(why, 0) + 1
            continue
        if npk % 1000000 == 0:
            m = rss_mb()
            if npk % 10000000 == 0:
                sys.stderr.write("[%6.0f s] %d packets, %d flows tracked, %.0f MB\n" % (time.time() - t_wall, npk, len(slot) if compact else len(st), m))
            if a.mem_limit_mb and m > a.mem_limit_mb:
                sys.stderr.write("memory limit %d MB reached after %d packets (%d flows tracked): nothing written. Re-run with a larger --flow-sample (now %d) "
                                 "or on the machine with more memory.\n" % (a.mem_limit_mb, npk, len(slot) if compact else len(st), R))
                sys.exit(3)
        if compact:
            usable += 1
            k = key64(*fl)
            if R > 1 and k % R:
                continue
            sampled += 1
            rt = ts - t0
            i = slot.get(k)
            if i is None:
                slot[k] = len(clast)
                clast.append(rt)
                for j in range(len(taus)):
                    cstart[j].append(rt)
                    kk = int(rt); starts[j][kk] = starts[j].get(kk, 0) + 1
            else:
                gap = rt - clast[i]
                for j, tau in enumerate(taus):
                    if gap > tau:
                        res[j].append((clast[i] - cstart[j][i]) + tau)
                        kk = int(clast[i] + tau); ends[j][kk] = ends[j].get(kk, 0) + 1
                        kk = int(rt); starts[j][kk] = starts[j].get(kk, 0) + 1
                        cstart[j][i] = rt
                clast[i] = rt
            continue
        if taus:
            rt = ts - t0
            s = st.get(fl)
            if s is None:
                st[fl] = [rt] + [rt] * len(taus)
                for i in range(len(taus)):
                    k = int(rt); starts[i][k] = starts[i].get(k, 0) + 1
            else:
                gap = rt - s[0]
                for i, tau in enumerate(taus):
                    if gap > tau:                              # the idle timeout fired: close the entry, a new one starts now
                        res[i].append((s[0] - s[1 + i]) + tau)
                        k = int(s[0] + tau); ends[i][k] = ends[i].get(k, 0) + 1
                        k = int(rt); starts[i][k] = starts[i].get(k, 0) + 1
                        s[1 + i] = rt
                s[0] = rt
        c = count.get(fl)
        if c is None:
            count[fl] = 1
            order.append(fl)
            if a.max and len(order) >= a.max:
                break
        else:
            count[fl] = c + 1
    flows = [x for x in order if count[x] >= a.min_packets]
    if not compact:
      with open(a.out, "w") as o:
        for p, s, d, sp, dp in flows:
            o.write("%d %s %s %d %d\n" % (p, ip(s), ip(d), sp, dp))
    if a.keys and not compact:
        with open(a.keys, "wb") as o:
            o.write(b"".join(struct.pack("<Q", key64(*x)) for x in flows))
    pk = sorted((count[x] for x in order), reverse=True)
    tot = sum(pk) or 1
    err = sys.stderr
    err.write("packets read            %d\n" % npk)
    err.write("  usable (IPv4 TCP/UDP) %d\n" % (usable if compact else sum(pk)))
    for k in sorted(skipped):
        err.write("  skipped %-14s %d\n" % (k, skipped[k]))
    if compact:
        err.write("compact churn mode: no flow list written; flows tracked %d%s\n" % (len(clast), "" if R == 1 else " = a 1-in-%d sample (about %d distinct flows estimated); %d sampled packets" % (R, len(clast) * R, sampled)))
    else:
        err.write("distinct flows seen    %d\n" % len(order))
        err.write("flows written          %d%s\n" % (len(flows), "" if len(flows) == len(order) else " (after --min-packets %d)" % a.min_packets))
    if pk:
        err.write("packets per flow       mean %.2f  median %d  max %d\n" % (tot / len(pk), pk[len(pk) // 2], pk[0]))
        top = max(1, len(pk) // 100)
        err.write("top 1%% of flows carry  %.1f%% of the usable packets\n" % (100.0 * sum(pk[:top]) / tot))
        err.write("single-packet flows    %.1f%%\n" % (100.0 * sum(1 for c in pk if c == 1) / len(pk)))
    if t0 is not None and t1 is not None and t1 >= t0:
        err.write("trace time span        %.3f s\n" % (t1 - t0))
    if tstate.get("trunc"):
        err.write("TRUNCATED INPUT (%s): the report covers only the first %.1f s of the capture\n" % (tstate["trunc"], (t1 - t0) if t0 is not None else 0.0))
    if a.max and len(order) >= a.max:
        err.write("(stopped at --max %d flows; the rest of the trace was not read)\n" % a.max)
    if taus and t0 is not None:
        span = max(t1 - t0, 1e-9)
        if compact:                                            # close the entries still open at the end of the capture
            for x in range(len(clast)):
                for i, tau in enumerate(taus):
                    res[i].append((clast[x] - cstart[i][x]) + tau)
                    k = int(clast[x] + tau); ends[i][k] = ends[i].get(k, 0) + 1
        else:
            for s in st.values():
                for i, tau in enumerate(taus):
                    res[i].append((s[0] - s[1 + i]) + tau)
                    k = int(s[0] + tau); ends[i][k] = ends[i].get(k, 0) + 1
        nfl = len(clast) if compact else len(st)
        lines = ["churn model: idle timeout only; capture span %.3f s; %d distinct flows (IPv4 TCP/UDP)%s" % (span, nfl * R, "" if R == 1 else " (estimated from a 1-in-%d flow sample: %d flows tracked)" % (R, nfl))]
        if R > 1:
            lines.append("sample scaling: entries, lambda and the occupancy are multiplied by %d; T_res statistics need no scaling. The occupancy mean is unbiased; its p99 and PEAK are "
                         "OVERESTIMATES (the sampling noise is multiplied by %d), so use them only as upper bounds." % (R, R))
        nsec = int(span + max(taus)) + 3
        for i, tau in enumerate(taus):
            r = sorted(res[i])
            n = len(r)
            if n == 0:
                continue
            mean = sum(r) / n
            occ, cur = [], 0
            for k in range(nsec):
                cur += starts[i].get(k, 0) - ends[i].get(k, 0)
                occ.append(cur)
            warm = int(max(taus)) + 1
            body = sorted(occ[warm:int(span)]) if int(span) > warm + 1 else []
            lam = n * R / span
            lines.append("T=%g s: entries %d  lambda %.4g /s  T_res mean %.2f median %.2f p90 %.2f p99 %.2f max %.2f s  lambda*E[T_res] %.4g"
                         % (tau, n * R, lam, mean, r[n // 2], r[int(0.9 * (n - 1))], r[int(0.99 * (n - 1))], r[-1], lam * mean))
            if body:
                lines.append("        occupancy per second after %d s warm-up: mean %.0f  p99 %d  peak %d  (peak/0.88 = %.0f cells, peak/0.94 = %.0f cells)%s"
                             % (warm, R * sum(body) / len(body), R * body[int(0.99 * (len(body) - 1))], R * body[-1], R * body[-1] / 0.88, R * body[-1] / 0.94,
                                "" if R == 1 else "   [p99 and peak: upper bounds, see above]"))
            else:
                lines.append("        trace shorter than the warm-up: occupancy per second not reported")
        if tstate.get("trunc"):
            lines.insert(0, "TRUNCATED INPUT: only the first %.1f s of the capture were read (%s); lambda and T_res describe that part only" % (span, tstate["trunc"]))
        for ln in lines:
            err.write(ln + "\n")
        if a.res_out:
            with open(a.res_out, "w") as o:
                for i, tau in enumerate(taus):
                    r = sorted(res[i])
                    if r:
                        o.write("%g\t%s\n" % (tau, ",".join("%.3f" % r[min(len(r) - 1, int((j + 0.5) / 100.0 * len(r)))] for j in range(100))))
        if a.churn_out:
            with open(a.churn_out, "w") as o:
                o.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
