# Run guide 1: the i3 laptop (Fedora, bash) -- final state of the paper "Cuckoo Hashing with Bounded Displacement for Exact-Match Flow Tables"

This guide reproduces every run of the paper on the test laptop. The runs reported in the paper were made with exactly these commands (benchmarks 23 October, SDN 24 to 25 October 2026, kernel 7.2.11). The model check (`tinycheck`) was run on the same laptop booted into Windows (PowerShell, see part E).
The deferred runs (exact whole-trace churn, N = 10^7) are in `run_ubuntu_future.sh` and `RUN_GUIDE_2_ubuntu_v4.md`; they are not part of the paper.

**Order:** A (trace) -> B (benchmarks) -> C (SDN) -> D (optional: SDN churn with the exact residence times, after the future-work run) -> E (model check, Windows) -> F (extract the tables) -> G (upload).
Writes to the SSD: the trace is streamed through a pipe; only `keys.bin` (16 MB), `flows.txt` (about 100 MB), the result folders and the build trees are written.

## A. One-time setup and the trace (streamed)
```bash
sudo dnf install -y gcc-c++ python3 python3-pandas python3-matplotlib perf tmux curl
mkdir -p ~/adsa ~/mawi ~/tools    # ~/adsa: bench.cpp run_all.sh (v5.7) run_sweep.sh perf_summarize.py plot_sweep.py;  ~/tools: pcap2flows.py (v6)
#   ~/sdn_pkg: unpack sdn_pkg_v4.tar.gz in your home folder (tar xzf sdn_pkg_v4.tar.gz -C ~). All these files are in this chat.
cd ~/mawi
# The first 2,000,000 distinct flows of the MAWI trace, straight from the network: pcap2flows reads the gzip stream from standard input and stops once it has
# 2,000,000 flows, which ends the download early (how much of the 6.1 GB that is, is not measured). curl may print "(23) Failure writing output" once: that is the early stop.
time curl -sS -L http://mawi.nezu.wide.ad.jp/mawi/samplepoint-F/2026/202610181400.pcap.gz | python3 ~/tools/pcap2flows.py - --out flows.txt --keys keys.bin --max 2000000 2>&1 | tee flows_stats.txt
sha256sum keys.bin | tee keys.sha256
head -n 400000 flows.txt > flows_400k.txt
free -m                          # while it runs, watch memory in a second terminal: watch -n 5 free -m  (about 1 GB expected for 2,000,000 flows; not measured)
```
No unzipping is needed anywhere: `pcap2flows.py` reads `.pcap.gz` as it is. If the connection drops, run the same command again (nothing partial is kept). Keep the MAWI usage terms and requested citation with the data description.

**A2. Flow-sampled churn estimate (optional but recommended; about 0.5 to 1 h by arithmetic).** The exact whole-trace churn model keeps one entry per distinct flow (about 550 bytes per flow with v4, measured on a synthetic trace; the real trace's flow count is not known), so the exact run is the future-work script (`run_ubuntu_future.sh`). Here it runs on a 1-in-8 sample of the flows with a memory guard:
```bash
cd ~/mawi
time python3 ~/tools/pcap2flows.py http://mawi.nezu.wide.ad.jp/mawi/samplepoint-F/2026/202610181400.pcap.gz --out /dev/null \
   --churn 5,15,30,60 --flow-sample 8 --mem-limit-mb 2200 --allow-truncated --churn-out churn_sample8.txt --res-out churn_res_sample8.txt 2>&1 | tee whole_stats_sample8.txt
```
This streams the whole 6.1 GB through the laptop (nothing stored). It prints progress and memory every 10,000,000 packets. If it prints "memory limit ... reached" it exits with code 3 and writes nothing: re-run with `--flow-sample 16` (or 32). **v6 reads the URL itself and resumes after a dropped connection** (the first attempt with `curl | python3` died at about 3.7 GB with curl error 18, and a pipe cannot resume; nothing was written then). Each resume prints `[connection lost at byte ... resuming]`; nothing is stored on disk. If the server refuses resuming, the message says so: then download to disk with `curl -C - --retry 20 -o 202610181400.pcap.gz URL` (6.1 GB; check `df -h` first), run `python3 ~/tools/pcap2flows.py 202610181400.pcap.gz ...` with the same options, and delete the file afterwards. With `--allow-truncated`, if the input still ends early the report is written anyway and says `TRUNCATED INPUT ... first N s of the capture`; send it, but then say so and I will mark the result as covering only that part.
What the sample gives: the residence-time distribution is unbiased (that is what `churn_trace` replays); arrival rate and mean occupancy are scaled by 8 and are unbiased; the occupancy p99 and peak come out too high (the sampling noise is multiplied by 8), so a table-size claim from the peak needs the exact numbers (future work). On synthetic traces only: 1-in-4 sampling changed the mean occupancy by 1 % and raised the peak by about 13 %.
Speed (synthetic trace, this sandbox, not the i3): about 170,000 packets/s through the gzip pipe with sampling, so 240,811,249 packets would take about 24 min here; the i3 is probably slower (not measured).

## B. Benchmarks: `run_all.sh`
```bash
cd ~/adsa
tmux new -s runs                                                   # detach with Ctrl-b d; re-attach with: tmux attach -t runs
sudo -v; while true; do sudo -n true; sleep 60; done & KEEP=$!      # keeps sudo alive for SETUP
# 1. smoke test (numbers are not results)
QUICK=1 KEYS=$HOME/mawi/keys.bin SETUP=1 OUT=results_quick bash run_all.sh 2>&1 | tee quick.log
# 2. the run of the paper: default stages + real (keys.bin)
SETUP=1 KEYS=$HOME/mawi/keys.bin OUT=results_full systemd-inhibit --what=sleep:idle bash run_all.sh 2>&1 | tee full.log
# 3. d = 4 and 5 (loads below c*_4 = 0.9768 and c*_5 = 0.9924), own folder
SETUP=1 KEYS=$HOME/mawi/keys.bin OUT=results_dscan systemd-inhibit --what=sleep:idle bash run_all.sh dscan 2>&1 | tee dscan.log
kill $KEEP
ls -l results_full.tar.gz results_dscan.tar.gz
```
Default stages: info, build, main, ext, sweep, tail, sens, sat, perf, retrybug, rehashclassical, rehashcost, window, hyper, merge, plots; `real` runs when `KEYS` is set. Do not set `BIG=1` here (N = 10^7 is in `run_ubuntu_future.sh`). `PIN=<cpu>` pins the timed runs (`taskset`); the paper's run was not pinned.

## C. The SDN runs, d = 3, 4, 5
The d = 4, 5 bench runs are step B3 above; the SDN side has its own d = 3, 4, 5 stages below.
```bash
# C2. Once: Mininet, the patched switch, its unit test (README steps 1-2)
sudo dnf install -y git gcc make autoconf automake libtool libpcap-devel openssl-devel python3-numpy iproute iputils net-tools help2man mininet
sudo modprobe tun
cd ~ && git clone https://github.com/mininet/openflow.git && bash ~/sdn_pkg/patch/apply_patch.sh ~/openflow
cd ~/openflow && ./boot.sh && ./configure CFLAGS="-O2 -g -std=gnu89 -Wno-error -Wno-implicit-function-declaration -Wno-int-conversion -Wno-incompatible-pointer-types" \
  && make -j"$(nproc)" udatapath/ofdatapath secchan/ofprotocol utilities/dpctl
cd ~/sdn_pkg && sudo python3 live_switch_test.py ~/openflow proposed 0.9 2048     # must end OK. sudo is needed: ofdatapath opens /dev/net/tun for its local port, which fails for a normal user (the README's 'no root' was wrong)
cd ~/sdn_pkg && sudo python3 selftest_pipeline.py ~/openflow && sudo chown -R "$USER": ~/sdn_pkg                         # every stage on the real switch without Mininet; ends by writing plots (numbers are NOT for the paper)
# If a check says "switch did not connect" or dp.log shows 'ioctl(TUNSETIFF) ... Operation not permitted', it was run without sudo. Clear leftovers before retrying:
sudo pkill -f 'ofdatapath|ofprotocol'; cd ~/sdn_pkg && sudo mn -c
# If you unpacked the older v3b package, only one file changed (Mininet 2.3 keeps TreeTopo in mininet.topolib; v3b failed with 'cannot import name TreeTopo' and every run FAILED): copy the new sdn_run.py over ~/sdn_pkg/sdn_run.py, and delete the failed attempt before restarting:  sudo rm -rf ~/sdn_pkg/results_sdn ~/sdn_pkg/results_sdn_quick
# The 'egrep: warning' and 'ovs-vsctl: database connection failed' lines come from Mininet itself (Open vSwitch is not used here) and are harmless.
# C3. the sweeps (root). The reduced grid first, then the full grid (3 seeds; resumable: run the same line again)
cd ~/sdn_pkg && sudo mn -c
sudo OUT=results_sdn_quick QUICK=1 TRACE=$HOME/mawi/flows_400k.txt RES=$HOME/mawi/churn_res_sample8.txt bash sdn_sweep.sh ~/openflow all 2>&1 | tee quick_sdn.log      # RES from A2; without A2 drop RES= and churn_trace is skipped with a notice
#   full grid, in two pieces so that a crash costs less (the second adds the real-trace stages):
sudo bash sdn_sweep.sh ~/openflow all 2>&1 | tee full_sdn.log
sudo TRACE=$HOME/mawi/flows_400k.txt RES=$HOME/mawi/churn_res_sample8.txt bash sdn_sweep.sh ~/openflow trace reactive_trace ceiling_trace resize_trace churn_trace 2>&1 | tee full_sdn_trace.log     # churn_trace needs A2's file; without A2 leave churn_trace out
sudo chown -R "$USER": results_sdn && python3 sdn_plot.py results_sdn/results.jsonl results_sdn/plots
tar czf sdn_results.tar.gz results_sdn/results.jsonl results_sdn/failures.txt results_sdn/plots results_sdn/runs/*/*.stats
```
New stages of this package (all in `all`; the trace ones only when `TRACE` is set; `churn_trace` also needs `RES`, so without A2's file (or part D's) it is skipped with a one-line notice):

| Stage | What it runs (d = 3, 4, 5 unless said) | Runs, full grid | Arithmetic time |
|---|---|---|---|
| `ceiling_d` | bulk install, load 0.80 ... 0.99, 2520 cells, no resize: the load of the first rejection against c*_d | 30 configs x 3 seeds | about 0.5 h |
| `resize_d` | flows = 2 x cells, incremental resize with trigger c*_d - margin (margin 0.01, 0.02, 0.05, 0.10) and a no-resize baseline | 15 x 3 | about 0.3 h |
| `churn` | Poisson arrivals, hard timeouts (exponential, mean 5 s), steady load 0.7 / 0.9 / 0.95; stock, 2-choice, classic, linear probing, chaining, proposed d = 3, 4, 5, proposed d = 3 with resize | 27 x 3 | about 1.6 h (55 s of traffic + start-up per run) |
| `ceiling_trace`, `resize_trace` | the two stages above with real flow keys | (30 + 15) x 3 | about 0.8 h |
| `churn_trace` | arrivals as above but lifetimes drawn from the MAWI residence times (T = 15 s, truncated at 30 s), 150 s per run | 27 x 3 | about 3.7 h |

`CHURN_T=5` (or 30, 60) picks another idle timeout from `churn_res.txt`. With `TRACE` set, `all` also runs `trace` and `reactive_trace` on the real flows (2048-cell tables, so 400,000 flows are plenty).
If anything crashes: `sudo mn -c`, then `tail -20 results_sdn/runs/*/s1-ofd.log` and send me the message.

## C2. Rerun the stages that ran on a slowed machine (optional)

In the 24 Oct run the stages `sweep_cycle`, `resize`, `resize_big` and the bulk part of `reactive` ran while the machine was about 2.6 times slower than in the other stages: the median cost of reading the clock in the switch self-benchmark (`selfbench_clock_ns` in `runs/*/s1.stats`) was 44 ns in them and 17 ns elsewhere, while the work counters (rounds, kicks, stash arrivals) were identical. The cause was not recorded. To rerun them:

```bash
# before: note the CPU governor and close other programs; do not run anything else on the laptop
cpupower frequency-info | grep -i "governor\|current CPU frequency"
sudo OUT=results_sdn_rerun bash sdn_sweep.sh /path/to/openflow sweep_cycle resize resize_big reactive
python3 extract_pkg/extract_results.py --sdn results_sdn_rerun --out rerun_out
grep "sdn.clock_ns" rerun_out/csv/text_values.csv      # about 17 ns in every stage means a normal machine
```

If every stage now shows about 17 ns, the absolute times of these stages (install rates, the resize times, the longest batch) can be compared with the other stages; if not, they can only be compared within a stage.

## D. SDN churn with the exact residence times (optional; after the future-work run)
Not part of the paper. Only needed if you want `churn_trace` on the exact whole-trace distribution instead of A2's sample (or if you skipped A2, in which case this is the only way to run `churn_trace`).
```bash
# put churn_res.txt (from `run_ubuntu_future.sh`, a few KB) into ~/mawi: download it from this chat, a USB stick, or paste the 4 lines into the file
cd ~/sdn_pkg && sudo mn -c
sudo CT_TAG=churn_trace_exact TRACE=$HOME/mawi/flows_400k.txt RES=$HOME/mawi/churn_res.txt bash sdn_sweep.sh ~/openflow churn_trace 2>&1 | tee full_sdn_churn_trace_exact.log
sudo chown -R "$USER": results_sdn && python3 sdn_plot.py results_sdn/results.jsonl results_sdn/plots
tar czf sdn_results.tar.gz results_sdn/results.jsonl results_sdn/failures.txt results_sdn/plots results_sdn/runs/*/*.stats        # replaces the earlier sdn_results.tar.gz
```
`CT_TAG=churn_trace_exact` keeps these rows apart from A2's (`churn_trace`); the plot script reports both. (`CHURN_T=5`, `30` or `60` pick another timeout; QUICK=1 shortens the run.) Part D waits for the future-work run; nothing else does.


## E. Model check (Windows, PowerShell)
```powershell
# tinycheck_v1.tar.gz: tinycheck.cpp and run_tinycheck.ps1; needs g++ (TDM-GCC 10.3.0 was used)
tar xzf tinycheck_v1.tar.gz; cd tinycheck
powershell -ExecutionPolicy Bypass -File .\run_tinycheck.ps1          # writes tinycheck_results.txt: six runs, the mutant (retired retry) must report violations
```
`tinycheck_results.txt` may mix UTF-16 and UTF-8 lines (PowerShell redirection); `make_tables_tinycheck.py` decodes it line by line.

## F. Extract the tables and the quoted numbers
Unpack the archives (`tar xzf results_full.tar.gz`, `results_dscan.tar.gz`, `sdn_results_all.tar.gz`) and run, from the folder `extract_pkg`:
```bash
python3 extract_results.py --full ../results_full --dscan ../results_dscan --sdn ../results_sdn \
   --tinycheck ../tinycheck_results.txt --trace ../flows_stats.txt ../whole_stats_sample8.txt ../churn_res_sample8.txt --out ../extracted
```
PowerShell: the same line with `python` and backticks for line breaks. Output: `extracted/csv/*.csv` (one per table of the paper), `extracted/csv/text_values.csv` and `extracted/paper_values.xlsx` (numbers quoted in the text, with source file and method), `extracted/tex/` (the LaTeX tables the paper includes). Needs pandas, numpy, matplotlib, openpyxl. `--trace` takes the three files in this order: key-file statistics, whole-trace statistics, residence-time file.

## G. Upload to the repository
Put the three archives, the trace statistics files, `tinycheck_results.txt`, the sources and scripts of this package, the figures and `extracted/` into https://github.com/c43-sar/2650026_CS60101 (large files: keep `keys.bin` and `flows_400k.txt` out and keep their SHA-256 in `keys.sha256`; the 6.1 GB trace is never uploaded; use the MAWI URL and the Cho, Mitsuya and Kato 2000 citation requested by the MAWI project).

## H. What to send back after a new run
`results_full.tar.gz`, `results_dscan.tar.gz`, `sdn_results_all.tar.gz`, `flows_stats.txt`, `whole_stats_sample8.txt`, `churn_sample8.txt`, `churn_res_sample8.txt`, `keys.sha256`, `tinycheck_results.txt`, and `cat /etc/fedora-release; uname -r; lscpu | head -20`.

## G. What these runs cannot give
- TCAM priority reordering and hardware update rates: the software switch has neither, so those map entries stay hypotheses.
- `t_a` (time of one random cell access): no script reports it; the nearest is the `bench lookup` latency.
- The load-triggered resize has no `bench.cpp` stage; it exists only in the SDN stages (`resize`, `resize_big`, `resize_d`, `resize_trace`).
- `churn` expires flows by hard timeout (the lifetime is drawn per flow); the switch scans for expired flows once per second, so a flow lives H + U(0,1] s and the offered load is computed with E[H] + 0.5 s. It does not reproduce idle timeouts, hard-timeout/idle-timeout mixtures or flow_removed messages.
- `churn_trace` replays the trace's residence-time distribution, not its packet order, truncated at 30 s so that a 150 s run can reach steady state; the truncation lowers the mean lifetime, which the result files record (`churn_mean_lifetime`).
- In `churn` the measured occupancy (`occ_mean_alpha`) can differ from the offered load by a few percent (arrival timing of a Python generator, short runs): compare variants by the measured column, and read the `floor` column of the table (Erlang B) as the rejection rate even a perfect table would have at that load.
- The table never shrinks after a resize, so under churn a resized table stays large (`cells_per_flow` rises); a shrink policy is not implemented.
- The flow_mod latency here is the barrier round trip on loopback to a software switch: it shows the stall of the table, not hardware update rates.
