# Run guide 2: the deferred runs (future work), Ubuntu LTS, bash, about 32 GB

These runs are **not in the paper**. They exist as a ready script for a machine that can hold them; add their results to the paper only after they have been run.

| Stage | What | Why |
|---|---|---|
| `trace` | download the MAWI trace 202610181400 (6.1 GB, `wget -c`, resumable) and its SHA-256 | input of the next stage; never unzipped |
| `churn` | exact whole-trace churn model: one entry per distinct flow (exact peak and 99th-percentile occupancy at idle timeouts 5, 15, 30, 60 s; `churn.txt`, `churn_res.txt`, `whole_stats.txt`, memory log) | the paper uses a 1-in-8 flow sample, whose mean occupancy and residence times are unbiased but whose peak and p99 are upper bounds; the exact run gives the table size the trace needs and checks the sample |
| `big` | `bench main` at N = 10^7 (`run_all.sh big`, time cap off) | the paper's sizes stop at 2x10^6; not timed here |
| `pack` | tar of the above with SHA-256 sums and `sysinfo.txt` (`lsb_release -a; uname -r; lscpu; free -m`) | one file to carry back |

```bash
export EMPLOYEE_CODE=<your employee code>; export W=$HOME/$EMPLOYEE_CODE; mkdir -p $W/tools $W/adsa $W/mawi
# copy from the repository: tools/pcap2flows.py (v6); adsa/ bench.cpp run_all.sh run_sweep.sh perf_summarize.py plot_sweep.py; and run_ubuntu_future.sh
tmux new -s future
export EMPLOYEE_CODE=<your employee code>; export W=$HOME/$EMPLOYEE_CODE
APT=1 bash run_ubuntu_future.sh              # all stages: setup trace churn big pack     (or name stages:  bash run_ubuntu_future.sh trace churn)
```
- Memory of `churn` is not measured; `mem.log` records it every 10 s. `MEM_LIMIT_MB` (default 28000) makes `pcap2flows.py` stop with exit code 3 and write nothing instead of swapping; then keep the flow-sampled result or raise the limit.
- A finished stage is skipped on a second call unless `FORCE=1`. The script writes only below `$W`.
- Latencies from this machine are a second machine and are not comparable with the paper's; counts are.
- After the run: carry `churn_res.txt` to the test laptop for the optional SDN stage (`CT_TAG=churn_trace_exact`, guide 1 part D) and put `ubuntu_future_results.tar.gz` in the repository next to the other archives. MAWI usage terms and the requested citation stay with the data description.
