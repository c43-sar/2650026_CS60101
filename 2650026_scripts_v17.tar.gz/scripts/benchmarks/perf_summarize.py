#!/usr/bin/env python3
"""perf_summarize.py <perf_dir> <out_csv>
Reads the pairs written by run_all.sh: <scheme>_<N>_r<k>_base.csv (build only) and
<scheme>_<N>_r<k>_run.csv (+ _run.txt, the program's own output) from `perf stat -x,` and writes one row per
(scheme, N) with per-lookup values = (run - base) / (reps * N), medians over the repeats.
Hybrid CPUs print events as cpu_core/<event>/ and cpu_atom/<event>/; events of the pinned core are used and
the other PMU is ignored. Events the CPU or the virtual machine does not support are left empty."""
import csv, glob, os, re, statistics, sys
def read_perf(path):
    d = {}
    for line in open(path, encoding="utf-8", errors="replace"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        f = line.split(",")
        if len(f) < 3:
            continue
        val, ev = f[0], f[2]
        m = re.match(r"cpu_(core|atom)/(.+?)/", ev)
        if m:
            if m.group(1) == "atom":
                continue
            ev = m.group(2)
        ev = re.sub(r":[uk]+$", "", ev)
        try:
            d[ev] = float(val)
        except ValueError:
            d.setdefault(ev, None)
    return d
def main(pd, out):
    runs = {}
    for p in sorted(glob.glob(os.path.join(pd, "*_run.csv"))):
        m = re.match(r"(.+)_(\d+)_r(\d+)_run\.csv$", os.path.basename(p))
        if not m:
            continue
        sc, n, rep = m.group(1), int(m.group(2)), int(m.group(3))
        base = p[:-len("_run.csv")] + "_base.csv"
        txt = p[:-len("_run.csv")] + "_run.txt"
        if not (os.path.exists(base) and os.path.exists(txt)):
            continue
        mt = re.search(r"reps=(\d+) ns_per_lookup=([0-9.eE+-]+)", open(txt).read())
        if not mt:
            continue
        reps, ns = int(mt.group(1)), float(mt.group(2))
        a, b = read_perf(p), read_perf(base)
        per = {}
        for ev, v in a.items():
            if v is not None and b.get(ev) is not None:
                per[ev] = (v - b[ev]) / (reps * n)
        per["ns_per_lookup"] = ns
        runs.setdefault((sc, n), []).append(per)
    cols = ["ns_per_lookup", "cycles", "instructions", "cache-references", "cache-misses",
            "L1-dcache-loads", "L1-dcache-load-misses", "LLC-loads", "LLC-load-misses", "dTLB-loads", "dTLB-load-misses"]
    with open(out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["scheme", "N", "repeats"] + [c + "_per_lookup" if c != "ns_per_lookup" else c for c in cols] + ["ipc"])
        for (sc, n) in sorted(runs, key=lambda k: (k[0], k[1])):
            rs = runs[(sc, n)]
            row = [sc, n, len(rs)]
            med = {}
            for c in cols:
                vals = [r[c] for r in rs if c in r]
                med[c] = statistics.median(vals) if vals else None
                row.append("" if med[c] is None else "%.6g" % med[c])
            ipc = med["instructions"] / med["cycles"] if med["instructions"] and med["cycles"] else None
            row.append("" if ipc is None else "%.4f" % ipc)
            w.writerow(row)
    print("wrote", out)
if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
