// bench.cpp (v5.8: adds `hyperfine` (finer density bins per load, per seed); v5.7: adds `satcomp` (component size of the key's slots at insertion, and the routing rate by component size, per table size m);
//            v5.6: adds `-d D` (sub-tables of the proposed scheme, default 3) and `-a a1,a2,...` (load-list override) -- see "v5.6 options" below;
//            v5.5: adds `rehashclassical`, `rehashcost`, `window`, `hyper`, `merge` modes, `-k keys.bin` key-file input and a `-T seconds` time cap
//            for `main`; every pre-existing mode keeps its output; v5.4 added `retrybug`; v5.3 `lookup`; v5.2 `sens`, `sat`; v5.1 `tail`)
//   v5.5 modes (all new; none changes an existing mode):
//     bench rehashclassical [seeds=3] [N=2000000] -c rehash_classical.csv
//         classical 2-way cuckoo at alpha 0.45/0.49/0.495, short and prescribed loop: every full rehash is timed
//         (inclusive and exclusive of nested rehashes) and its nesting depth recorded; settles whether the maximum
//         single-insert time is one outermost rehash or a nest of rehashes.
//     bench rehashcost [seeds=3] [N=200000] [maxEvents=50] -c rehashcost.csv
//         proposed scheme: for the first <maxEvents> stash-overflow events of each build, times the REAL RehashStash
//         against a full rebuild (fresh hashes, all keys) of an identical COPY of the table at that moment.
//         The copy never touches the original, so the measured build is identical to a build without the probe.
//     bench window [seeds=5] [N=2000000]
//         measured frequency of W-insertion windows with more than s stash arrivals vs the Chernoff bound and the exact
//         binomial tail (the independence check for Theorem "Stash-Overflow Probability Bound"); dispersion index var/mean.
//     bench hyper [seeds=3] [N=200000]
//         hypergraph counters: per-insertion work and stash routing binned by the density E/V of the component the key
//         lands in, final component statistics, and the offline minimum stash (N - maximum matching, Hall deficiency)
//         against the stash the scheme actually used.
//     bench merge [N=2000000] [reps=7]
//         same scheme with key and occupancy merged into one array (sentinel = all ones): verifies identical behaviour,
//         then times positive and negative lookups of both layouts.
//   v5.8 mode (new; none changes an existing mode):
//     bench hyperfine [seeds=20] [N=200000] -c hyperfine.csv
//         the builds and the density statistic of `hyper` at the loads 0.84 / 0.88 / 0.90 / 0.92 (override with -a), one CSV row per (alpha, seed, density bin, component-size bin):
//         insertions, stash arrivals, sum of density, sum of rounds, sum of min(density,1)^16. Nine density bins (<0.50, 0.50-0.75, then steps of 0.05 up to 1.00, 1.00-1.10, >=1.10)
//         and four component-size bins (<129, 129-2048, 2049-16384, >16384 slots). hyperfine_report.py turns it into rates with seed-resampled intervals and
//         the cross-load test of the paper's local-density statement.
//   v5.7 mode (new; none changes an existing mode):
//     bench satcomp [seeds=3] -c satcomp.csv
//         the builds of `sat` (same keys, same seeds, exact integer m), plus a union-find over the slots: for every insertion the number of
//         slots of the component(s) the key joins (before its own hyperedge is added) and whether the insertion reached the stash.
//         Per (alpha, MaxKicks, m): routedFrac (reproduces `sat`), its standard error over the builds, the mean / 99th percentile / maximum of that
//         component size, and counts of insertions and stash arrivals per component-size bin. At the loads of `sat` the component a key joins is a large part of all
//         slots (it grows in proportion to m), so the bins separate m from local structure only weakly; what the file settles is the noise of the rate (its standard
//         error over the builds) and the size at which it saturates.
//   v5.6 options (default behaviour and output are unchanged when neither is given):
//     -d D          number of sub-tables/hash functions of the PROPOSED scheme (2..16, default 3) in ext, sweep, tail, sens, sat, lookup,
//                   rehashcost, window, hyper, merge and main. Table sizes use d (m = N/(alpha*d)). Default CSV names get a _d<D> suffix
//                   (sens_d4.csv, ...) so a d=3 file is never overwritten. Ignored (with a note) by retrybug and rehashclassical.
//     -a a1,a2,..   replace the built-in load list of those modes (0 < alpha < 1). For `main` the first value is the target load.
//                   Offline load thresholds (one key per cell): d=3 0.9179, d=4 0.9768, d=5 0.9924; above them no placement stores all keys.
//     lookup scheme names: pNN = proposed at alpha NN/100 (p45, p80, p88 as before), pNNN = alpha NNN/1000 (p945 = 0.945).
//   Options added: -k <keys.bin> little-endian u64 keys (e.g. pcap2flows.py --keys); every mode that draws keys then uses the file
//                  (first-seen order kept, duplicates dropped, N clamped to the file size; seeds then vary hashes only).
//                  -T <seconds> wall-clock cap for `main` (blocks after the cap are skipped; a block cut short reports nothing).
//   v5 adds ITERATION counts to the sweep CSV, next to the latencies (insItersPerOp, maxInsIters,
//   insItersPerRun, lookItersPerOp, maxLookIters). One iteration means:
//     linear probing : one probe step              chained : one chain node scanned (+1 for the append)
//     classical cuckoo: one table visit (an eviction or the final placement; one PR loop pass = 2)
//     proposed       : one kick round (check d cells, then evict); nested RehashStash rounds included
//   Insert counts exclude the opening duplicate-check lookup. Lookup counts = cells/nodes actually visited.
//   Build with -DNO_ITERS to remove all counters (iteration columns then read 0) for latency-only runs.
//   v4 notes follow.
//   Changes vs v3: classical baseline now reports BOTH a short fixed loop and Pagh-Rodler's prescribed
//   MaxLoop (r = per-table size, 1+eps = m/n); -o <file> writes the report without shell redirection
//   (PowerShell-safe); `sweep` mode writes a CSV over N = 10..1,000,000; carried-key retry fix and
//   missing-key verification are kept.
//
// Build:   g++ -O2 -std=c++17 -o bench bench.cpp          (Windows: bench.exe)
// Modes:   bench [main [N]]                   main tables (default N = 2000000)
//          bench ext [seeds] [N]              multi-seed sweeps for the TBD cells
//          bench sweep [seeds] [maxN]         size sweep -> CSV (default 5 seeds, maxN 1000000)
//          bench tail [N] [builds]            many builds at ONE N -> tail.csv (rare-event sampling; counting build only)
//          bench sens [seeds=5] [N=2000000]   Table VI: MaxKicks and stash-size sensitivity -> sens.csv (counting build only)
//          bench sat  [seeds=3]               stash routing vs table size at EXACT integer load -> sat.csv (counting build only)
//          (options -d and -a: see v5.6 above)
//          bench retrybug [seeds=5] [N=200000] reproduces the retired wrong-key retry (correct vs retired, same inputs)
//          bench lookup <scheme> <N> <reps>   build ONE table, then <reps> shuffled lookup passes; prints ns/lookup.
//                                             scheme: linear | chained | classical | p45 | p80 | p88. Run under `perf stat`
//                                             once with reps=0 and once with reps=R and subtract (see run_all.sh, perf_summarize.py).
// Options: -o <report.txt>   write the text report here (default: stderr)
//          -c <data.csv>     CSV path for sweep (default sweep.csv)
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <random>
#include <sstream>
#include <string>
#include <unordered_set>
#include <vector>
using namespace std;
using u64 = uint64_t;
using i64 = long long;
using Clock = chrono::steady_clock;
#ifdef NO_ITERS
#define CNT(x)
#else
#define CNT(x) x
#endif

// ---- v5.5 globals ----
static inline i64 nsSince(Clock::time_point t0, Clock::time_point t1){
    return chrono::duration_cast<chrono::nanoseconds>(t1-t0).count();
}
static vector<u64> g_fileKeys; static bool g_useFile=false;                         // -k keys.bin
static bool g_capOn=false, g_capTripped=false; static Clock::time_point g_deadline;  // -T seconds (main mode only)
static inline bool capHit(){
    if(!g_capOn) return false;
    if(g_capTripped) return true;
    static unsigned c=0;
    if(((++c) & 0x3FFFu)==0 && Clock::now()>=g_deadline) g_capTripped=true;
    return g_capTripped;
}

static inline u64 splitmix64(u64 x) {
    x += 0x9E3779B97F4A7C15ULL;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}
struct HashFn {
    u64 seed;
    HashFn(u64 s=0): seed(s) {}
    inline u64 operator()(u64 key) const { return splitmix64(key ^ seed); }
};

// ---------- Linear probing ----------
struct LinearProbing {
    vector<u64> table; vector<char> occ; size_t cap; size_t n=0; HashFn h; i64 insIters=0, lkIters=0;
    LinearProbing(size_t c, u64 seed): table(c,0), occ(c,0), cap(c), h(seed) {}
    i64 insert(u64 key){
        size_t idx=h(key)%cap; i64 probes=0;
        for(size_t i=0;i<cap;i++){
            probes++; CNT(insIters++;) size_t p=(idx+i)%cap;
            if(!occ[p]){ occ[p]=1; table[p]=key; n++; return probes; }
            if(table[p]==key) return probes;
        }
        return -1;
    }
    i64 lookup(u64 key){
        size_t idx=h(key)%cap; i64 probes=0;
        for(size_t i=0;i<cap;i++){ probes++; CNT(lkIters++;) size_t p=(idx+i)%cap;
            if(!occ[p]) return probes;
            if(table[p]==key) return probes; }
        return -1;
    }
};

// ---------- Chained hashing ----------
struct ChainedHashing {
    vector<vector<u64>> table; size_t cap; size_t n=0; HashFn h; i64 insIters=0, lkIters=0;
    ChainedHashing(size_t c, u64 seed): table(c), cap(c), h(seed) {}
    i64 insert(u64 key){
        auto &b=table[h(key)%cap];
        for(u64 k: b){ CNT(insIters++;) if(k==key) return (i64)b.size(); }
        CNT(insIters++;) b.push_back(key); n++; return (i64)b.size();
    }
    i64 lookup(u64 key){
        auto &b=table[h(key)%cap]; i64 probes=0;
        for(u64 k: b){ probes++; CNT(lkIters++;) if(k==key) return probes; }
        return probes+1;
    }
};

// ---------- Classical 2-way cuckoo (Pagh-Rodler) ----------
// Two tables of m cells each. maxLoop is given explicitly:
//   shortLoop(m)   = ceil(3 log2(2m))                   (eps=1, r=2m: what the first harness used)
//   prescribedLoop = ceil(3 ln m / ln(m/n))             (r=m per table, 1+eps = m/n, as in Pagh-Rodler)
// v5.6: -d / -a
static int g_d=3; static bool g_dSet=false; static vector<double> g_alphas;
static vector<double> alphasOr(initializer_list<double> def){ return g_alphas.empty()? vector<double>(def) : g_alphas; }
static string dCsv(const string& base){ if(g_d==3) return base; size_t q=base.rfind('.'); string t="_d"+to_string(g_d); return q==string::npos? base+t : base.substr(0,q)+t+base.substr(q); }
static i64 shortLoop(size_t m){ return max<i64>(4,(i64)ceil(3.0*log(2.0*m)/log(2.0))); }
static i64 prescribedLoop(size_t m, size_t n){
    double eps=(double)m/(double)n-1.0; if(eps<=1e-9) return 1000000;
    return max<i64>(4,(i64)ceil(3.0*log((double)m)/log(1.0+eps)));
}
// v5.5: optional per-rehash log (only filled when g_timeRehash is set; `rehashclassical` mode).
//   depth 0 = outermost rehash, 1 = a rehash triggered while re-inserting inside depth 0, and so on.
//   inclNs includes nested rehashes; exclNs subtracts them.
struct RehashRec{ i64 inclNs, exclNs, keys; int depth; };
static bool g_timeRehash=false;
struct ClassicalCuckoo {
    vector<u64> T1,T2; vector<char> occ1,occ2; size_t m;
    HashFn h1,h2; size_t n=0; i64 maxLoop; i64 fullRehashes=0; mt19937_64 rng; i64 insIters=0, lkIters=0;
    int rhDepth=0, maxRhDepth=0;            // current / maximum rehash nesting level (1 = rehashes never nest)
    vector<RehashRec> rehashLog; vector<i64> childAcc;
    ClassicalCuckoo(size_t m_, i64 maxLoop_, u64 seed): T1(m_,0),T2(m_,0),occ1(m_,0),occ2(m_,0),
        m(m_), h1(seed*2+1), h2(seed*2+2), maxLoop(maxLoop_), rng(seed) {}
    i64 lookup(u64 key){
        CNT(lkIters++;) size_t a=h1(key)%m; if(occ1[a] && T1[a]==key) return 1;
        CNT(lkIters++;) size_t b=h2(key)%m; if(occ2[b] && T2[b]==key) return 2;
        return -1;
    }
    // returns evictions used; on full rehash returns maxLoop (recorded as such in the kick arrays)
    i64 insert(u64 key){
        if(lookup(key)>0) return 0;
        u64 cur=key; i64 kicks=0;
        for(i64 it=0; it<maxLoop; it++){
            CNT(insIters++;) size_t p1=h1(cur)%m;
            if(!occ1[p1]){ occ1[p1]=1; T1[p1]=cur; n++; return kicks; }
            u64 ev=T1[p1]; T1[p1]=cur; cur=ev; kicks++;
            CNT(insIters++;) size_t p2=h2(cur)%m;
            if(!occ2[p2]){ occ2[p2]=1; T2[p2]=cur; n++; return kicks; }
            ev=T2[p2]; T2[p2]=cur; cur=ev; kicks++;
        }
        fullRehashes++;
        int myDepth=rhDepth; Clock::time_point rt0; if(g_timeRehash) rt0=Clock::now();
        rhDepth++; if(rhDepth>maxRhDepth) maxRhDepth=rhDepth;
        vector<u64> all;
        for(size_t i=0;i<m;i++){ if(occ1[i]) all.push_back(T1[i]); if(occ2[i]) all.push_back(T2[i]); }
        all.push_back(cur);
        fill(occ1.begin(),occ1.end(),0); fill(occ2.begin(),occ2.end(),0);
        n=0; h1=HashFn(rng()); h2=HashFn(rng());
        for(u64 k: all) insert(k);   // recursive; nested rehashes possible
        rhDepth--;
        if(g_timeRehash){
            i64 incl=nsSince(rt0, Clock::now());
            if(childAcc.size()<(size_t)myDepth+2) childAcc.resize(myDepth+2,0);
            i64 excl=incl-childAcc[myDepth+1]; childAcc[myDepth+1]=0; childAcc[myDepth]+=incl;
            rehashLog.push_back({incl, excl, (i64)all.size(), myDepth});
        }
        return maxLoop;
    }
};

// Reproduction switch for the retired retry defect (default false = corrected code). Only the `retrybug` mode sets it.
static bool g_buggyRetry=false;

// v5.5 probe (`rehashcost` mode): at the first <maxEvents> stash-overflow events of a build, the real RehashStash is timed
// and, on an identical COPY of the table taken just before it, a full rebuild with fresh hash functions is timed too.
// The copy is private: nothing the probe does reaches the original table or its eviction RNG.
struct ProbeRec{ i64 nAtEvent, stashKeys, rsNs, rsRounds, rsNested, fbNs, fbKeys, fbRounds, fbStashRouted, fbOverflow; int rsExtraDepth, fbFirst; };
struct ProbeCfg{ bool on=false; size_t maxEvents=50; vector<ProbeRec> recs; };
static ProbeCfg g_probe;

// ---------- Proposed: d-ary bounded-displacement cuckoo with stash ----------
struct BoundedCuckoo {
    int d; size_t m; vector<vector<u64>> T; vector<vector<char>> occ; vector<HashFn> h; size_t n=0;
    vector<u64> stash; size_t stashCap; vector<char> stashOcc;
    vector<u64> spill;            // stand-in for a full rebuild when the depth guard trips
    i64 maxKicks;
    i64 incrementalRehashes=0, stashOverflowEvents=0, stashRoutedCount=0;
    i64 peakStashOcc=0; double sumStashOcc=0; i64 stashSamples=0;
    i64 fullRehashesFromStuckStash=0;   // = depth-guard trips
    i64 insIters=0, lkIters=0;
    int maxDepthSeen=0;                 // deepest nested-reinsertion level reached (v5.5; counted only when counters are on)
    mt19937_64 rng;
    BoundedCuckoo(int d_, size_t m_, i64 maxKicks_, size_t stashCap_, u64 seed)
        : d(d_), m(m_), T(d_, vector<u64>(m_,0)), occ(d_, vector<char>(m_,0)),
          stash(stashCap_,0), stashCap(stashCap_), stashOcc(stashCap_,0),
          maxKicks(maxKicks_), rng(seed) {
        for(int i=0;i<d;i++) h.push_back(HashFn(seed*10+i+7));
    }
    i64 lookup(u64 key){
        for(int i=0;i<d;i++){ CNT(lkIters++;) size_t p=h[i](key)%m; if(occ[i][p] && T[i][p]==key) return i+1; }
        for(size_t j=0;j<stashCap;j++){ CNT(lkIters++;) if(stashOcc[j] && stash[j]==key) return d+1; }
        for(u64 k: spill){ CNT(lkIters++;) if(k==key) return d+2; }
        return -1;
    }
    i64 currentStashOcc(){ i64 c=0; for(size_t j=0;j<stashCap;j++) if(stashOcc[j]) c++; return c; }
    // returns evictions used; -2 if stashed; -4 if depth guard tripped
    i64 insertInner(u64 key, int depth=0){
        if(lookup(key)>0) return 0;
        CNT(if(depth>maxDepthSeen) maxDepthSeen=depth;)
        u64 cur=key; i64 kicks=0;
        for(i64 round=0; round<maxKicks; round++){
            CNT(insIters++;)
            for(int i=0;i<d;i++){
                size_t p=h[i](cur)%m;
                if(!occ[i][p]){ occ[i][p]=1; T[i][p]=cur; n++; return kicks; }
            }
            int i=(int)(rng()%d); size_t p=h[i](cur)%m;
            u64 ev=T[i][p]; T[i][p]=cur; cur=ev; kicks++;
        }
        for(size_t j=0;j<stashCap;j++){
            if(!stashOcc[j]){ stashOcc[j]=1; stash[j]=cur; n++; stashRoutedCount++;
                i64 so=currentStashOcc(); sumStashOcc+=so; stashSamples++;
                peakStashOcc=max(peakStashOcc,so); return -2; }
        }
        stashOverflowEvents++;
        if(depth>=20){ fullRehashesFromStuckStash++; spill.push_back(cur); n++; return -4; }
        if(g_probe.on && depth==0) rehashProbed(depth+1, cur); else incrementalRehashStash(depth+1);
        return insertInner(g_buggyRetry ? key : cur, depth+1);   // corrected: retry the CARRIED key `cur`; g_buggyRetry=true reproduces the retired defect (retries the original `key`)
    }
    // h[] stays fixed: redrawing it would orphan every resident key.
    void incrementalRehashStash(int depth){
        incrementalRehashes++;
        vector<u64> S;
        for(size_t j=0;j<stashCap;j++) if(stashOcc[j]) S.push_back(stash[j]);
        fill(stashOcc.begin(),stashOcc.end(),0);
        n-=S.size();
        for(u64 k: S) insertInner(k, depth);
    }
    i64 insert(u64 key){ return insertInner(key); }

    // ---- v5.5: full rebuild with fresh hash functions (used on a private copy by the probe; not part of the scheme) ----
    // Gathers every key (table, stash, spill, plus the in-flight carried key), draws new hash seeds, reinserts all.
    void fullRebuildFresh(u64 newSeed, u64 carried){
        vector<u64> all; all.reserve(n+1);
        for(int i=0;i<d;i++) for(size_t p=0;p<m;p++) if(occ[i][p]) all.push_back(T[i][p]);
        for(size_t j=0;j<stashCap;j++) if(stashOcc[j]) all.push_back(stash[j]);
        for(u64 k: spill) all.push_back(k);
        all.push_back(carried);
        for(int i=0;i<d;i++){ fill(occ[i].begin(),occ[i].end(),0); h[i]=HashFn(newSeed*10+i+7); }
        fill(stashOcc.begin(),stashOcc.end(),0); spill.clear(); n=0;
        for(u64 k: all) insertInner(k,0);
    }
    // Same effect on this table as incrementalRehashStash(depth), plus (for the first events) a timed rebuild of a copy.
    void rehashProbed(int depth, u64 cur){
        if(g_probe.recs.size() >= g_probe.maxEvents){ incrementalRehashStash(depth); return; }
        size_t ev=g_probe.recs.size();
        ProbeRec r{}; r.nAtEvent=(i64)n+1; r.stashKeys=currentStashOcc(); r.fbFirst=(int)(ev&1);
        BoundedCuckoo cp(*this);                       // identical state, in-flight key `cur` still outside
        auto runActual=[&](){
            i64 r0=insIters, v0=incrementalRehashes; maxDepthSeen=depth;
            auto t0=Clock::now(); incrementalRehashStash(depth); auto t1=Clock::now();
            r.rsNs=nsSince(t0,t1); r.rsRounds=insIters-r0; r.rsNested=incrementalRehashes-v0; r.rsExtraDepth=maxDepthSeen-depth;
        };
        auto runRebuild=[&](){
            bool was=g_probe.on; g_probe.on=false;
            i64 r0=cp.insIters, s0=cp.stashRoutedCount, o0=cp.stashOverflowEvents;
            auto t0=Clock::now(); cp.fullRebuildFresh(0xC0FFEEULL+ev, cur); auto t1=Clock::now();
            r.fbNs=nsSince(t0,t1); r.fbKeys=(i64)n+1; r.fbRounds=cp.insIters-r0;
            r.fbStashRouted=cp.stashRoutedCount-s0; r.fbOverflow=cp.stashOverflowEvents-o0;
            g_probe.on=was;
        };
        if(r.fbFirst){ runRebuild(); runActual(); } else { runActual(); runRebuild(); }
        g_probe.recs.push_back(r);
    }
};

// ---------- reporting helpers ----------
template<typename F>
void percentileReport(vector<i64>& samples, F conv, const string& label){
    sort(samples.begin(), samples.end());
    size_t N=samples.size();
    auto pct=[&](double p)->i64{ return samples[(size_t)(p*(N-1))]; };
    cerr << label << " N=" << N << " p50=" << conv(pct(0.50)) << " p99=" << conv(pct(0.99))
         << " p999=" << conv(pct(0.999)) << " max=" << conv(samples.back()) << "\n";
}
template<typename T>
void lookupLatency(T& t, const vector<u64>& keys, size_t ops, const string& label){
    vector<i64> lat; lat.reserve(ops);
    for(size_t i=0;i<ops;i++){
        if(capHit()) break;
        u64 k=keys[(i*7919)%keys.size()];
        auto s=Clock::now(); volatile i64 sink=t.lookup(k); (void)sink; auto e=Clock::now();
        lat.push_back(chrono::duration_cast<chrono::nanoseconds>(e-s).count());
    }
    if(g_capTripped){ cerr << label << " ABORTED: -T time cap reached (partial sample not reported)\n"; return; }
    percentileReport(lat, [](i64 x){return x;}, label);
}
// Keys: with -k, the first N keys of the file; otherwise N distinct mt19937_64(s) outputs (identical to the earlier
// versions: the fast path draws N values and only if a duplicate exists falls back to the original reject loop).
static vector<u64> makeKeys(size_t N, u64 s){
    if(g_useFile){ size_t n=min(N,g_fileKeys.size()); return vector<u64>(g_fileKeys.begin(), g_fileKeys.begin()+n); }
    { mt19937_64 r(s); vector<u64> k(N); for(size_t i=0;i<N;i++) k[i]=r();
      vector<u64> c(k); sort(c.begin(), c.end());
      if(adjacent_find(c.begin(), c.end())==c.end()) return k; }
    mt19937_64 r(s); vector<u64> k(N);
    unordered_set<u64> seen; seen.reserve(N*2);
    for(size_t i=0;i<N;i++){ u64 x; do{ x=r(); }while(!seen.insert(x).second); k[i]=x; }
    return k;
}
static bool loadKeyFile(const string& path){
    FILE* f=fopen(path.c_str(),"rb"); if(!f) return false;
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    vector<u64> raw((size_t)(sz/8)); size_t got=raw.empty()?0:fread(raw.data(),8,raw.size(),f); fclose(f); raw.resize(got);
    unordered_set<u64> seen; seen.reserve(raw.size()*2); g_fileKeys.clear(); g_fileKeys.reserve(raw.size());
    for(u64 x: raw) if(seen.insert(x).second) g_fileKeys.push_back(x);
    cerr << "key file " << path << ": " << raw.size() << " records, " << g_fileKeys.size() << " distinct ("
         << raw.size()-g_fileKeys.size() << " duplicates dropped)" << (sz%8? "; WARNING: size not a multiple of 8":"") << "\n";
    g_useFile=true; return !g_fileKeys.empty();
}
static void meanSd(const vector<double>& v, double& m, double& sd){
    m=0; for(double x: v) m+=x; m/=v.size();
    double s=0; for(double x: v) s+=(x-m)*(x-m);
    sd = v.size()>1 ? sqrt(s/(v.size()-1)) : 0.0;
}
static void classicalBlock(const string& label, const vector<u64>& keys, double alpha, i64 maxLoop, u64 seed, size_t lookupOps){
    size_t N=keys.size(); size_t m=(size_t)(N/(alpha*2.0));
    ClassicalCuckoo cc(m, maxLoop, seed);
    vector<i64> insLat, ik; insLat.reserve(N); ik.reserve(N);
    for(u64 k: keys){ if(capHit()) break; auto s=Clock::now(); i64 kk=cc.insert(k); auto e=Clock::now();
        insLat.push_back(nsSince(s,e)); ik.push_back(kk); }
    if(g_capTripped){ cerr << label << " ABORTED: -T time cap reached (no numbers reported for it)\n"; return; }
    double avg=0; i64 miss=0; for(u64 k: keys){ i64 r=cc.lookup(k); if(r<0){ miss++; r=2; } avg+=r; } avg/=N;
    i64 maxK=*max_element(ik.begin(), ik.end());
    cerr << label << " load=" << (double)cc.n/(2*m) << " stored=" << cc.n << "/" << N << " missing=" << miss
         << " maxLoopParam=" << cc.maxLoop << " avgLookupProbes=" << avg << " maxKicksObserved=" << maxK
         << " fullRehashes=" << cc.fullRehashes << "\n";
    sort(ik.begin(), ik.end()); size_t Nn=ik.size();
    cerr << label << " kicks(rehash events recorded as maxLoop) p50=" << ik[(size_t)(0.50*(Nn-1))]
         << " p99=" << ik[(size_t)(0.99*(Nn-1))] << " p999=" << ik[(size_t)(0.999*(Nn-1))] << " max=" << ik.back() << "\n";
    percentileReport(insLat, [](i64 x){return x;}, label+" insertLatencyNs");
    lookupLatency(cc, keys, lookupOps, label+" lookupLatencyNs");
}

// ---------- EXT: multi-seed sweeps for the TBD cells ----------
static void runExt(size_t N, int seeds){
    cerr << fixed << setprecision(4);
    cerr << "\n=== EXT: N=" << N << " seeds=" << seeds << " (mean +- sample sd over seeds) ===\n";
    vector<vector<u64>> K(seeds);
    for(int s=0;s<seeds;s++) K[s]=makeKeys(N, 1000+s);
    for(int variant=0; variant<2; variant++){          // 0 = short loop, 1 = prescribed loop
      for(double a : {0.30, 0.40, 0.45, 0.49}){
        vector<double> rh, mk, mxms; i64 missMax=0, loopSeen=0;
        for(int s=0;s<seeds;s++){
            size_t m=(size_t)(N/(a*2.0));
            i64 ml = variant==0 ? shortLoop(m) : prescribedLoop(m, N);
            ClassicalCuckoo cc(m, ml, 5000+s); loopSeen=ml;
            i64 mxk=0; double mxns=0;
            for(u64 k: K[s]){
                auto t0=Clock::now(); i64 kk=cc.insert(k); auto t1=Clock::now();
                mxk=max(mxk,kk); mxns=max(mxns,(double)nsSince(t0,t1));
            }
            i64 miss=0; for(u64 k: K[s]) if(cc.lookup(k)<0) miss++;
            missMax=max(missMax,miss);
            rh.push_back((double)cc.fullRehashes); mk.push_back((double)mxk); mxms.push_back(mxns/1e6);
        }
        double a1,b1,a2,b2,a3,b3; meanSd(rh,a1,b1); meanSd(mk,a2,b2); meanSd(mxms,a3,b3);
        cerr << "[EXT classical " << (variant==0?"short":"prescribed") << " maxLoop=" << loopSeen
             << "] alpha=" << a << " fullRehashes=" << a1 << "+-" << b1
             << " maxKicksOrLoop=" << a2 << "+-" << b2 << " maxInsertMs=" << a3 << "+-" << b3
             << " missingMax=" << missMax << "\n";
        cout << "ext classical " << (variant==0?"short":"prescribed") << " alpha=" << a << " done\n";
      }
    }
    for(double a : alphasOr({0.30, 0.45, 0.75, 0.80, 0.88})){
      for(i64 mkk : {16LL, 32LL, 48LL, 64LL}){
        vector<double> rp, ov, gt, mxms; i64 missMax=0, peak=0; double load=0;
        for(int s=0;s<seeds;s++){
            size_t m=(size_t)(N/(a*g_d));
            BoundedCuckoo bc(g_d, m, mkk, 4, 7000+s+mkk);
            double mxns=0;
            for(u64 k: K[s]){
                auto t0=Clock::now(); bc.insert(k); auto t1=Clock::now();
                mxns=max(mxns,(double)nsSince(t0,t1));
            }
            i64 miss=0; for(u64 k: K[s]) if(bc.lookup(k)<0) miss++;
            missMax=max(missMax,miss); peak=max(peak,bc.peakStashOcc);
            load=(double)bc.n/((double)g_d*m);
            rp.push_back((double)bc.stashRoutedCount/N); ov.push_back((double)bc.stashOverflowEvents);
            gt.push_back((double)bc.fullRehashesFromStuckStash); mxms.push_back(mxns/1e6);
        }
        double a1,b1,a2,b2,a3,b3,a4,b4; meanSd(rp,a1,b1); meanSd(ov,a2,b2); meanSd(gt,a3,b3); meanSd(mxms,a4,b4);
        cerr << "[EXT proposed d=" << g_d << " s=4] alpha=" << a << " MaxKicks=" << mkk
             << " routingProb=" << a1 << "+-" << b1 << " overflowEvents=" << a2 << "+-" << b2
             << " depthGuardTrips=" << a3 << "+-" << b3 << " peakStash=" << peak
             << " maxInsertMs=" << a4 << "+-" << b4 << " loadLastSeed=" << load
             << " missingMax=" << missMax << "\n";
        cout << "ext proposed alpha=" << a << " MaxKicks=" << mkk << " done\n";
      }
    }
    cerr << "EXT done.\n";
}

// ---------- SWEEP: N = 10..90, 100..900, ..., 100000..900000, 1000000 -> CSV ----------
// Per (scheme, N, seed): `reps` fresh builds (reps ~ 1e6/N) so tiny N get measurable times.
// "work": probes (linear probing, chained) or evictions (cuckoo; rehash/stash events counted as
// the loop/kick cap). "cells": key cells allocated (chained = buckets + N entries; proposed = d*m + s).
struct Acc {
    double insNs=0, lookNs=0, insWork=0, lookProbes=0; i64 maxInsWork=0, maxLookProbes=0;
    double rehash=0, routed=0, overflow=0, trips=0; i64 missingMax=0;
    double insIters=0, lookIters=0; i64 maxInsIters=0, maxLookIters=0;
};
static i64 workOf(const LinearProbing&, i64 r, i64){ return r; }
static i64 workOf(const ChainedHashing&, i64 r, i64){ return r; }
static i64 workOf(const ClassicalCuckoo&, i64 r, i64){ return r; }
static i64 workOf(const BoundedCuckoo& t, i64 r, i64){ return r<0 ? t.maxKicks : r; }
static i64 storedOf(const LinearProbing& t){ return (i64)t.n; }
static i64 storedOf(const ChainedHashing& t){ return (i64)t.n; }
static i64 storedOf(const ClassicalCuckoo& t){ return (i64)t.n; }
static i64 storedOf(const BoundedCuckoo& t){ return (i64)t.n; }
template<typename T> static void onePass(T& t, const vector<u64>& keys, Acc& a){
    volatile i64 sink=0;
    auto t0=Clock::now();
    i64 w=0, wmax=0, it=0, itmax=0;
    for(u64 k: keys){ CNT(i64 i0=t.insIters;) i64 r=t.insert(k); i64 x=workOf(t,r,0); w+=x; wmax=max(wmax,x);
        CNT(i64 di=t.insIters-i0; it+=di; itmax=max(itmax,di);) }
    auto t1=Clock::now();
    i64 pr=0, pmax=0, miss=0, li=0, limax=0;
    for(u64 k: keys){ CNT(i64 l0=t.lkIters;) i64 r=t.lookup(k); if(r<0){ miss++; r=0; } pr+=r; pmax=max(pmax,r); sink=sink+r;
        CNT(i64 dl=t.lkIters-l0; li+=dl; limax=max(limax,dl);) }
    auto t2=Clock::now();
    miss=max(miss, (i64)keys.size()-storedOf(t));
    a.insNs+=(double)nsSince(t0,t1); a.lookNs+=(double)nsSince(t1,t2);
    a.insWork+=(double)w; a.maxInsWork=max(a.maxInsWork,wmax);
    a.lookProbes+=(double)pr; a.maxLookProbes=max(a.maxLookProbes,pmax);
    a.missingMax=max(a.missingMax,miss);
    a.insIters+=(double)it; a.maxInsIters=max(a.maxInsIters,itmax);
    a.lookIters+=(double)li; a.maxLookIters=max(a.maxLookIters,limax);
}
static void writeRow(ofstream& csv, const string& scheme, double alpha, size_t N, int seed, i64 reps, size_t cells, const Acc& a){
    double ops=(double)reps*(double)N;
    csv << scheme << "," << alpha << "," << N << "," << seed << "," << reps << "," << cells << ","
        << (double)cells/(double)N << "," << a.insNs/ops << "," << a.lookNs/ops << ","
        << a.insWork/ops << "," << a.maxInsWork << "," << a.lookProbes/ops << "," << a.maxLookProbes << ","
        << a.rehash/reps << "," << a.routed/reps << "," << a.overflow/reps << "," << a.trips/reps << ","
        << a.missingMax << ","
        << a.insIters/ops << "," << a.maxInsIters << "," << a.insIters/(double)reps << ","
        << a.lookIters/ops << "," << a.maxLookIters << "\n";
}
static void runSweep(int seeds, size_t maxN, const string& csvPath){
    ofstream csv(csvPath);
    if(!csv){ cerr << "cannot open " << csvPath << "\n"; return; }
    csv << setprecision(7);
    csv << "scheme,alpha,N,seed,reps,cells,cellsPerKey,insNsPerOp,lookNsPerOp,meanInsWork,maxInsWork,"
           "meanLookProbes,maxLookProbes,rehashesPerRun,stashRoutedPerRun,overflowPerRun,guardTripsPerRun,missingMax,"
           "insItersPerOp,maxInsIters,insItersPerRun,lookItersPerOp,maxLookIters\n";
    vector<size_t> sizes;
    for(size_t dec=10; dec<=100000; dec*=10) for(size_t mult=1; mult<=9; mult++) sizes.push_back(mult*dec);
    sizes.push_back(1000000);
    sizes.erase(remove_if(sizes.begin(), sizes.end(), [&](size_t n){ return n>maxN; }), sizes.end());
    cerr << "SWEEP: " << sizes.size() << " sizes, " << seeds << " seeds -> " << csvPath << "\n";
    for(size_t N: sizes){
        i64 reps = max<i64>(1, min<i64>(100000, 1000000/(i64)N));
        for(int s=0;s<seeds;s++){
            vector<u64> keys=makeKeys(N, 1000+s);
            u64 hs = 90000ULL + (u64)s*1000003ULL;
            { Acc a; size_t cap=(size_t)ceil(N/0.70);
              for(i64 r=0;r<reps;r++){ LinearProbing t(cap, hs+r); onePass(t,keys,a); }
              writeRow(csv,"linear_probing",0.70,N,s,reps,cap,a); }
            { Acc a; size_t cap=N;
              for(i64 r=0;r<reps;r++){ ChainedHashing t(cap, hs+r); onePass(t,keys,a); }
              writeRow(csv,"chained",1.00,N,s,reps,cap+N,a); }
            for(int variant=0; variant<2; variant++){
              Acc a; size_t m=(size_t)ceil(N/(0.45*2.0)); i64 ml= variant==0? shortLoop(m) : prescribedLoop(m,N);
              for(i64 r=0;r<reps;r++){ ClassicalCuckoo t(m, ml, hs+r); onePass(t,keys,a); a.rehash+=(double)t.fullRehashes; }
              writeRow(csv, variant==0?"classical_short":"classical_prescribed",0.45,N,s,reps,2*m,a);
            }
            for(double al : alphasOr({0.45, 0.80, 0.88})){
              Acc a; size_t m=(size_t)ceil(N/(al*g_d)); size_t cells=(size_t)g_d*m+4;
              for(i64 r=0;r<reps;r++){ BoundedCuckoo t(g_d, m, 16, 4, hs+r); onePass(t,keys,a);
                a.rehash+=(double)t.incrementalRehashes; a.routed+=(double)t.stashRoutedCount;
                a.overflow+=(double)t.stashOverflowEvents; a.trips+=(double)t.fullRehashesFromStuckStash; }
              ostringstream nm; nm << "proposed_d" << g_d << "_K16_s4_a" << (int)(al*100+0.5);
              writeRow(csv, nm.str(), al, N, s, reps, cells, a);
            }
        }
        csv.flush();
        cout << "sweep N=" << N << " done\n"; cout.flush();
    }
    cerr << "SWEEP done.\n";
}


// ---------- TAIL: rare-event sampling at one N with many builds -> CSV ----------
// The sweep builds each table min(100000, 1e6/N) times per seed, so at large N it sees only a handful of
// builds and cannot sample rare events (a classical rehash). `tail` fixes N and runs MANY builds, so the
// worst single insert (including a full-rehash spike) is actually sampled. Counts are deterministic given the
// seeds, so they do NOT depend on the machine or OS, unlike latencies. Needs the counting build (no -DNO_ITERS).
static void runTail(size_t N, int builds, const string& csvPath){
#ifdef NO_ITERS
    cerr << "tail needs iteration counters: build without -DNO_ITERS\n"; (void)N; (void)builds; (void)csvPath; return;
#else
    bool fresh = true; { ifstream t(csvPath); fresh = !t.good() || t.peek()==ifstream::traits_type::eof(); }
    ofstream csv(csvPath, ios::app);
    if(!csv){ cerr << "cannot open " << csvPath << "\n"; return; }
    if(fresh) csv << "scheme,N,builds,rehashOrOverflowEvents,eventsPerBuild,guardTrips,worstSingleInsertIters,worstOverN,meanItersPerInsert\n";
    vector<u64> keys=makeKeys(N, 1000);
    auto row=[&](const string& nm, i64 ev, i64 trips, i64 worst, double itTot){
        csv << nm << "," << N << "," << builds << "," << ev << "," << (double)ev/builds << "," << trips << ","
            << worst << "," << (double)worst/(double)N << "," << itTot/((double)builds*(double)N) << "\n";
        cout << nm << " N=" << N << " builds=" << builds << " events=" << ev << " worstIters=" << worst
             << " (" << (double)worst/(double)N << " N)\n"; cout.flush();
    };
    for(int variant=0; variant<2; variant++){
        size_t m=(size_t)ceil(N/(0.45*2.0)); i64 ml= variant==0? shortLoop(m) : prescribedLoop(m,N);
        i64 ev=0, worst=0; double it=0;
        for(int r=0;r<builds;r++){
            ClassicalCuckoo t(m, ml, 90000ULL+r); i64 wmax=0;
            for(u64 k: keys){ i64 b=t.insIters; t.insert(k); wmax=max(wmax,t.insIters-b); }
            ev+=t.fullRehashes; worst=max(worst,wmax); it+=(double)t.insIters;
        }
        row(variant==0?"classical_short":"classical_prescribed", ev, 0, worst, it);
    }
    for(double al : alphasOr({0.45, 0.80, 0.88})){
        size_t m=(size_t)ceil(N/(al*g_d));
        i64 ev=0, trips=0, worst=0; double it=0;
        for(int r=0;r<builds;r++){
            BoundedCuckoo t(g_d, m, 16, 4, 90000ULL+r); i64 wmax=0;
            for(u64 k: keys){ i64 b=t.insIters; t.insert(k); wmax=max(wmax,t.insIters-b); }
            ev+=t.stashOverflowEvents; trips+=t.fullRehashesFromStuckStash; worst=max(worst,wmax); it+=(double)t.insIters;
        }
        ostringstream nm; nm << "proposed_d" << g_d << "_K16_s4_a" << (int)(al*100+0.5);
        row(nm.str(), ev, trips, worst, it);
    }
#endif
}


// ---------- SENS: MaxKicks / stash-size sensitivity (paper Table VI) -> CSV ----------
// Block A: d=3, s=4, MaxKicks in {4,8,12,16,24,32,48,64}, at alpha 0.80 and 0.88.
// Block B: d=3, MaxKicks=16, s in {1,2,4,8}, at alpha 0.80 and 0.88.
// Same keys and same hash seed for every setting of one seed, so rows differ only by the parameter.
// Counts are deterministic (machine-independent). Needs the counting build.
static void runSens(int seeds, size_t N, const string& csvPath){
#ifdef NO_ITERS
    cerr << "sens needs iteration counters: build without -DNO_ITERS\n"; (void)seeds; (void)N; (void)csvPath; return;
#else
    ofstream out(csvPath);
    out << "block,alpha,maxKicks,stash,seed,N,m,loadAchieved,routedFrac,overflowEvents,guardTrips,missing,peakStash,meanItersPerInsert,maxInsIters\n";
    out << fixed << setprecision(8);
    vector<vector<u64>> K(seeds);
    for(int s=0;s<seeds;s++) K[s]=makeKeys(N, 1000+s);
    struct Cfg{ char block; double a; i64 mk; size_t st; };
    vector<Cfg> cfgs;
    for(double a : alphasOr({0.80, 0.88})){
        for(i64 mk : {4LL,8LL,12LL,16LL,24LL,32LL,48LL,64LL}) cfgs.push_back({'A',a,mk,4});
        for(size_t st : {1,2,4,8}) cfgs.push_back({'B',a,16,st});
    }
    for(const Cfg& c : cfgs){
        for(int s=0;s<seeds;s++){
            size_t m=(size_t)(N/(c.a*g_d));
            BoundedCuckoo bc(g_d, m, c.mk, c.st, 7000+s);
            i64 mx=0;
            for(u64 k: K[s]){ i64 b=bc.insIters; bc.insert(k); mx=max(mx,bc.insIters-b); }
            i64 miss=0; for(u64 k: K[s]) if(bc.lookup(k)<0) miss++;
            out << c.block << ',' << c.a << ',' << c.mk << ',' << c.st << ',' << s << ',' << N << ',' << m << ','
                << (double)bc.n/((double)g_d*m) << ',' << (double)bc.stashRoutedCount/N << ',' << bc.stashOverflowEvents << ','
                << bc.fullRehashesFromStuckStash << ',' << miss << ',' << bc.peakStashOcc << ','
                << (double)bc.insIters/N << ',' << mx << '\n';
        }
        cout << "sens " << c.block << " alpha=" << c.a << " MaxKicks=" << c.mk << " s=" << c.st << " done\n";
    }
#endif
}

// ---------- SAT: finite-size behaviour of stash routing at exact load -> CSV ----------
// m is an INTEGER per-table size and N = round(alpha*3*m), so no rounding of the table size is involved.
// Tests the conjecture of the paper: the size at which the routing rate saturates grows with alpha and
// with MaxKicks. Many builds at small m, fewer at large m. Deterministic; needs the counting build.
static void runSat(int seeds, const string& csvPath){
#ifdef NO_ITERS
    cerr << "sat needs iteration counters: build without -DNO_ITERS\n"; (void)seeds; (void)csvPath; return;
#else
    ofstream out(csvPath);
    out << "alpha,maxKicks,stash,m,N,builds,routedFrac,meanItersPerInsert\n";
    out << fixed << setprecision(8);
    for(double a : alphasOr({0.80, 0.88, 0.90})){
      for(i64 mk : {4LL, 16LL, 64LL}){
        for(size_t m : {4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144}){
            size_t N=(size_t)llround(a*g_d*m);
            int builds=(int)max<size_t>(3, min<size_t>((size_t)500*seeds, (size_t)3000000/N));
            double routed=0, iters=0;
            for(int r=0;r<builds;r++){
                vector<u64> keys=makeKeys(N, 5000+r);
                BoundedCuckoo t(g_d, m, mk, 4, 777+r);
                for(u64 k: keys) t.insert(k);
                routed+=t.stashRoutedCount; iters+=t.insIters;
            }
            out << a << ',' << mk << ",4," << m << ',' << N << ',' << builds << ','
                << routed/builds/N << ',' << iters/builds/N << '\n';
        }
        cout << "sat alpha=" << a << " MaxKicks=" << mk << " done\n";
      }
    }
#endif
}


// ---------- LOOKUP: steady-state lookup loop for hardware counters (perf stat) ----------
// Builds one table (same keys/seeds as the sweep), then runs `reps` passes of lookups over the keys in a
// shuffled order. With reps=0 only the build runs, so a second run with reps=R minus the first gives the
// counters of the lookup phase alone. Use the clean build (-DNO_ITERS) so no software counters are touched.
template<typename T> static void lookupLoop(T& t, vector<u64> keys, i64 reps, const string& name, size_t N){
    shuffle(keys.begin(), keys.end(), mt19937_64(9));
    volatile i64 sink=0; auto t0=Clock::now();
    for(i64 r=0;r<reps;r++) for(u64 k: keys) sink=sink+t.lookup(k);
    auto t1=Clock::now();
    double ns = reps>0 ? (double)nsSince(t0,t1)/((double)reps*(double)N) : 0.0;
    cout << "lookup scheme=" << name << " N=" << N << " reps=" << reps << " ns_per_lookup=" << ns << " checksum=" << (i64)sink << "\n";
}
static int runLookup(const string& scheme, size_t N, i64 reps){
    vector<u64> keys=makeKeys(N, 1000); u64 hs=90000ULL;
    if(scheme=="linear"){ LinearProbing t((size_t)ceil(N/0.70), hs); for(u64 k:keys) t.insert(k); lookupLoop(t,keys,reps,scheme,N); }
    else if(scheme=="chained"){ ChainedHashing t(N, hs); for(u64 k:keys) t.insert(k); lookupLoop(t,keys,reps,scheme,N); }
    else if(scheme=="classical"){ size_t m=(size_t)ceil(N/(0.45*2.0)); ClassicalCuckoo t(m, shortLoop(m), hs); for(u64 k:keys) t.insert(k); lookupLoop(t,keys,reps,scheme,N); }
    else if(scheme.size()>=3 && scheme.size()<=4 && scheme[0]=='p' && all_of(scheme.begin()+1,scheme.end(),[](char c){return c>='0'&&c<='9';})){
        double al = atoi(scheme.c_str()+1) / (scheme.size()==3 ? 100.0 : 1000.0);
        if(!(al>0 && al<1)){ cerr << "bad load in scheme '" << scheme << "'\n"; return 1; }
        size_t m=(size_t)ceil(N/(al*g_d)); BoundedCuckoo t(g_d, m, 16, 4, hs); for(u64 k:keys) t.insert(k); lookupLoop(t,keys,reps,scheme,N); }
    else { cerr << "unknown scheme '" << scheme << "' (linear|chained|classical|pNN|pNNN, e.g. p88 = proposed at alpha 0.88, p945 = 0.945)\n"; return 1; }
    return 0;
}


// ---------- RETRYBUG: reproduce the retired "retry the wrong key" defect ----------
// bench retrybug [seeds=5] [N=200000] : for each config, build once with the corrected retry and once with the
// retired one (same keys, same hashes, same eviction RNG seed), then count keys that no lookup can find.
static void runRetryBug(int seeds, size_t N){
    cerr << fixed << setprecision(4);
    cerr << "\n=== RETRYBUG: N=" << N << " seeds=" << seeds << " (correct vs retired retry; missing = keys not found by lookup) ===\n";
    struct Cfg{ int d; double a; i64 mk; size_t s; };
    vector<Cfg> cfgs={{3,0.88,8,4},{3,0.88,16,4},{3,0.80,8,4},{3,0.90,16,4}};
    for(auto c: cfgs){
        for(int bug=0; bug<2; bug++){
            double sumMiss=0, sumOv=0, sumTrips=0, sumStored=0; i64 maxMiss=0, minMiss=(i64)1<<60;
            for(int sd=0; sd<seeds; sd++){
                vector<u64> keys=makeKeys(N, 1000+sd);
                size_t m=(size_t)(N/(c.a*c.d));
                g_buggyRetry = (bug==1);
                BoundedCuckoo t(c.d, m, c.mk, c.s, 90000ULL+sd);
                for(u64 k: keys) t.insert(k);
                g_buggyRetry=false;
                i64 miss=0; for(u64 k: keys) if(t.lookup(k)<0) miss++;
                sumMiss+=miss; sumOv+=t.stashOverflowEvents; sumTrips+=t.fullRehashesFromStuckStash; sumStored+=t.n;
                maxMiss=max(maxMiss,miss); minMiss=min(minMiss,miss);
            }
            cerr << "retrybug d=" << c.d << " alpha=" << c.a << " MaxKicks=" << c.mk << " s=" << c.s
                 << " retry=" << (bug?"RETIRED(original key)":"CORRECT(carried key)")
                 << " meanMissing=" << sumMiss/seeds << " minMissing=" << minMiss << " maxMissing=" << maxMiss
                 << " meanOverflowEvents=" << sumOv/seeds << " meanDepthGuardTrips=" << sumTrips/seeds
                 << " meanStoredCount=" << sumStored/seeds << " of N=" << N << "\n";
        }
    }
}


// =====================================================================================================
// v5.5 modes
// =====================================================================================================
template<typename V> static double pctOf(vector<V> v, double p){
    if(v.empty()) return 0;
    sort(v.begin(), v.end()); return (double)v[(size_t)(p*(v.size()-1))];
}

// ---------- REHASHCLASSICAL: per-rehash timing and nesting depth for the classical 2-way cuckoo ----------
static void runRehashClassical(int seeds, size_t N, const string& csvPath){
    cerr << fixed << setprecision(3);
    ofstream csv(csvPath);
    if(!csv){ cerr << "cannot open " << csvPath << "\n"; return; }
    csv << "variant,alpha,N,seed,event,depth,keys,inclNs,exclNs\n";
    cerr << "\n=== REHASHCLASSICAL: N=" << N << " seeds=" << seeds << " (classical 2-way cuckoo; every full rehash timed) ===\n"
         << "depth 0 = outermost rehash; nesting = max rehash nesting level (1 = rehashes never nest); incl = with nested rehashes, excl = without.\n";
    g_timeRehash=true;
    for(int variant=0; variant<2; variant++){
      for(double a : {0.45, 0.49, 0.495}){
        for(int s=0;s<seeds;s++){
            vector<u64> keys=makeKeys(N, 1000+s); size_t n=keys.size();
            size_t m=(size_t)(n/(a*2.0));
            i64 ml = variant==0 ? shortLoop(m) : prescribedLoop(m, n);
            ClassicalCuckoo cc(m, ml, 5000+s);
            i64 maxOpNs=0; double totNs=0;
            for(u64 k: keys){
                auto t0=Clock::now(); cc.insert(k); auto t1=Clock::now();
                i64 ns=nsSince(t0,t1); maxOpNs=max(maxOpNs,ns); totNs+=(double)ns;
            }
            i64 miss=0; for(u64 k: keys) if(cc.lookup(k)<0) miss++;
            i64 outer=0, nested=0, maxIncl=0, maxExcl=0, maxInclOuter=0; double sumOuterIncl=0, sumKeys=0;
            vector<i64> depthHist(8,0);
            for(size_t e=0;e<cc.rehashLog.size();e++){
                const RehashRec& r=cc.rehashLog[e];
                csv << (variant==0?"short":"prescribed") << "," << a << "," << n << "," << s << "," << e << "," << r.depth << ","
                    << r.keys << "," << r.inclNs << "," << r.exclNs << "\n";
                if(r.depth==0){ outer++; sumOuterIncl+=(double)r.inclNs; maxInclOuter=max(maxInclOuter,r.inclNs); } else nested++;
                maxIncl=max(maxIncl,r.inclNs); maxExcl=max(maxExcl,r.exclNs); sumKeys+=(double)r.keys;
                depthHist[min(r.depth,7)]++;
            }
            cerr << "[REHASHCLASSICAL " << (variant==0?"short":"prescribed") << " maxLoop=" << ml << "] alpha=" << a << " seed=" << s
                 << " rehashes=" << cc.fullRehashes << " outermost=" << outer << " nested=" << nested << " nesting=" << cc.maxRhDepth
                 << " depthHist=[" << depthHist[0] << "," << depthHist[1] << "," << depthHist[2] << "," << depthHist[3] << "+]"
                 << " totalInsertSec=" << totNs/1e9 << " outermostRehashShare=" << (totNs>0? sumOuterIncl/totNs : 0.0)
                 << " maxSingleInsertMs=" << maxOpNs/1e6 << " maxOutermostInclMs=" << maxInclOuter/1e6
                 << " maxExclMs=" << maxExcl/1e6 << " meanKeysPerRehash=" << (cc.rehashLog.empty()?0.0:sumKeys/cc.rehashLog.size())
                 << " missing=" << miss << "\n";
        }
      }
    }
    g_timeRehash=false;
    cerr << "REHASHCLASSICAL done; per-event rows in " << csvPath << ".\n";
}

// ---------- REHASHCOST: real RehashStash vs full rebuild of an identical copy ----------
static void runRehashCost(int seeds, size_t N, size_t maxEvents, const string& csvPath){
#ifdef NO_ITERS
    cerr << "rehashcost needs iteration counters: build without -DNO_ITERS\n"; (void)seeds; (void)N; (void)maxEvents; (void)csvPath; return;
#else
    cerr << fixed << setprecision(3);
    ofstream csv(csvPath);
    if(!csv){ cerr << "cannot open " << csvPath << "\n"; return; }
    csv << "alpha,N,seed,event,load,keys,stashKeysAtEvent,rehashStashNs,rehashStashRounds,rehashStashCalls,extraNestingDepth,"
           "rebuildNs,rebuildKeys,rebuildRounds,rebuildStashRouted,rebuildOverflowEvents,rebuildFirst\n";
    cerr << "\n=== REHASHCOST: N=" << N << " seeds=" << seeds << " d=" << g_d << " MaxKicks=16 s=4, first " << maxEvents
         << " stash-overflow events per build ===\n"
         << "RehashStash = the real routine, timed in place. Rebuild = all keys reinserted under fresh hash functions into an identical COPY of the table\n"
         << "taken just before the event (the copy is untouched by the real build; order of the two timings alternates per event).\n";
    g_probe.maxEvents=maxEvents;
    for(double a : alphasOr({0.80, 0.88, 0.90})){
        vector<i64> rsNs, fbNs, rsRounds, fbRounds, extra, fbOv; vector<double> load, ratio; i64 events=0, totalOverflow=0;
        for(int s=0;s<seeds;s++){
            vector<u64> keys=makeKeys(N, 1000+s); size_t n=keys.size(); size_t m=(size_t)(n/(a*g_d));
            g_probe.recs.clear(); g_probe.on=true;
            BoundedCuckoo bc(g_d, m, 16, 4, 90000ULL+s);
            for(u64 k: keys) bc.insert(k);
            g_probe.on=false; totalOverflow+=bc.stashOverflowEvents;
            for(size_t e=0;e<g_probe.recs.size();e++){
                const ProbeRec& r=g_probe.recs[e]; events++;
                double ld=(double)r.nAtEvent/((double)g_d*m);
                csv << a << "," << n << "," << s << "," << e << "," << ld << "," << r.nAtEvent << "," << r.stashKeys << "," << r.rsNs << ","
                    << r.rsRounds << "," << r.rsNested << "," << r.rsExtraDepth << "," << r.fbNs << "," << r.fbKeys << "," << r.fbRounds << ","
                    << r.fbStashRouted << "," << r.fbOverflow << "," << r.fbFirst << "\n";
                rsNs.push_back(r.rsNs); fbNs.push_back(r.fbNs); rsRounds.push_back(r.rsRounds); fbRounds.push_back(r.fbRounds);
                extra.push_back(r.rsExtraDepth); fbOv.push_back(r.fbOverflow); load.push_back(ld);
                if(r.rsNs>0) ratio.push_back((double)r.fbNs/(double)r.rsNs);
            }
        }
        cerr << "[REHASHCOST alpha=" << a << "] events=" << events << " (overflow events in the builds: " << totalOverflow << ")"
             << " loadAtEvent p50=" << pctOf(load,0.5) << " max=" << pctOf(load,1.0) << "\n"
             << "   RehashStash: ns p50=" << pctOf(rsNs,0.5) << " p99=" << pctOf(rsNs,0.99) << " max=" << pctOf(rsNs,1.0)
             << "  rounds p50=" << pctOf(rsRounds,0.5) << " max=" << pctOf(rsRounds,1.0)
             << "  extraNestingDepth max=" << pctOf(extra,1.0) << "\n"
             << "   FullRebuild: ns p50=" << pctOf(fbNs,0.5) << " p99=" << pctOf(fbNs,0.99) << " max=" << pctOf(fbNs,1.0)
             << "  rounds p50=" << pctOf(fbRounds,0.5) << " max=" << pctOf(fbRounds,1.0)
             << "  overflowEventsDuringRebuild max=" << pctOf(fbOv,1.0) << "\n"
             << "   rebuild/RehashStash time ratio: p50=" << pctOf(ratio,0.5) << " min=" << pctOf(ratio,0.0) << " max=" << pctOf(ratio,1.0) << "\n";
    }
    cerr << "REHASHCOST done; per-event rows in " << csvPath << ".\n";
#endif
}

// ---------- WINDOW: the independence check for the stash-overflow bound ----------
#ifndef NO_ITERS
static double binomTailGT(int s, i64 W, double p){      // P(Bin(W,p) > s)
    if(p<=0) return 0;
    if(p>=1) return 1;
    double lp=log(p), lq=log1p(-p);
    auto pmf=[&](i64 k){ return exp(lgamma((double)W+1)-lgamma((double)k+1)-lgamma((double)(W-k)+1)+(double)k*lp+(double)(W-k)*lq); };
    if((double)W*p > (double)s+1){ double c=0; for(i64 k=0;k<=s;k++) c+=pmf(k); return max(0.0,1.0-c); }   // mean above s: 1 - CDF is accurate
    double t=0; for(i64 k=s+1; k<=min<i64>(W, s+200); k++) t+=pmf(k);                                      // mean below s: sum the upper terms
    return min(1.0,t);
}
static double chernoffGT(int s, double mu){              // Theorem bound: Pr[X>s] <= (e mu/s)^s e^-mu, valid for s>mu; else vacuous (1)
    if(mu<=0) return 0;
    if(mu>=s) return 1.0;
    return exp(s*(1.0+log(mu/s)) - mu);
}
#endif
static void runWindow(int seeds, size_t N){
#ifdef NO_ITERS
    cerr << "window needs the stash counters: build without -DNO_ITERS\n"; (void)seeds; (void)N; return;
#else
    cerr << fixed << setprecision(6);
    const int s=4;
    cerr << "\n=== WINDOW: N=" << N << " seeds=" << seeds << " d=" << g_d << " MaxKicks=16 s=" << s << " ===\n"
         << "arrival = an insertion during which at least one key was routed to the stash (the Bernoulli event of the theorem; a RehashStash cascade inside one insertion counts once).\n"
         << "Windows are disjoint blocks of W consecutive insertions.\n"
         << "segment 'all' = the whole build from empty (p rises with load, so it is non-stationary); 'last20' = the final fifth of the build.\n"
         << "binom = exact Pr[Bin(W,phat)>s] with phat = measured arrivals/insertion in that segment; chernoff = the theorem's bound with mu=W*phat (1 = vacuous);\n"
         << "disp = var/mean of arrivals per window (1 for independent rare arrivals; >1 means clustering).\n";
    for(double a : alphasOr({0.80, 0.84, 0.88})){
        vector<vector<unsigned char>> arr(seeds);
        for(int sd=0; sd<seeds; sd++){
            vector<u64> keys=makeKeys(N, 1000+sd); size_t n=keys.size(); size_t m=(size_t)(n/(a*g_d));
            BoundedCuckoo bc(g_d, m, 16, s, 90000ULL+sd);
            arr[sd].resize(n);
            for(size_t i=0;i<n;i++){ i64 b=bc.stashRoutedCount; bc.insert(keys[i]); arr[sd][i]=(bc.stashRoutedCount>b)?1:0; }
        }
        for(int seg=0; seg<2; seg++){
            for(i64 W : {64LL, 256LL, 1024LL, 4096LL}){
                i64 windows=0, over=0; double sumX=0, sumX2=0, ins=0;
                for(int sd=0; sd<seeds; sd++){
                    size_t n=arr[sd].size(); size_t lo = seg==0 ? 0 : n-n/5;
                    for(size_t st=lo; st+(size_t)W<=n; st+=(size_t)W){
                        i64 X=0; for(i64 j=0;j<W;j++) X+=arr[sd][st+j];
                        windows++; if(X>s) over++; sumX+=(double)X; sumX2+=(double)X*(double)X; ins+=(double)W;
                    }
                }
                if(windows==0) continue;
                double mean=sumX/windows, var=sumX2/windows-mean*mean, phat=sumX/ins;
                double obs=(double)over/windows, bn=binomTailGT(s,W,phat), ch=chernoffGT(s,(double)W*phat);
                cerr << "[WINDOW alpha=" << a << " seg=" << (seg==0?"all   ":"last20") << " W=" << W << "] windows=" << windows
                     << " phat=" << phat << " meanPerWindow=" << mean << " disp=" << (mean>0? var/mean : 0.0)
                     << " obsFracOver=" << obs << " binom=" << bn << " chernoff=" << ch
                     << " obs/binom=" << (bn>1e-12? to_string(obs/bn) : string("n/a")) << "\n";
            }
        }
    }
    cerr << "WINDOW done.\n";
#endif
}

// ---------- HYPER: hypergraph counters ----------
// Vertices = slots (d*m of them), one hyperedge per key joining its d slots. Component state is kept with union-find as keys arrive.
struct SlotDSU{
    vector<int> p; vector<i64> E, V;
    SlotDSU(size_t n): p(n), E(n,0), V(n,0) { iota(p.begin(),p.end(),0); }
    int find(int x){ while(p[x]!=x){ p[x]=p[p[x]]; x=p[x]; } return x; }
};
struct HopcroftKarp{    // left = keys, right = slots, d neighbours per key
    int nL,nR,d; const vector<int>& adj; vector<int> mL,mR,dist,it;
    HopcroftKarp(int nL_, int nR_, int d_, const vector<int>& a): nL(nL_),nR(nR_),d(d_),adj(a),mL(nL_,-1),mR(nR_,-1),dist(nL_),it(nL_) {}
    bool bfs(){
        vector<int> q; q.reserve(nL); bool found=false;
        for(int u=0;u<nL;u++){ if(mL[u]<0){ dist[u]=0; q.push_back(u); } else dist[u]=-1; }
        for(size_t h=0;h<q.size();h++){ int u=q[h];
            for(int e=0;e<d;e++){ int v=adj[(size_t)u*d+e]; int w=mR[v];
                if(w<0) found=true; else if(dist[w]<0){ dist[w]=dist[u]+1; q.push_back(w); } } }
        return found;
    }
    bool dfs(int u){
        for(int &e=it[u]; e<d; e++){ int v=adj[(size_t)u*d+e]; int w=mR[v];
            if(w<0 || (dist[w]==dist[u]+1 && dfs(w))){ mL[u]=v; mR[v]=u; return true; } }
        dist[u]=-1; return false;
    }
    int run(){
        int msz=0;
        for(int u=0;u<nL;u++) for(int e=0;e<d;e++){ int v=adj[(size_t)u*d+e]; if(mR[v]<0){ mR[v]=u; mL[u]=v; msz++; break; } }   // greedy start
        while(bfs()){ fill(it.begin(),it.end(),0); for(int u=0;u<nL;u++) if(mL[u]<0 && dfs(u)) msz++; }
        return msz;
    }
};
static void runHyper(int seeds, size_t N){
#ifdef NO_ITERS
    cerr << "hyper needs iteration counters: build without -DNO_ITERS\n"; (void)seeds; (void)N; return;
#else
    cerr << fixed << setprecision(4);
    const int d=g_d; const double bounds[5]={0.5,0.75,0.9,1.0,1.1};
    const char* binName[6]={"<0.50","0.50-0.75","0.75-0.90","0.90-1.00","1.00-1.10",">=1.10"};
    cerr << "\n=== HYPER: N=" << N << " seeds=" << seeds << " d=" << g_d << " MaxKicks=16 s=4 ===\n"
         << "density = E/V of the component a key joins, measured just BEFORE its own hyperedge is added (E = keys inserted so far in the component,\n"
         << "V = slots they touch; 0 for a key whose slots are all untouched). rounds = kick rounds of that insertion (nested RehashStash rounds included).\n"
         << "deficiency = N - maximum matching of the final key/slot graph = the fewest keys ANY placement must leave out (Hall); stashUsed = keys the scheme holds in stash+spill.\n";
    for(double a : alphasOr({0.80, 0.88, 0.92})){
        i64 binN[6]={0}, binRouted[6]={0}, binRoundsSum[6]={0}, binRoundsMax[6]={0};
        i64 locN[256]={0}, locRouted[256]={0}, locRoundsSum[256]={0}, locRoundsMax[256]={0}, allIns=0, blockedIns=0;
        double defSum=0, usedSum=0, maxDens=0; i64 compsSum=0, overCompsSum=0, largestMax=0; i64 usedMax=0, defMax=0; i64 stashedWhileFeasible=0;
        for(int sd=0; sd<seeds; sd++){
            vector<u64> keys=makeKeys(N, 1000+sd); size_t n=keys.size(); size_t m=(size_t)(n/(a*d));
            BoundedCuckoo bc(d, m, 16, 4, 90000ULL+sd);
            SlotDSU dsu((size_t)d*m); vector<int> adj(n*(size_t)d);
            for(size_t i=0;i<n;i++){
                int sl[16]; for(int j=0;j<d;j++) sl[j]=(int)(j*m + bc.h[j](keys[i])%m);
                for(int j=0;j<d;j++) adj[i*d+j]=sl[j];
                // pre-insertion density of the union of the components its touched slots belong to
                int roots[16]; int nr=0; i64 E=0, V=0;
                for(int j=0;j<d;j++){ int r=dsu.find(sl[j]); if(dsu.V[r]==0) continue;      // untouched slot: not yet a vertex
                    bool dup=false; for(int q=0;q<nr;q++) if(roots[q]==r) dup=true;
                    if(!dup){ roots[nr++]=r; E+=dsu.E[r]; V+=dsu.V[r]; } }
                double dens = V>0 ? (double)E/(double)V : 0.0;
                int b=0; while(b<5 && dens>=bounds[b]) b++;
                // local statistic: if all d candidate cells are occupied ('blocked'), count the free cells among the d(d-1) cells
                // the occupants could move to (second hop). 0 free = the walk is locked in for at least two kicks.
                int freeCnt=-1;
                { bool blocked=true; for(int j=0;j<d;j++){ size_t pp=bc.h[j](keys[i])%m; if(!bc.occ[j][pp]){ blocked=false; break; } }
                  if(blocked){ freeCnt=0;
                    for(int j=0;j<d;j++){ size_t pp=bc.h[j](keys[i])%m; u64 y=bc.T[j][pp];
                        for(int jj=0;jj<d;jj++){ if(jj==j) continue; size_t q=bc.h[jj](y)%m; if(!bc.occ[jj][q]) freeCnt++; } } } }
                i64 r0=bc.insIters, s0=bc.stashRoutedCount;
                bc.insert(keys[i]);
                i64 rr=bc.insIters-r0; allIns++; if(freeCnt>=0){ blockedIns++; locN[freeCnt]++; locRoundsSum[freeCnt]+=rr; locRoundsMax[freeCnt]=max(locRoundsMax[freeCnt],rr); if(bc.stashRoutedCount>s0) locRouted[freeCnt]++; }
                binN[b]++; binRoundsSum[b]+=rr; binRoundsMax[b]=max(binRoundsMax[b],rr); if(bc.stashRoutedCount>s0) binRouted[b]++;
                // add this key's hyperedge: touch untouched slots, union everything, E += 1
                for(int j=0;j<d;j++){ int r=dsu.find(sl[j]); if(dsu.V[r]==0) dsu.V[r]=1; }
                int r0r=dsu.find(sl[0]);
                for(int j=1;j<d;j++){ int r=dsu.find(sl[j]); r0r=dsu.find(r0r);
                    if(r!=r0r){ dsu.p[r]=r0r; dsu.E[r0r]+=dsu.E[r]; dsu.V[r0r]+=dsu.V[r]; } }
                dsu.E[dsu.find(sl[0])]+=1;
            }
            // final component statistics (touched slots only)
            i64 comps=0, overComps=0, largest=0; double md=0;
            for(size_t v=0; v<(size_t)d*m; v++) if(dsu.p[v]==(int)v && dsu.V[v]>0){
                comps++; if(dsu.E[v]>dsu.V[v]) overComps++; largest=max(largest,dsu.V[v]); md=max(md,(double)dsu.E[v]/(double)dsu.V[v]); }
            HopcroftKarp hk((int)n,(int)(d*m),d,adj); i64 M=hk.run(); i64 defic=(i64)n-M;
            i64 used=0; for(size_t j=0;j<bc.stashCap;j++) if(bc.stashOcc[j]) used++; used+=(i64)bc.spill.size();
            defSum+=defic; usedSum+=used; compsSum+=comps; overCompsSum+=overComps; largestMax=max(largestMax,largest); maxDens=max(maxDens,md);
            usedMax=max(usedMax,used); defMax=max(defMax,defic); if(used>defic) stashedWhileFeasible++;
        }
        cerr << "[HYPER alpha=" << a << "] per-insertion bins (pooled over " << seeds << " seeds):\n";
        for(int b=0;b<6;b++) if(binN[b]>0)
            cerr << "   density " << setw(9) << binName[b] << ": inserts=" << binN[b] << " meanRounds=" << (double)binRoundsSum[b]/binN[b]
                 << " maxRounds=" << binRoundsMax[b] << " routedToStashFrac=" << (double)binRouted[b]/binN[b] << "\n";
        cerr << "   local 2-hop view, blocked keys only (all d candidate cells occupied): " << blockedIns << " of " << allIns << " inserts ("
             << (allIns? 100.0*blockedIns/allIns : 0.0) << "%); free cells among the " << d*(d-1) << " second-hop cells:\n";
        for(int f=0; f<=d*(d-1); f++) if(locN[f]>0)
            cerr << "   free=" << f << ": inserts=" << locN[f] << " meanRounds=" << (double)locRoundsSum[f]/locN[f]
                 << " maxRounds=" << locRoundsMax[f] << " routedToStashFrac=" << (double)locRouted[f]/locN[f] << "\n";
        cerr << "   final graph (mean over seeds): components=" << (double)compsSum/seeds << " componentsWithE>V=" << (double)overCompsSum/seeds
             << " largestComponentSlots(max)=" << largestMax << " maxComponentDensity=" << maxDens << "\n"
             << "   offline minimum stash (deficiency) mean=" << defSum/seeds << " max=" << defMax
             << "   stash+spill actually used mean=" << usedSum/seeds << " max=" << usedMax
             << "   seeds where the scheme used more than the offline minimum: " << stashedWhileFeasible << "/" << seeds << "\n";
    }
    cerr << "HYPER done.\n";
#endif
}

// ---------- HYPERFINE: per-seed stash routing by finer density bin, size bin and load (tests the local-density statement of the paper) ----------
// Same builds and same density statistic as `hyper` (keys 1000+sd, table seed 90000+sd, MaxKicks 16, s 4); no matching is computed. One CSV row per
// (alpha, seed, density bin, component-size bin) with insertion count, stash arrivals, sum of the density, sum of rounds and the sum of min(density,1)^MaxKicks
// (the value of the heuristic "a walk of MaxKicks steps fails with probability density^MaxKicks"; it is a heuristic to be compared with the data, not a result).
// Rows are per seed so that the analysis can resample whole builds (insertions of one build are not independent).
static void runHyperFine(int seeds, size_t N, const string& csvPath){
#ifdef NO_ITERS
    cerr << "hyperfine needs iteration counters: build without -DNO_ITERS\n"; (void)seeds; (void)N; (void)csvPath; return;
#else
    const int d=g_d; const int MK=16;
    const double db[8]={0.5,0.75,0.80,0.85,0.90,0.95,1.00,1.10};          // density bin = number of bounds <= density: 9 bins
    const i64 vb[3]={129,2049,16385};                                     // component-size bin = number of bounds <= V (slots touched): 4 bins
    ofstream out(csvPath);
    out << "alpha,N,seed,dbin,vbin,n,routed,sumDens,sumRounds,sumPredK\n" << fixed << setprecision(8);
    for(double a : alphasOr({0.84, 0.88, 0.90, 0.92})){
        for(int sd=0; sd<seeds; sd++){
            vector<u64> keys=makeKeys(N, 1000+sd); size_t n=keys.size(); size_t m=(size_t)(n/(a*d));
            BoundedCuckoo bc(d, m, MK, 4, 90000ULL+sd);
            SlotDSU dsu((size_t)d*m);
            i64 cN[9][4]={{0}}, cR[9][4]={{0}}, cRounds[9][4]={{0}}; double cD[9][4]={{0}}, cP[9][4]={{0}};
            for(size_t i=0;i<n;i++){
                int sl[16]; for(int j=0;j<d;j++) sl[j]=(int)(j*m + bc.h[j](keys[i])%m);
                int roots[16]; int nr=0; i64 E=0, V=0;
                for(int j=0;j<d;j++){ int r=dsu.find(sl[j]); if(dsu.V[r]==0) continue;
                    bool dup=false; for(int q=0;q<nr;q++) if(roots[q]==r) dup=true;
                    if(!dup){ roots[nr++]=r; E+=dsu.E[r]; V+=dsu.V[r]; } }
                double dens = V>0 ? (double)E/(double)V : 0.0;
                int b=0; while(b<8 && dens>=db[b]) b++;
                int vbin=0; while(vbin<3 && V>=vb[vbin]) vbin++;
                i64 r0=bc.insIters, s0=bc.stashRoutedCount;
                bc.insert(keys[i]);
                i64 rr=bc.insIters-r0;
                cN[b][vbin]++; cRounds[b][vbin]+=rr; cD[b][vbin]+=dens; cP[b][vbin]+=pow(min(dens,1.0),(double)MK);
                if(bc.stashRoutedCount>s0) cR[b][vbin]++;
                for(int j=0;j<d;j++){ int r=dsu.find(sl[j]); if(dsu.V[r]==0) dsu.V[r]=1; }
                int r0r=dsu.find(sl[0]);
                for(int j=1;j<d;j++){ int r=dsu.find(sl[j]); r0r=dsu.find(r0r);
                    if(r!=r0r){ dsu.p[r]=r0r; dsu.E[r0r]+=dsu.E[r]; dsu.V[r0r]+=dsu.V[r]; } }
                dsu.E[dsu.find(sl[0])]+=1;
            }
            for(int b=0;b<9;b++) for(int v=0;v<4;v++) if(cN[b][v]>0)
                out << a << "," << N << "," << sd << "," << b << "," << v << "," << cN[b][v] << "," << cR[b][v] << "," << cD[b][v] << "," << cRounds[b][v] << "," << cP[b][v] << "\n";
        }
        cout << "hyperfine alpha=" << a << " N=" << N << " seeds=" << seeds << " done\n";
    }
#endif
}

// ---------- SATCOMP: component size at insertion vs table size m (why does the routing rate change with m?) ----------
// Same builds as `sat` (keys 5000+r, seed 777+r, N = round(alpha*d*m)); a union-find over the d*m slots gives, for each insertion, the number of
// touched slots V of the component(s) its d slots belong to BEFORE its own hyperedge is added (0 when all its slots are untouched).
static void runSatComp(int seeds, const string& csvPath){
#ifdef NO_ITERS
    cerr << "satcomp needs iteration counters: build without -DNO_ITERS\n"; (void)seeds; (void)csvPath; return;
#else
    ofstream out(csvPath);
    const i64 bnd[6]={1,9,33,129,513,2049};      // bin b = number of bounds <= V: 0 | 1-8 | 9-32 | 33-128 | 129-512 | 513-2048 | >2048
    out << "alpha,maxKicks,stash,m,N,builds,routedFrac,routedFracSE,meanItersPerInsert,compMean,compP99,compMax,largestFinalSlots";
    for(int b=0;b<7;b++) out << ",bin" << b << "_n,bin" << b << "_routed";
    out << "\n" << fixed << setprecision(8);
    for(double a : alphasOr({0.80, 0.88})){
      for(i64 mk : {4LL, 16LL, 64LL}){
        for(size_t m : {4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144}){
            size_t N=(size_t)llround(a*g_d*m);
            int builds=(int)max<size_t>(3, min<size_t>((size_t)500*seeds, (size_t)3000000/N));
            double routed=0, iters=0, sumF=0, sumF2=0; i64 binN[7]={0}, binR[7]={0}, largest=0;
            vector<int> comp; comp.reserve((size_t)builds*N); double compSum=0;
            for(int r=0;r<builds;r++){
                vector<u64> keys=makeKeys(N, 5000+r);
                BoundedCuckoo t(g_d, m, mk, 4, 777+r);
                SlotDSU dsu((size_t)g_d*m);
                for(u64 k: keys){
                    int sl[16]; for(int j=0;j<g_d;j++) sl[j]=(int)(j*m + t.h[j](k)%m);
                    int roots[16]; int nr=0; i64 V=0;
                    for(int j=0;j<g_d;j++){ int rt=dsu.find(sl[j]); if(dsu.V[rt]==0) continue;
                        bool dup=false; for(int q=0;q<nr;q++) if(roots[q]==rt) dup=true;
                        if(!dup){ roots[nr++]=rt; V+=dsu.V[rt]; } }
                    int b=0; while(b<6 && V>=bnd[b]) b++;
                    i64 s0=t.stashRoutedCount;
                    t.insert(k);
                    binN[b]++; if(t.stashRoutedCount>s0) binR[b]++;
                    comp.push_back((int)V); compSum+=(double)V;
                    for(int j=0;j<g_d;j++){ int rt=dsu.find(sl[j]); if(dsu.V[rt]==0) dsu.V[rt]=1; }
                    int r0r=dsu.find(sl[0]);
                    for(int j=1;j<g_d;j++){ int rt=dsu.find(sl[j]); r0r=dsu.find(r0r);
                        if(rt!=r0r){ dsu.p[rt]=r0r; dsu.E[r0r]+=dsu.E[rt]; dsu.V[r0r]+=dsu.V[rt]; } }
                    dsu.E[dsu.find(sl[0])]+=1;
                }
                for(size_t v=0; v<(size_t)g_d*m; v++) if(dsu.p[v]==(int)v && dsu.V[v]>0) largest=max(largest,dsu.V[v]);
                double f=(double)t.stashRoutedCount/N; sumF+=f; sumF2+=f*f;
                routed+=t.stashRoutedCount; iters+=t.insIters;
            }
            double meanF=sumF/builds, varF = builds>1 ? max(0.0,(sumF2-builds*meanF*meanF)/(builds-1)) : 0.0, se=sqrt(varF/builds);
            size_t i99=(size_t)((double)comp.size()*0.99); if(i99>=comp.size()) i99=comp.size()-1;
            nth_element(comp.begin(), comp.begin()+i99, comp.end());
            int p99=comp[i99]; int cmax=*max_element(comp.begin(), comp.end());
            out << a << ',' << mk << ",4," << m << ',' << N << ',' << builds << ',' << routed/builds/N << ',' << se << ','
                << iters/builds/N << ',' << compSum/(double)comp.size() << ',' << p99 << ',' << cmax << ',' << largest;
            for(int b=0;b<7;b++) out << ',' << binN[b] << ',' << binR[b];
            out << '\n';
        }
        cout << "satcomp alpha=" << a << " MaxKicks=" << mk << " done\n";
      }
    }
#endif
}

// ---------- MERGE: key and occupancy merged into one array ----------
struct BoundedCuckooMerged {          // same algorithm and RNG use as BoundedCuckoo; empty cell = EMPTY sentinel
    static constexpr u64 EMPTY=~0ULL;
    int d; size_t m; vector<vector<u64>> T; vector<HashFn> h; size_t n=0;
    vector<u64> stash; size_t stashCap; vector<u64> spill; i64 maxKicks;
    i64 incrementalRehashes=0, stashOverflowEvents=0, stashRoutedCount=0, fullRehashesFromStuckStash=0, insIters=0, lkIters=0;
    mt19937_64 rng;
    BoundedCuckooMerged(int d_, size_t m_, i64 mk, size_t sc, u64 seed): d(d_), m(m_), T(d_, vector<u64>(m_,EMPTY)), stash(sc,EMPTY), stashCap(sc), maxKicks(mk), rng(seed){
        for(int i=0;i<d;i++) h.push_back(HashFn(seed*10+i+7));
    }
    i64 lookup(u64 key){
        for(int i=0;i<d;i++){ CNT(lkIters++;) size_t p=h[i](key)%m; if(T[i][p]==key) return i+1; }
        for(size_t j=0;j<stashCap;j++){ CNT(lkIters++;) if(stash[j]==key) return d+1; }
        for(u64 k: spill){ CNT(lkIters++;) if(k==key) return d+2; }
        return -1;
    }
    i64 insertInner(u64 key, int depth=0){
        if(lookup(key)>0) return 0;
        u64 cur=key; i64 kicks=0;
        for(i64 round=0; round<maxKicks; round++){
            CNT(insIters++;)
            for(int i=0;i<d;i++){ size_t p=h[i](cur)%m; if(T[i][p]==EMPTY){ T[i][p]=cur; n++; return kicks; } }
            int i=(int)(rng()%d); size_t p=h[i](cur)%m;
            u64 ev=T[i][p]; T[i][p]=cur; cur=ev; kicks++;
        }
        for(size_t j=0;j<stashCap;j++) if(stash[j]==EMPTY){ stash[j]=cur; n++; stashRoutedCount++; return -2; }
        stashOverflowEvents++;
        if(depth>=20){ fullRehashesFromStuckStash++; spill.push_back(cur); n++; return -4; }
        incrementalRehashes++;
        vector<u64> S; for(size_t j=0;j<stashCap;j++) if(stash[j]!=EMPTY){ S.push_back(stash[j]); stash[j]=EMPTY; }
        n-=S.size();
        for(u64 k: S) insertInner(k, depth+1);
        return insertInner(cur, depth+1);
    }
    i64 insert(u64 key){ return insertInner(key); }
};
template<typename T> static double timedLookups(T& t, const vector<u64>& q, i64& checksum){
    volatile i64 sink=0; auto t0=Clock::now();
    for(u64 k: q) sink=sink+t.lookup(k);
    auto t1=Clock::now(); checksum=(i64)sink;
    return (double)nsSince(t0,t1)/(double)q.size();
}
static void runMerge(size_t N, int reps){
    cerr << fixed << setprecision(3);
    cerr << "\n=== MERGE: N=" << N << " reps=" << reps << " d=" << g_d << " MaxKicks=16 s=4 (separate key+occupancy arrays vs one array with sentinel) ===\n"
         << "Both layouts carry the same instrumentation; build with -DNO_ITERS to remove it from both. Order alternates each rep. ns = per lookup, batch of N shuffled lookups.\n";
    vector<u64> keys=makeKeys(N,1000); keys.erase(remove(keys.begin(),keys.end(),BoundedCuckooMerged::EMPTY),keys.end());
    size_t n=keys.size();
    for(double a : alphasOr({0.45, 0.80, 0.88})){
        size_t m=(size_t)ceil(n/(a*g_d));
        BoundedCuckoo A(g_d,m,16,4,90000ULL); BoundedCuckooMerged B(g_d,m,16,4,90000ULL);
        for(u64 k: keys){ A.insert(k); B.insert(k); }
        bool same = A.n==B.n && A.stashRoutedCount==B.stashRoutedCount && A.stashOverflowEvents==B.stashOverflowEvents && A.incrementalRehashes==B.incrementalRehashes;
        vector<u64> pos(keys); shuffle(pos.begin(),pos.end(),mt19937_64(9));
        vector<u64> neg; { mt19937_64 r(77); neg.reserve(n); while(neg.size()<n){ u64 x=r(); if(A.lookup(x)<0 && x!=BoundedCuckooMerged::EMPTY) neg.push_back(x); } }
        i64 missA=0, missB=0; for(u64 k: keys){ if(A.lookup(k)<0) missA++; if(B.lookup(k)<0) missB++; }
        for(u64 k: neg) if((A.lookup(k)<0)!=(B.lookup(k)<0)) same=false;
        vector<double> pa,pb,na,nb; i64 cs=0;
        for(int r=0;r<reps;r++){
            if(r&1){ pb.push_back(timedLookups(B,pos,cs)); pa.push_back(timedLookups(A,pos,cs)); nb.push_back(timedLookups(B,neg,cs)); na.push_back(timedLookups(A,neg,cs)); }
            else   { pa.push_back(timedLookups(A,pos,cs)); pb.push_back(timedLookups(B,pos,cs)); na.push_back(timedLookups(A,neg,cs)); nb.push_back(timedLookups(B,neg,cs)); }
        }
        cerr << "[MERGE alpha=" << a << "] identicalBehaviour=" << (same?"yes":"NO") << " missing(sep/merged)=" << missA << "/" << missB
             << " stashRouted=" << A.stashRoutedCount << " | positive ns: separate min=" << pctOf(pa,0) << " med=" << pctOf(pa,0.5)
             << "  merged min=" << pctOf(pb,0) << " med=" << pctOf(pb,0.5)
             << " | negative ns: separate min=" << pctOf(na,0) << " med=" << pctOf(na,0.5) << "  merged min=" << pctOf(nb,0) << " med=" << pctOf(nb,0.5)
             << " | bytes/cell separate=9 merged=8\n";
    }
    cerr << "MERGE done.\n";
}

int main(int argc, char** argv){
    vector<string> pos; string outPath, csvPath="sweep.csv", keyPath; double capSec=0;
    for(int i=1;i<argc;i++){
        string a=argv[i];
        if(a=="-o" && i+1<argc) outPath=argv[++i];
        else if(a=="-c" && i+1<argc) csvPath=argv[++i];
        else if(a=="-k" && i+1<argc) keyPath=argv[++i];
        else if(a=="-T" && i+1<argc) capSec=atof(argv[++i]);
        else if(a=="-d" && i+1<argc){ g_d=atoi(argv[++i]); g_dSet=true;
            if(g_d<2 || g_d>16){ cout << "-d must be between 2 and 16\n"; return 1; } }
        else if(a=="-a" && i+1<argc){ string L=argv[++i]; g_alphas.clear(); size_t st=0;
            while(st<=L.size()){ size_t cm=L.find(',',st); if(cm==string::npos) cm=L.size();
                string tok=L.substr(st,cm-st); char* e=nullptr; double v=strtod(tok.c_str(),&e);
                if(tok.empty() || *e!='\0' || !(v>0 && v<1)){ cout << "-a needs loads strictly between 0 and 1, comma separated (got '" << tok << "')\n"; return 1; }
                g_alphas.push_back(v); st=cm+1; } }
        else pos.push_back(a);
    }
    if(!outPath.empty()){
        if(!freopen(outPath.c_str(),"w",stderr)){ cout << "cannot open " << outPath << "\n"; return 1; }
        cout << "report -> " << outPath << "\n";
    }
    string mode = pos.empty() ? "main" : pos[0];
    cerr << fixed << setprecision(6);
    if(g_dSet || !g_alphas.empty()){
        cerr << "[options] d=" << g_d; if(!g_alphas.empty()){ cerr << " loads="; for(size_t q=0;q<g_alphas.size();q++) cerr << (q?",":"") << g_alphas[q]; } cerr << "\n";
        if(mode=="retrybug" || mode=="rehashclassical") cerr << "[options] -d/-a are ignored by `" << mode << "` (fixed configurations)\n";
        double thr = g_d==3?0.9179 : g_d==4?0.9768 : g_d==5?0.9924 : (g_d==2?0.5:0.0);
        if(thr>0) for(double v : g_alphas) if(v>=thr) cerr << "[options] note: alpha " << v << " is at or above the offline threshold " << thr << " for d=" << g_d << ": no placement can store all keys; the stash only absorbs a constant number\n";
    }
    if(!keyPath.empty()){
        if(mode=="sat" || mode=="satcomp"){ cerr << "-k is not supported with `sat`/`satcomp` (it builds its own exact-load sizes)\n"; return 1; }
        if(!loadKeyFile(keyPath)){ cerr << "cannot read keys from " << keyPath << "\n"; return 1; }
    }
    auto clampN=[&](size_t n)->size_t{
        if(g_useFile && n>g_fileKeys.size()){ cerr << "N=" << n << " exceeds the key file; using N=" << g_fileKeys.size() << "\n"; return g_fileKeys.size(); }
        return n; };
    if(capSec>0){ g_capOn=true; g_deadline=Clock::now()+chrono::milliseconds((long long)(capSec*1000.0)); }
    if(mode=="rehashclassical"){   // bench rehashclassical [seeds=3] [N=2000000] -c rehash_classical.csv
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 3;
        size_t nn = clampN(pos.size()>2 ? (size_t)strtoull(pos[2].c_str(),nullptr,10) : 2000000);
        if(csvPath=="sweep.csv") csvPath="rehash_classical.csv";
        runRehashClassical(seeds, nn, csvPath); cout << "done\n"; return 0;
    }
    if(mode=="rehashcost"){        // bench rehashcost [seeds=3] [N=200000] [maxEvents=50] -c rehashcost.csv
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 3;
        size_t nn = clampN(pos.size()>2 ? (size_t)strtoull(pos[2].c_str(),nullptr,10) : 200000);
        size_t me = pos.size()>3 ? (size_t)strtoull(pos[3].c_str(),nullptr,10) : 50;
        if(csvPath=="sweep.csv") csvPath=dCsv("rehashcost.csv");
        runRehashCost(seeds, nn, me, csvPath); cout << "done\n"; return 0;
    }
    if(mode=="window"){            // bench window [seeds=5] [N=2000000]
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 5;
        size_t nn = clampN(pos.size()>2 ? (size_t)strtoull(pos[2].c_str(),nullptr,10) : 2000000);
        runWindow(seeds, nn); cout << "done\n"; return 0;
    }
    if(mode=="hyper"){             // bench hyper [seeds=3] [N=200000]
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 3;
        size_t nn = clampN(pos.size()>2 ? (size_t)strtoull(pos[2].c_str(),nullptr,10) : 200000);
        runHyper(seeds, nn); cout << "done\n"; return 0;
    }
    if(mode=="hyperfine"){         // bench hyperfine [seeds=20] [N=200000] -c hyperfine.csv
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 20;
        size_t nn = clampN(pos.size()>2 ? (size_t)strtoull(pos[2].c_str(),nullptr,10) : 200000);
        if(csvPath=="sweep.csv") csvPath=dCsv("hyperfine.csv");
        runHyperFine(seeds, nn, csvPath); cout << "done\n"; return 0;
    }
    if(mode=="merge"){             // bench merge [N=2000000] [reps=7]
        size_t nn = clampN(pos.size()>1 ? (size_t)strtoull(pos[1].c_str(),nullptr,10) : 2000000);
        int reps = pos.size()>2 ? atoi(pos[2].c_str()) : 7;
        runMerge(nn, reps); cout << "done\n"; return 0;
    }
    if(mode=="ext"){
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 5;
        size_t nn = clampN(pos.size()>2 ? (size_t)strtoull(pos[2].c_str(),nullptr,10) : 2000000);
        runExt(nn, seeds); cout << "done\n"; return 0;
    }
    if(mode=="tail"){   // bench tail [N=100000] [builds=1000] -c tail.csv   (appends one block of rows)
        size_t nn = clampN(pos.size()>1 ? (size_t)strtoull(pos[1].c_str(),nullptr,10) : 100000);
        int builds = pos.size()>2 ? atoi(pos[2].c_str()) : 1000;
        if(csvPath=="sweep.csv") csvPath=dCsv("tail.csv");
        runTail(nn, builds, csvPath); cout << "done\n"; return 0;
    }
    if(mode=="sens"){   // bench sens [seeds=5] [N=2000000] -c sens.csv
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 5;
        size_t nn = clampN(pos.size()>2 ? (size_t)strtoull(pos[2].c_str(),nullptr,10) : 2000000);
        if(csvPath=="sweep.csv") csvPath=dCsv("sens.csv");
        runSens(seeds, nn, csvPath); cout << "done\n"; return 0;
    }
    if(mode=="sat"){    // bench sat [seeds=3] -c sat.csv
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 3;
        if(csvPath=="sweep.csv") csvPath=dCsv("sat.csv");
        runSat(seeds, csvPath); cout << "done\n"; return 0;
    }
    if(mode=="satcomp"){   // bench satcomp [seeds=3] -c satcomp.csv
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 3;
        if(csvPath=="sweep.csv") csvPath=dCsv("satcomp.csv");
        runSatComp(seeds, csvPath); cout << "done\n"; return 0;
    }
    if(mode=="retrybug"){   // bench retrybug [seeds=5] [N=200000]
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 5;
        size_t nn = clampN(pos.size()>2 ? (size_t)strtoull(pos[2].c_str(),nullptr,10) : 200000);
        runRetryBug(seeds, nn); cout << "done\n"; return 0;
    }
    if(mode=="lookup"){   // bench lookup <scheme> <N> <reps>
        if(pos.size()<4){ cerr << "usage: bench lookup <scheme> <N> <reps>\n"; return 1; }
        return runLookup(pos[1], clampN((size_t)strtoull(pos[2].c_str(),nullptr,10)), (i64)strtoll(pos[3].c_str(),nullptr,10));
    }
    if(mode=="sweep"){
        int seeds = pos.size()>1 ? atoi(pos[1].c_str()) : 5;
        size_t maxN = clampN(pos.size()>2 ? (size_t)strtoull(pos[2].c_str(),nullptr,10) : 1000000);
        if(csvPath=="sweep.csv") csvPath=dCsv("sweep.csv");
        runSweep(seeds, maxN, csvPath); cout << "done\n"; return 0;
    }

    size_t N = 2000000;
    if(mode=="main" && pos.size()>1) N=(size_t)strtoull(pos[1].c_str(),nullptr,10);
    N=clampN(N);
    size_t lookupOps=N; double targetLoad=g_alphas.empty()?0.90:g_alphas[0]; u64 seed=123456789ULL;
    vector<u64> keys=makeKeys(N, 42);
    cerr << "\n=== TABLE I: comparative microbenchmark, N=" << N << " keys ===\n";
    auto capNote=[&](const string& what){ cerr << what << " SKIPPED/ABORTED: -T time cap reached (no numbers reported for it)\n"; };

    if(!g_capTripped){ // Linear probing, load 0.70
        size_t cap=(size_t)(N/0.70);
        LinearProbing lp(cap, seed);
        vector<i64> insLat; insLat.reserve(N);
        auto t0=Clock::now();
        for(u64 k: keys){ if(capHit()) break; auto s=Clock::now(); lp.insert(k); auto e=Clock::now(); insLat.push_back(nsSince(s,e)); }
        if(g_capTripped) capNote("[LinearProbing]"); else {
        double totalInsSec=chrono::duration<double>(Clock::now()-t0).count();
        double avgLookProbes=0; for(u64 k: keys) avgLookProbes+=lp.lookup(k); avgLookProbes/=N;
        i64 maxInsProbe=0; { LinearProbing lp2(cap,seed); for(u64 k: keys) maxInsProbe=max(maxInsProbe, lp2.insert(k)); }
        cerr << "[LinearProbing] load=" << (double)N/cap << " stored=" << lp.n << "/" << N
             << " avgLookupProbes=" << avgLookProbes << " maxInsertProbes=" << maxInsProbe
             << " totalInsertTimeSec=" << totalInsSec << "\n";
        percentileReport(insLat, [](i64 x){return x;}, "[LinearProbing] insertLatencyNs");
        lookupLatency(lp, keys, lookupOps, "[LinearProbing] lookupLatencyNs"); }
    } else capNote("[LinearProbing]");
    if(!g_capTripped){ // Chained, alpha ~ 1.0
        size_t cap=N;
        ChainedHashing ch(cap, seed);
        vector<i64> insLat; insLat.reserve(N);
        for(u64 k: keys){ if(capHit()) break; auto s=Clock::now(); ch.insert(k); auto e=Clock::now(); insLat.push_back(nsSince(s,e)); }
        if(g_capTripped) capNote("[Chained]"); else {
        double avgLookProbes=0; for(u64 k: keys) avgLookProbes+=ch.lookup(k); avgLookProbes/=N;
        i64 maxChain=0; for(auto &b: ch.table) maxChain=max(maxChain,(i64)b.size());
        cerr << "[Chained] load=" << (double)N/cap << " stored=" << ch.n << "/" << N
             << " avgLookupProbes=" << avgLookProbes << " maxChainLen(=maxInsertProbes)=" << maxChain << "\n";
        percentileReport(insLat, [](i64 x){return x;}, "[Chained] insertLatencyNs");
        lookupLatency(ch, keys, lookupOps, "[Chained] lookupLatencyNs"); }
    } else capNote("[Chained]");
    // Classical cuckoo: short loop (as in the first harness) and Pagh-Rodler's prescribed loop
    for(double a : {0.33, 0.49, 0.495}){
        if(g_capTripped){ capNote("[ClassicalCuckoo a="+to_string(a)+"]"); continue; }
        size_t m=(size_t)(N/(a*2.0));
        i64 shortL = a<0.4 ? 43 : 66;   // the values used in the first harness (N=2e6); reproduces earlier rows
        if(N!=2000000) shortL=shortLoop(m);
        ostringstream l1, l2; l1 << "[ClassicalCuckoo short a=" << a << "]"; l2 << "[ClassicalCuckoo prescribed a=" << a << "]";
        classicalBlock(l1.str(), keys, a, shortL, seed + (a<0.4?555:(a<0.492?999:0)), lookupOps);
        if(g_capTripped){ capNote(l2.str()); continue; }
        classicalBlock(l2.str(), keys, a, prescribedLoop(m,N), seed + 777, lookupOps);
    }
    if(!g_capTripped){ // Proposed: d=3, MaxKicks=16, s=4, target load 0.90
        int d=g_d; i64 maxKicks=16; size_t stashCap=4;
        size_t m=(size_t)(N/(targetLoad*d));
        BoundedCuckoo bc(d, m, maxKicks, stashCap, seed);
        vector<i64> insLat; insLat.reserve(N);
        for(u64 k: keys){ if(capHit()) break; auto s=Clock::now(); bc.insert(k); auto e=Clock::now(); insLat.push_back(nsSince(s,e)); }
        if(g_capTripped) capNote("[Proposed]"); else {
        double avgLookProbes=0; i64 miss=0;
        for(u64 k: keys){ i64 r=bc.lookup(k); if(r<0){ miss++; r=d; } avgLookProbes+=min(r,(i64)d); } avgLookProbes/=N;
        cerr << "[Proposed d=" << g_d << ",MaxKicks=16,s=4] load=" << (double)bc.n/(d*m) << " stored=" << bc.n << "/" << N
             << " missing=" << miss << " spill=" << bc.spill.size()
             << " avgLookupProbes(table only)=" << avgLookProbes
             << " stashRoutedCount=" << bc.stashRoutedCount << " incrementalRehashes=" << bc.incrementalRehashes
             << " stashOverflowEvents=" << bc.stashOverflowEvents << " depthGuardTrips=" << bc.fullRehashesFromStuckStash << "\n";
        percentileReport(insLat, [](i64 x){return x;}, "[Proposed] insertLatencyNs");
        lookupLatency(bc, keys, lookupOps, "[Proposed] lookupLatencyNs"); }
    } else capNote("[Proposed]");

    cerr << "\n=== TABLE II: MaxKicks sensitivity, N=" << N << ", d=" << g_d << ", target alpha=" << (g_alphas.empty()? string("0.88") : to_string(g_alphas[0])) << ", s=4 ===\n";
    for(i64 mk : {4LL,8LL,12LL,16LL,24LL,32LL,48LL,64LL}){
        if(g_capTripped){ capNote("[TABLE II MaxKicks="+to_string(mk)+"]"); continue; }
        int d=g_d; size_t stashCap=4; double alpha=g_alphas.empty()?0.88:g_alphas[0];
        size_t m=(size_t)(N/(alpha*d));
        BoundedCuckoo bc(d, m, mk, stashCap, seed+mk);
        i64 maxKicksObs=0;
        for(u64 k: keys){ if(capHit()) break; i64 kk=bc.insert(k); if(kk>=0) maxKicksObs=max(maxKicksObs,kk); }
        if(g_capTripped){ capNote("[TABLE II MaxKicks="+to_string(mk)+"]"); continue; }
        i64 miss=0; for(u64 k: keys) if(bc.lookup(k)<0) miss++;
        double avgStash=bc.stashSamples? bc.sumStashOcc/bc.stashSamples : 0.0;
        cerr << "MaxKicks=" << mk << " routingProb=" << (double)bc.stashRoutedCount/N
             << " avgStashOccAtRouting=" << avgStash << " stashOverflowEvents=" << bc.stashOverflowEvents
             << " depthGuardTrips=" << bc.fullRehashesFromStuckStash << " missing=" << miss
             << " maxObservedKicksBeforeStash=" << maxKicksObs << " load=" << (double)bc.n/(d*m) << "\n";
    }
    if(g_capOn) cerr << "\n[time cap] -T " << capSec << " s: " << (g_capTripped? "HIT; blocks marked SKIPPED/ABORTED above have no numbers, all other blocks are complete" : "not reached; every block completed") << "\n";
    cerr << "\nDone.\n";
    cout << "done\n";
    return 0;
}
