#!/usr/bin/env bash
# run_thp.sh -- huge-page test around `bench_clean lookup` (Linux; needs perf and sudo). Rewritten for the Ubuntu run (v14).
#
# For every THP mode it runs the same lookup loop as the `perf` stage of run_all.sh (build-only run and lookup run, `perf stat`, median of REPEAT repeats)
# and in addition records the PEAK of AnonHugePages while the program runs:
#   peak_AnonHugePages_kB        peak of the benchmark process itself (and its children), from /proc/<pid>/smaps_rollup, polled every 50 ms
#   peak_system_AnonHugePages_kB peak of the system-wide AnonHugePages line of /proc/meminfo during the same run
# A row where the first column is 0 for the modes that should use huge pages means that the program did not get huge pages in that mode (the earlier
# Fedora run reported 0 kB in every mode, `always` included, so the first thing to read in the new file is these two columns).
# Modes:  never | madvise | madvise+malloc (madvise and GLIBC_TUNABLES=glibc.malloc.hugetlb=1, glibc >= 2.35) | always
# The THP setting is restored on exit. Needs `sudo -v` beforehand (the script calls sudo -n only).
#
# Environment (all optional): OUT=thp  PIN=<cpu>|none  SCHEMES="linear chained classical p45 p80 p88"  NS="100000 1000000 4000000"  OPS=30000000  REPEAT=3
#                             MODES="never madvise madvise+malloc always"
# Output: $OUT/thp_results.csv, $OUT/thp_state.txt, and per mode $OUT/<mode>/ (perf CSVs, perf_summary.csv, *.peak)
set -uo pipefail
cd "$(dirname "$0")"
OUT="${OUT:-thp}"; PIN="${PIN:-}"; [ "$PIN" = none ] && PIN=""
SCHEMES="${SCHEMES:-linear chained classical p45 p80 p88}"; NS="${NS:-100000 1000000 4000000}"; OPS="${OPS:-30000000}"; REPEAT="${REPEAT:-3}"
MODES="${MODES:-never madvise madvise+malloc always}"
THP="${THP_FILE:-/sys/kernel/mm/transparent_hugepage/enabled}"   # THP_FILE only for testing the script
EVENTS="cycles,instructions,cache-references,cache-misses,L1-dcache-loads,L1-dcache-load-misses,LLC-loads,LLC-load-misses,dTLB-loads,dTLB-load-misses"
[ -x ./bench_clean ] || { echo "bench_clean not found (build it: g++ -O2 -std=c++17 -DNO_ITERS -o bench_clean bench.cpp)"; exit 1; }
command -v perf >/dev/null 2>&1 || { echo "perf not installed (Ubuntu: sudo apt install linux-tools-common linux-tools-generic linux-tools-\$(uname -r))"; exit 1; }
[ -w "$THP" ] || sudo -n true 2>/dev/null || { echo "need sudo (run: sudo -v) to change $THP"; exit 1; }
mkdir -p "$OUT"
ORIG=$(sed 's/.*\[\(.*\)\].*/\1/' "$THP")
set_thp() { echo "$1" | sudo -n tee "$THP" >/dev/null; }
restore() { set_thp "$ORIG" && echo "restored THP enabled=$ORIG"; }
trap restore EXIT
{
  echo "date: $(date -Is)"; echo "kernel: $(uname -sr)"
  echo "THP enabled (start): $(cat "$THP")"; echo "THP defrag: $(cat /sys/kernel/mm/transparent_hugepage/defrag 2>/dev/null)"
  grep -E "AnonHugePages|HugePages_Total|Hugepagesize" /proc/meminfo
  echo "glibc: $(ldd --version 2>&1 | head -n 1)"; echo "pin: ${PIN:-none}"
} > "$OUT/thp_state.txt"; cat "$OUT/thp_state.txt"

PINCMD=(); if [ -n "$PIN" ] && command -v taskset >/dev/null 2>&1; then PINCMD=(taskset -c "$PIN"); fi
kids() { local c; for c in $(pgrep -P "$1" 2>/dev/null); do echo "$c"; kids "$c"; done; }
# measure PREFIX STDOUT_FILE ENVWORDS... -- command...   runs the command in the background, polls AnonHugePages, writes PREFIX.peak = "<process kB> <system kB>"
measure() {
  local prefix=$1 outf=$2; shift 2
  local envw=(); while [ "$1" != "--" ]; do envw+=("$1"); shift; done; shift
  env "${envw[@]}" "$@" > "$outf" 2> "$prefix.err" &
  local top=$! pp=0 ps=0 v p
  while kill -0 "$top" 2>/dev/null; do
    for p in $top $(kids "$top"); do
      v=$(awk '/^AnonHugePages:/{print $2}' "/proc/$p/smaps_rollup" 2>/dev/null); [ -n "$v" ] && [ "$v" -gt "$pp" ] && pp=$v
    done
    v=$(awk '/^AnonHugePages:/{print $2}' /proc/meminfo); [ -n "$v" ] && [ "$v" -gt "$ps" ] && ps=$v
    sleep 0.05
  done
  wait "$top"; local rc=$?
  echo "$pp $ps" > "$prefix.peak"; return "$rc"
}

for mode in $MODES; do
  echo "=== mode $mode"
  D="$OUT/$mode"; mkdir -p "$D"; rm -f "$D"/*.csv "$D"/*.txt "$D"/*.peak "$D"/*.err
  case "$mode" in
    never)          set_thp never;   ENVW=(X=1);;
    madvise)        set_thp madvise; ENVW=(X=1);;
    madvise+malloc) set_thp madvise; ENVW=(GLIBC_TUNABLES=glibc.malloc.hugetlb=1);;
    always)         set_thp always;  ENVW=(X=1);;
    *) echo "unknown mode $mode"; continue;;
  esac
  echo "THP now: $(cat "$THP")  tunable: ${ENVW[*]}"
  for sc in $SCHEMES; do for N in $NS; do
    R=$(( OPS / N )); [ "$R" -lt 2 ] && R=2
    for rep in $(seq 1 "$REPEAT"); do
      tag="${sc}_${N}_r${rep}"
      measure "$D/${tag}_base" /dev/null "${ENVW[@]}" -- "${PINCMD[@]}" perf stat -x, -e "$EVENTS" -o "$D/${tag}_base.csv" -- ./bench_clean lookup "$sc" "$N" 0
      measure "$D/${tag}_run"  "$D/${tag}_run.txt" "${ENVW[@]}" -- "${PINCMD[@]}" perf stat -x, -e "$EVENTS" -o "$D/${tag}_run.csv" -- ./bench_clean lookup "$sc" "$N" "$R"
    done
    echo "  $mode $sc N=$N done (peak AnonHugePages of the last run: $(cut -d' ' -f1 "$D/${sc}_${N}_r${REPEAT}_run.peak" 2>/dev/null) kB, system $(cut -d' ' -f2 "$D/${sc}_${N}_r${REPEAT}_run.peak" 2>/dev/null) kB)"
  done; done
  python3 perf_summarize.py "$D" "$D/perf_summary.csv" || echo "perf_summarize failed for $mode"
done

python3 - "$OUT" $MODES <<'EOF'
import csv, glob, os, re, sys
out = sys.argv[1]; modes = sys.argv[2:]
rows = []
for mode in modes:
    f = os.path.join(out, mode, "perf_summary.csv")
    if not os.path.exists(f): continue
    pk = {}
    for p in glob.glob(os.path.join(out, mode, "*_run.peak")):
        m = re.match(r"(.+)_(\d+)_r\d+_run\.peak$", os.path.basename(p))
        if not m: continue
        a, b = (int(x) for x in open(p).read().split())
        k = (m.group(1), m.group(2)); o = pk.get(k, (0, 0)); pk[k] = (max(o[0], a), max(o[1], b))
    for r in csv.DictReader(open(f)):
        k = (r["scheme"], r["N"]); a, b = pk.get(k, ("", ""))
        rows.append(dict(mode=mode, scheme=r["scheme"], N=r["N"], repeats=r["repeats"], peak_AnonHugePages_kB=a, peak_system_AnonHugePages_kB=b,
                         **{c: v for c, v in r.items() if c not in ("scheme", "N", "repeats")}))
if rows:
    with open(os.path.join(out, "thp_results.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print("wrote", os.path.join(out, "thp_results.csv"), len(rows), "rows")
else:
    print("no rows"); sys.exit(1)
EOF
