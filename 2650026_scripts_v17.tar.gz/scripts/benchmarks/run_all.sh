#!/usr/bin/env bash
# run_all.sh - every benchmark run of the ADSA paper in one go (Linux / bash).
#
# Usage:   bash run_all.sh                 everything, in order, one go
#          bash run_all.sh sens sat        only the named stages
#          QUICK=1 bash run_all.sh         smoke test of the whole pipeline in a few minutes (numbers NOT for the paper)
#          SETUP=1 bash run_all.sh         also let the script tune the machine for perf (sudo; restored at exit)
#
# Stages, in the order they run:
#   info   machine description                                              -> cpu.txt
#   build  bench (counting build) and bench_clean (-DNO_ITERS: latency, perf)   (done automatically when missing)
#   main   `bench main`  main tables                                        -> report_main.txt
#   ext    `bench ext`   multi-seed runs at the shared loads (Table of shared-load comparison)        -> report_ext.txt
#   sweep  size sweep N = 10..1,000,000, counting + clean pass + check      -> sweep.csv, sweep_latency.csv, check.txt
#   tail   rare-event sampling at N = 1e3, 1e4, 1e5                         -> tail.csv
#   sens   MaxKicks / stash sensitivity (sensitivity table)                         -> sens.csv, check_sens.txt
#   sat    stash routing vs table size at exact integer load (saturation table)     -> sat.csv
#   satcomp (v5.7) the `sat` builds with a union-find over the slots: routing rate +- standard error per m, component size at insertion, routing rate by
#          component size   -> satcomp.csv   (gives the noise of the rate against m and its saturation; it may not explain the rise with m, see the paper's VI-D)
#   hyperfine (v5.8) finer density bins x loads 0.84 / 0.88 / 0.90 / 0.92, per build (N = 200000 with 20 builds, N = 10^6 with 10), then hyperfine_report.py
#          -> hyperfine.csv, hyperfine_N1000000.csv, hyperfine_report.txt, hyperfine_summary.csv, hyperfine_table.tex  (tests the paper's local-density statement)
#   perf   `perf stat` counters of the lookup loop (needs perf)             -> perf/perf_summary.csv
#   retrybug         the retired wrong-key retry, reproduced (correct vs retired) -> report_retrybug.txt
#   rehashclassical  classical 2-way cuckoo: every full rehash timed, nesting depth -> report_rehash_classical.txt, rehash_classical.csv
#   rehashcost       real RehashStash vs a full rebuild of an identical copy        -> report_rehashcost.txt, rehashcost.csv
#   window           stash-overflow bound: observed windows vs Chernoff/binomial     -> report_window.txt
#   hyper            hypergraph counters, local 2-hop view, offline minimum stash    -> report_hyper.txt
#   merge            key + occupancy merged into one array vs separate arrays        -> report_merge.txt   (clean build, pinned)
#   real             real trace: `bench main` and the size sweep on keys from KEYS=keys.bin (-k); skipped when KEYS is unset
#                                                                                   -> report_real_main.txt, sweep_real.csv, sweep_real_latency.csv
#   dscan  OPTIONAL, not in the default run: the proposed scheme at d = DSCAN_D (default "4 5") with loads suited to each d
#          (bench -d D -a LOADS): sens, sat, window, hyper, rehashcost, tail, a size sweep (counting + latency) and `main`
#          -> sens_d4.csv, check_sens_d4.txt, sat_d4.csv, report_window_d4.txt, report_hyper_d4.txt, rehashcost_d4.csv, tail_d4.csv,
#             sweep_d4.csv, sweep_d4_latency.csv, report_main_d4.txt (and the same for d5)      (DSCAN=1 or `bash run_all.sh dscan`)
#   thp    OPTIONAL, not in the default run: huge-page test around `bench_clean lookup` (run_thp.sh; needs perf and sudo; the THP setting is restored)
#          -> thp/thp_results.csv   (THP=1 or `bash run_all.sh thp`)
#   big    OPTIONAL, not in the default run: `bench main` at N = BIG_N, time cap BIG_CAP s -> report_big.txt   (BIG=1 or `bash run_all.sh big`)
#   plots  plots of sweep.csv (python3 with pandas, matplotlib)             -> plots/
# At the end everything is also packed into $OUT.tar.gz: send that one file.
#
# Environment variables (all optional):
#   OUT=results_linux   output folder         SEEDS=5       seeds for sweep, ext, sens      SAT_SEEDS=3   seeds for sat
#   MAIN_N=2000000  EXT_N=2000000  SENS_N=2000000  MAXN=1000000  BIG_N=10000000
#   PIN=<cpu>           CPU to pin the timed runs to (taskset). Default: first P-core on a hybrid CPU, else not pinned.  PIN=none disables.
#   REPEAT=3            repeats of every perf measurement
#   PERF_SCHEMES="linear chained classical p45 p80 p88"   PERF_NS="10000 30000 ... 2000000"   PERF_OPS=30000000 (lookups per run)
#   SETUP=1             perf_event_paranoid=1 and the performance CPU governor via sudo; the old values are restored when the script ends
#   THP=1               add the huge-page stage (do `sudo -v` first)
#   QUICK=1             tiny sizes everywhere (smoke test)
#   KEYS=keys.bin       little-endian u64 keys (python3 pcap2flows.py trace.pcap.gz --out flows.txt --keys keys.bin) for the `real` stage
#   BIG_CAP=14400       wall-clock cap in seconds for the big stage (blocks after it are skipped, never half-reported); 0 = no cap
#   RB_SEEDS=5 RB_N=200000   RHC_SEEDS=3 RHC_N=2000000   RC_SEEDS=3 RC_N=200000 RC_EVENTS=50   WIN_SEEDS=5 WIN_N=2000000
#   HYP_SEEDS=3 HYP_N=200000   MERGE_N=2000000 MERGE_REPS=7   REAL_N=2000000
#   DSCAN=1             add the d-scan stage;  DSCAN_D="4 5"  d values;  D4_ALPHAS=0.80,0.88,0.94,0.96  D5_ALPHAS=0.80,0.88,0.95,0.98  (loads per d;
#                       any other d reads D<d>_ALPHAS, default 0.80,0.88,0.94);  D4_MAIN_A=0.94  D5_MAIN_A=0.96  target load of `bench main` for that d.
#                       Offline thresholds (one key per cell): d=3 0.9179, d=4 0.9768, d=5 0.9924 -- keep every load below them.
# A failing stage does not stop the run. A summary with a status per stage is printed at the end; exit code 1 if any stage failed.
# Counts (iterations, stash statistics, tail, sens, sat) are machine-independent. Latency and perf are not.
set -uo pipefail
cd "$(dirname "$0")"
OUT="${OUT:-results_linux}"; SEEDS="${SEEDS:-5}"; SAT_SEEDS="${SAT_SEEDS:-3}"; REPEAT="${REPEAT:-3}"
MAIN_N="${MAIN_N:-2000000}"; EXT_N="${EXT_N:-2000000}"; SENS_N="${SENS_N:-2000000}"; MAXN="${MAXN:-1000000}"; BIG_N="${BIG_N:-10000000}"
PERF_SCHEMES="${PERF_SCHEMES:-linear chained classical p45 p80 p88}"
PERF_NS="${PERF_NS:-10000 30000 100000 200000 300000 400000 600000 800000 1000000 2000000}"
PERF_OPS="${PERF_OPS:-30000000}"
RB_SEEDS="${RB_SEEDS:-5}"; RB_N="${RB_N:-200000}"; RHC_SEEDS="${RHC_SEEDS:-3}"; RHC_N="${RHC_N:-2000000}"
RC_SEEDS="${RC_SEEDS:-3}"; RC_N="${RC_N:-200000}"; RC_EVENTS="${RC_EVENTS:-50}"; WIN_SEEDS="${WIN_SEEDS:-5}"; WIN_N="${WIN_N:-2000000}"
HYP_SEEDS="${HYP_SEEDS:-3}"; HYP_N="${HYP_N:-200000}"; MERGE_N="${MERGE_N:-2000000}"; MERGE_REPS="${MERGE_REPS:-7}"
HF_SEEDS="${HF_SEEDS:-20}"; HF_N="${HF_N:-200000}"; HF_SEEDS2="${HF_SEEDS2:-10}"; HF_N2="${HF_N2:-1000000}"
DSCAN_D="${DSCAN_D:-4 5}"; D4_ALPHAS="${D4_ALPHAS:-0.80,0.88,0.94,0.96}"; D5_ALPHAS="${D5_ALPHAS:-0.80,0.88,0.95,0.98}"; D4_MAIN_A="${D4_MAIN_A:-0.94}"; D5_MAIN_A="${D5_MAIN_A:-0.96}"
REAL_N="${REAL_N:-2000000}"; KEYS="${KEYS:-}"; BIG_CAP="${BIG_CAP:-14400}"
TAIL_A=20000; TAIL_B=2000; TAIL_C=2000
if [ "${QUICK:-0}" = 1 ]; then
  SEEDS=1; SAT_SEEDS=1; REPEAT=1; MAIN_N=20000; EXT_N=20000; SENS_N=20000; MAXN=2000; BIG_N=50000
  PERF_SCHEMES="linear p88"; PERF_NS="10000 30000"; PERF_OPS=300000; TAIL_A=200; TAIL_B=20; TAIL_C=20
  RB_SEEDS=1; RB_N=20000; RHC_SEEDS=1; RHC_N=20000; RC_SEEDS=1; RC_N=20000; RC_EVENTS=5; WIN_SEEDS=1; WIN_N=20000
  HYP_SEEDS=1; HYP_N=20000; HF_SEEDS=2; HF_N=20000; HF_SEEDS2=2; HF_N2=40000; MERGE_N=20000; MERGE_REPS=2; REAL_N=20000; BIG_CAP=120
  OUT="${OUT_QUICK:-results_quick}"
fi
STAGES=("$@"); [ ${#STAGES[@]} -eq 0 ] && STAGES=(all)
[ "${BIG:-0}" = 1 ] && STAGES+=(big)
[ "${DSCAN:-0}" = 1 ] && STAGES+=(dscan)
[ "${THP:-0}" = 1 ] && STAGES+=(thp)
want() { local s; for s in "${STAGES[@]}"; do if [ "$s" = "$1" ]; then return 0; fi; if [ "$s" = all ] && [ "$1" != big ] && [ "$1" != thp ] && [ "$1" != dscan ]; then return 0; fi; done; return 1; }
explicit() { local s; for s in "${STAGES[@]}"; do [ "$s" = "$1" ] && return 0; done; return 1; }

mkdir -p "$OUT"
exec > >(tee -a "$OUT/run_all.log") 2>&1
echo "run_all.sh started $(date -Is); stages: ${STAGES[*]}; OUT=$OUT"
[ -f bench.cpp ] || { echo "bench.cpp not found next to this script" >&2; exit 1; }
command -v g++ >/dev/null 2>&1 || { echo "g++ not found (Debian/Ubuntu: sudo apt install g++;  Fedora: sudo dnf install gcc-c++)" >&2; exit 1; }
# every file a chosen stage needs must be next to this script: stop now rather than 20 minutes in
MISSING=""
for need in "sweep:run_sweep.sh" "plots:plot_sweep.py" "perf:perf_summarize.py" "thp:run_thp.sh" "hyperfine:hyperfine_report.py"; do
  st="${need%%:*}"; fl="${need#*:}"
  if want "$st" && [ ! -f "$fl" ]; then MISSING="$MISSING $fl"; fi
done
[ -z "$MISSING" ] || { echo "missing next to run_all.sh:$MISSING  (copy them into this folder, then start again)" >&2; exit 1; }

# ---- CPU pinning: first P-core on a hybrid CPU, else none -------------------------------------------------------------
PIN="${PIN:-}"
if [ -z "$PIN" ] && [ -r /sys/devices/cpu_core/cpus ]; then PIN=$(cut -d, -f1 /sys/devices/cpu_core/cpus | cut -d- -f1); echo "hybrid CPU detected: pinning timed runs to P-core $PIN (override with PIN=<cpu>, or PIN=none)"; fi
[ "$PIN" = none ] && PIN=""
pin() { if [ -n "$PIN" ] && command -v taskset >/dev/null 2>&1; then taskset -c "$PIN" "$@"; else "$@"; fi; }

# ---- optional machine tuning for perf (SETUP=1), always restored ----------------------------------------------------------
ORIG_PARANOID=""; ORIG_GOV=""
SUDO_KEEP=""
restore_system() {
  [ -n "$SUDO_KEEP" ] && kill "$SUDO_KEEP" 2>/dev/null
  [ -n "$ORIG_PARANOID" ] && sudo sysctl -w kernel.perf_event_paranoid="$ORIG_PARANOID" >/dev/null 2>&1 && echo "restored perf_event_paranoid=$ORIG_PARANOID"
  [ -n "$ORIG_GOV" ] && sudo cpupower frequency-set -g "$ORIG_GOV" >/dev/null 2>&1 && echo "restored CPU governor=$ORIG_GOV"
  return 0
}
if [ "${SETUP:-0}" = 1 ] && { want perf || want thp; }; then
  trap restore_system EXIT
  # one password prompt now; a background refresh keeps the sudo timestamp alive so that the restore at the end does not wait for a password
  if sudo -v; then ( while true; do sudo -n true 2>/dev/null; sleep 50; done ) & SUDO_KEEP=$!; fi
  P=$(cat /proc/sys/kernel/perf_event_paranoid 2>/dev/null || echo "")
  if [ -n "$P" ] && [ "$P" -gt 1 ]; then sudo sysctl -w kernel.perf_event_paranoid=1 >/dev/null && ORIG_PARANOID="$P" && echo "SETUP: perf_event_paranoid $P -> 1"; fi
  if command -v cpupower >/dev/null 2>&1; then
    G=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo "")
    if [ -n "$G" ] && [ "$G" != performance ]; then sudo cpupower frequency-set -g performance >/dev/null && ORIG_GOV="$G" && echo "SETUP: governor $G -> performance"; fi
  else echo "SETUP: cpupower not installed, governor left as it is (Debian/Ubuntu: sudo apt install linux-tools-generic;  Fedora: sudo dnf install kernel-tools)"; fi
fi

# ---- stages -----------------------------------------------------------------------------------------------------------------
stage_info() {
  {
    echo "date: $(date -Is)"; echo "kernel: $(uname -sr)"; g++ --version | head -n 1
    lscpu 2>/dev/null | grep -E "Model name|^CPU\(s\)|Thread|Core|Socket|MHz|L1d|L1i|L2|L3|Hybrid" || true
    [ -r /sys/devices/cpu_core/cpus ] && echo "P-cores (cpu_core): $(cat /sys/devices/cpu_core/cpus)  E-cores (cpu_atom): $(cat /sys/devices/cpu_atom/cpus 2>/dev/null)"
    free -h 2>/dev/null | head -n 2 || true
    echo "governor: $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null || echo unknown)"
    echo "perf_event_paranoid: $(cat /proc/sys/kernel/perf_event_paranoid 2>/dev/null || echo unknown)"
    echo "perf: $(command -v perf >/dev/null 2>&1 && perf --version || echo not installed)"
    echo "seeds=$SEEDS sat_seeds=$SAT_SEEDS repeat=$REPEAT main_n=$MAIN_N ext_n=$EXT_N sens_n=$SENS_N maxn=$MAXN pin=${PIN:-none} quick=${QUICK:-0}"
    echo "retrybug=$RB_SEEDS/$RB_N rehashclassical=$RHC_SEEDS/$RHC_N rehashcost=$RC_SEEDS/$RC_N/$RC_EVENTS window=$WIN_SEEDS/$WIN_N hyper=$HYP_SEEDS/$HYP_N merge=$MERGE_N/$MERGE_REPS keys=${KEYS:-none} big_cap=$BIG_CAP"
    echo "bench.cpp: $(grep -m1 -o 'v5\.[0-9]*' bench.cpp)"
  } | tee "$OUT/cpu.txt"
}
stage_build() {
  g++ -O2 -std=c++17 -o bench bench.cpp && g++ -O2 -std=c++17 -DNO_ITERS -o bench_clean bench.cpp
}
stage_main()  { pin ./bench main "$MAIN_N" -o "$OUT/report_main.txt"; }
stage_ext()   { ./bench ext "$SEEDS" "$EXT_N" -o "$OUT/report_ext.txt"; }
stage_sweep() { pin bash run_sweep.sh "$SEEDS" "$MAXN" "$OUT"; }
stage_tail()  {
  rm -f "$OUT/tail.csv"
  ./bench tail 1000   "$TAIL_A" -c "$OUT/tail.csv" && ./bench tail 10000 "$TAIL_B" -c "$OUT/tail.csv" && ./bench tail 100000 "$TAIL_C" -c "$OUT/tail.csv"
}
stage_sens()  {
  ./bench sens "$SEEDS" "$SENS_N" -c "$OUT/sens.csv" || return 1
  awk -F, 'NR==1{next} { rows++; if($12+0!=0){bad++}
      b=$3*(1+20*($4+1)); if($15+0>b){over++; print "ITERATION BOUND EXCEEDED row " NR ": " $15 " > " b} }
    END { print "sens.csv: rows=" rows; print (bad? "FAIL: " bad " rows with missing keys" : "OK: no missing keys in any row");
          print (over? "FAIL: " over " rows above K(1+D(s+1))" : "OK: every maxInsIters <= K(1+D(s+1)), D=20");
          exit (bad||over) }' "$OUT/sens.csv" | tee "$OUT/check_sens.txt"
  return "${PIPESTATUS[0]}"
}
stage_sat()   { ./bench sat "$SAT_SEEDS" -c "$OUT/sat.csv"; }
stage_satcomp() {
  local A=(); [ "${QUICK:-0}" = 1 ] && A=(-a 0.88)
  ./bench "${A[@]}" satcomp "$SAT_SEEDS" -c "$OUT/satcomp.csv" && [ -s "$OUT/satcomp.csv" ]
}
stage_hyperfine() {
  ./bench hyperfine "$HF_SEEDS" "$HF_N" -c "$OUT/hyperfine.csv" && [ -s "$OUT/hyperfine.csv" ] || return 1
  ./bench hyperfine "$HF_SEEDS2" "$HF_N2" -c "$OUT/hyperfine_N$HF_N2.csv" && [ -s "$OUT/hyperfine_N$HF_N2.csv" ] || return 1
  python3 hyperfine_report.py "$OUT/hyperfine.csv" "$OUT/hyperfine_N$HF_N2.csv" --out "$OUT/hyperfine" > /dev/null && [ -s "$OUT/hyperfine_report.txt" ] && [ -s "$OUT/hyperfine_table.tex" ]
}
stage_retrybug()       { ./bench retrybug "$RB_SEEDS" "$RB_N" -o "$OUT/report_retrybug.txt"; }
stage_rehashclassical(){ pin ./bench_clean rehashclassical "$RHC_SEEDS" "$RHC_N" -c "$OUT/rehash_classical.csv" -o "$OUT/report_rehash_classical.txt"; }
stage_rehashcost()     { ./bench rehashcost "$RC_SEEDS" "$RC_N" "$RC_EVENTS" -c "$OUT/rehashcost.csv" -o "$OUT/report_rehashcost.txt"; }
stage_window()         { ./bench window "$WIN_SEEDS" "$WIN_N" -o "$OUT/report_window.txt"; }
stage_hyper()          { ./bench hyper "$HYP_SEEDS" "$HYP_N" -o "$OUT/report_hyper.txt"; }
stage_merge()          { pin ./bench_clean merge "$MERGE_N" "$MERGE_REPS" -o "$OUT/report_merge.txt" && grep -q "identicalBehaviour=yes" "$OUT/report_merge.txt" && ! grep -q "identicalBehaviour=NO" "$OUT/report_merge.txt"; }
stage_real()   {
  if [ -z "$KEYS" ] || [ ! -f "$KEYS" ]; then
    echo "no key file (KEYS=keys.bin; make one with: python3 pcap2flows.py trace.pcap.gz --out flows.txt --keys keys.bin --max 2000000)"
    explicit real && return 1 || return 2
  fi
  pin ./bench main "$REAL_N" -k "$KEYS" -o "$OUT/report_real_main.txt" || return 1
  ./bench sweep "$SEEDS" "$MAXN" -k "$KEYS" -c "$OUT/sweep_real.csv" -o "$OUT/report_real_sweep.txt" || return 1
  pin ./bench_clean sweep "$SEEDS" "$MAXN" -k "$KEYS" -c "$OUT/sweep_real_latency.csv" -o "$OUT/report_real_sweep_latency.txt"
}
check_sens_file() {   # $1 = sens csv, $2 = text file for the verdict
  awk -F, 'NR==1{next} { rows++; if($12+0!=0){bad++}
      b=$3*(1+20*($4+1)); if($15+0>b){over++; print "ITERATION BOUND EXCEEDED row " NR ": " $15 " > " b} }
    END { print FILENAME ": rows=" rows; print (bad? "FAIL: " bad " rows with missing keys" : "OK: no missing keys in any row");
          print (over? "FAIL: " over " rows above K(1+D(s+1))" : "OK: every maxInsIters <= K(1+D(s+1)), D=20");
          exit (bad||over) }' "$1" | tee "$2"
  return "${PIPESTATUS[0]}"
}
stage_dscan() {
  local d var A MA rc=0
  for d in $DSCAN_D; do
    var="D${d}_ALPHAS"; A="${!var:-0.80,0.88,0.94}"; var="D${d}_MAIN_A"; MA="${!var:-0.94}"
    echo "---- d=$d loads=$A main-load=$MA"
    ./bench -d "$d" -a "$A" sens "$SEEDS" "$SENS_N" -c "$OUT/sens_d$d.csv" && check_sens_file "$OUT/sens_d$d.csv" "$OUT/check_sens_d$d.txt" || rc=1
    ./bench -d "$d" -a "$A" sat "$SAT_SEEDS" -c "$OUT/sat_d$d.csv" || rc=1
    ./bench -d "$d" -a "$A" window "$WIN_SEEDS" "$WIN_N" -o "$OUT/report_window_d$d.txt" || rc=1
    ./bench -d "$d" -a "$A" hyper "$HYP_SEEDS" "$HYP_N" -o "$OUT/report_hyper_d$d.txt" || rc=1
    ./bench -d "$d" -a "$A" rehashcost "$RC_SEEDS" "$RC_N" "$RC_EVENTS" -c "$OUT/rehashcost_d$d.csv" -o "$OUT/report_rehashcost_d$d.txt" || rc=1
    rm -f "$OUT/tail_d$d.csv"; ./bench -d "$d" -a "$A" tail 100000 "$TAIL_C" -c "$OUT/tail_d$d.csv" || rc=1
    ./bench -d "$d" -a "$A" sweep "$SEEDS" "$MAXN" -c "$OUT/sweep_d$d.csv" -o "$OUT/report_sweep_d$d.txt" || rc=1
    pin ./bench_clean -d "$d" -a "$A" sweep "$SEEDS" "$MAXN" -c "$OUT/sweep_d${d}_latency.csv" -o "$OUT/report_sweep_d${d}_latency.txt" || rc=1
    pin ./bench -d "$d" -a "$MA" main "$MAIN_N" -o "$OUT/report_main_d$d.txt" || rc=1
  done
  return "$rc"
}
stage_thp()   {
  [ -f run_thp.sh ] || { echo "run_thp.sh not found next to this script"; return 1; }
  local E=("OUT=$OUT/thp" "PIN=$PIN")
  [ "${QUICK:-0}" = 1 ] && E+=("SCHEMES=p88" "NS=20000" "OPS=200000" "REPEAT=1" "MODES=never always")
  env "${E[@]}" bash run_thp.sh && [ -s "$OUT/thp/thp_results.csv" ]
}
stage_big()   {
  local cap=(); [ "$BIG_CAP" -gt 0 ] 2>/dev/null && cap=(-T "$BIG_CAP")
  pin ./bench main "$BIG_N" "${cap[@]}" -o "$OUT/report_big.txt" || return 1
  if grep -q "SKIPPED/ABORTED" "$OUT/report_big.txt"; then echo "WARNING: the BIG_CAP=${BIG_CAP}s time cap was hit; blocks marked SKIPPED/ABORTED have no numbers (raise BIG_CAP to complete them)"; return 3; fi
}
stage_plots() {
  [ -f "$OUT/sweep.csv" ] || { echo "no $OUT/sweep.csv (run the sweep stage first)"; return 1; }
  python3 plot_sweep.py "$OUT/sweep.csv" "$OUT/plots"
}
stage_perf()  {
  # returns 0 = done, 1 = failed, 2 = skipped (perf unusable; only when perf was not asked for by name)
  if ! command -v perf >/dev/null 2>&1; then
    echo "perf is not installed. Debian/Ubuntu: sudo apt install linux-perf   (or: sudo apt install linux-tools-generic linux-tools-\$(uname -r))"
    explicit perf && return 1 || return 2
  fi
  local PAR; PAR=$(cat /proc/sys/kernel/perf_event_paranoid 2>/dev/null || echo 2)
  if [ "$PAR" -gt 2 ]; then
    echo "perf_event_paranoid=$PAR blocks the counters. Either re-run with SETUP=1, or: sudo sysctl -w kernel.perf_event_paranoid=1"
    explicit perf && return 1 || return 2
  fi
  local EVENTS="cycles,instructions,cache-references,cache-misses,L1-dcache-loads,L1-dcache-load-misses,LLC-loads,LLC-load-misses,dTLB-loads,dTLB-load-misses"
  local PD="$OUT/perf"; mkdir -p "$PD"; rm -f "$PD"/*.csv "$PD"/*.txt
  [ "${SETUP:-0}" = 1 ] || echo "tip: steadier numbers with the performance governor:  SETUP=1 bash run_all.sh perf   (or: sudo cpupower frequency-set -g performance)"
  local sc N R rep tag fails=0
  for sc in $PERF_SCHEMES; do
    for N in $PERF_NS; do
      R=$(( PERF_OPS / N )); [ "$R" -lt 2 ] && R=2
      for rep in $(seq 1 "$REPEAT"); do
        tag="${sc}_${N}_r${rep}"
        pin perf stat -x, -e "$EVENTS" -o "$PD/${tag}_base.csv" -- ./bench_clean lookup "$sc" "$N" 0 >/dev/null || fails=$((fails+1))
        pin perf stat -x, -e "$EVENTS" -o "$PD/${tag}_run.csv"  -- ./bench_clean lookup "$sc" "$N" "$R" > "$PD/${tag}_run.txt" || fails=$((fails+1))
      done
      echo "  perf $sc N=$N done"
    done
  done
  [ "$fails" -eq 0 ] || echo "WARNING: $fails perf invocations failed"
  python3 perf_summarize.py "$PD" "$PD/perf_summary.csv" || return 1
  [ -s "$PD/perf_summary.csv" ] && [ "$(wc -l < "$PD/perf_summary.csv")" -gt 1 ] || { echo "perf_summary.csv is empty: no usable perf output"; return 1; }
  [ "$fails" -eq 0 ]
}

# ---- driver -----------------------------------------------------------------------------------------------------------------
SUMMARY=(); FAILED=0
run_stage() {
  local name=$1 t0=$SECONDS rc
  want "$name" || return 0
  echo; echo "==== $name  ($(date +%T)) ===="
  "stage_$name"; rc=$?
  local el=$(( SECONDS - t0 )) st
  case $rc in 0) st=OK;; 2) st="SKIPPED";; 3) st="PARTIAL (cap hit)";; *) st="FAILED (rc=$rc)"; FAILED=1;; esac
  SUMMARY+=("$(printf '%-16s %-18s %6d s' "$name" "$st" "$el")")
}
if ! want build && { [ ! -x ./bench ] || [ ! -x ./bench_clean ] || [ bench.cpp -nt ./bench ]; }; then
  echo "binaries missing or older than bench.cpp: building first"; STAGES+=(build)
fi
for s in info build main ext sweep tail sens sat satcomp hyperfine retrybug rehashclassical rehashcost window hyper merge real perf thp dscan big plots; do run_stage "$s"; done

echo; echo "==================== SUMMARY ===================="
printf '%s\n' "${SUMMARY[@]}"
tar czf "$OUT.tar.gz" "$OUT" 2>/dev/null && echo "packed: $OUT.tar.gz  <- send me this one file (or the whole folder $OUT/)"
[ "$FAILED" -eq 0 ] && echo "all requested stages finished" || echo "SOME STAGES FAILED: see above and $OUT/run_all.log"
exit "$FAILED"
