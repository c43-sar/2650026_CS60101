# run_sweep.ps1 - compile bench.cpp (v5) and run the size sweep
# N = 10,20,...,90,100,...,900,1000,...,9000,10000,...,90000,100000,...,900000,1000000
#
# Usage (PowerShell, in the folder holding bench.cpp):
#   powershell -ExecutionPolicy Bypass -File .\run_sweep.ps1
#   powershell -ExecutionPolicy Bypass -File .\run_sweep.ps1 -Seeds 5 -MaxN 1000000 -OutDir results
#   add -SkipClean to skip the second, counter-free latency pass
# Two passes:
#   1. counting build -> sweep.csv          latencies + iteration columns
#   2. clean build    -> sweep_latency.csv  latencies only (-DNO_ITERS: no counters in the timed loops)
# Use sweep_latency.csv for latency numbers in the paper, sweep.csv for iterations.
param(
    [int]$Seeds = 5,
    [int64]$MaxN = 1000000,
    [string]$OutDir = "results",
    [switch]$SkipClean
)
$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

if (-not (Get-Command g++ -ErrorAction SilentlyContinue)) { throw "g++ not found on PATH (MinGW-w64 / MSYS2 g++ is required)." }
if (-not (Test-Path -LiteralPath ".\bench.cpp")) { throw "bench.cpp not found next to this script." }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

Write-Host "== Compiling =="
& g++ -O2 -std=c++17 -o bench.exe bench.cpp
if ($LASTEXITCODE -ne 0) { throw "Compilation failed (exit code $LASTEXITCODE)." }
if (-not $SkipClean) {
    & g++ -O2 -std=c++17 -DNO_ITERS -o bench_clean.exe bench.cpp
    if ($LASTEXITCODE -ne 0) { throw "Clean-build compilation failed (exit code $LASTEXITCODE)." }
}

Write-Host "== Machine info -> $OutDir\cpu.txt =="
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$os  = Get-CimInstance Win32_OperatingSystem
$info = @(
    "date: $(Get-Date -Format o)",
    "os: $($os.Caption) $($os.Version)",
    "cpu: $($cpu.Name)",
    "cores: $($cpu.NumberOfCores)  logical: $($cpu.NumberOfLogicalProcessors)",
    "ram_gb: $([math]::Round($os.TotalVisibleMemorySize / 1MB, 1))",
    "compiler: $((& g++ --version | Select-Object -First 1))",
    "seeds=$Seeds maxN=$MaxN"
)
$info | Set-Content -Encoding utf8 -LiteralPath (Join-Path $OutDir "cpu.txt")
$info | ForEach-Object { Write-Host $_ }

$csv1 = Join-Path $OutDir "sweep.csv"
$csv2 = Join-Path $OutDir "sweep_latency.csv"

Write-Host "== Pass 1: counting build (iterations + latency) =="
$sw = [System.Diagnostics.Stopwatch]::StartNew()
& .\bench.exe sweep $Seeds $MaxN -o (Join-Path $OutDir "report.txt") -c $csv1
if ($LASTEXITCODE -ne 0) { throw "bench.exe failed (exit code $LASTEXITCODE)." }
Write-Host ("Pass 1 elapsed: {0:N0} s" -f $sw.Elapsed.TotalSeconds)

if (-not $SkipClean) {
    Write-Host "== Pass 2: clean build (latency only) =="
    $sw.Restart()
    & .\bench_clean.exe sweep $Seeds $MaxN -o (Join-Path $OutDir "report_latency.txt") -c $csv2
    if ($LASTEXITCODE -ne 0) { throw "bench_clean.exe failed (exit code $LASTEXITCODE)." }
    Write-Host ("Pass 2 elapsed: {0:N0} s" -f $sw.Elapsed.TotalSeconds)
}

Write-Host "== Checking -> $OutDir\check.txt =="
function Test-Sweep([string]$Path, [bool]$Iter) {
    $rows     = Import-Csv -LiteralPath $Path
    $sizes    = @($rows | Select-Object -ExpandProperty N -Unique)
    $expected = $sizes.Count * $Seeds * 7
    $bad      = @($rows | Where-Object { [double]$_.missingMax -ne 0 })
    $out = @("${Path}: rows=$($rows.Count) distinct N=$($sizes.Count) expected=$expected")
    if ($bad.Count) { $out += "  FAIL: $($bad.Count) rows with missingMax != 0" } else { $out += "  OK: missingMax is 0 in every row" }
    if ($Iter) {
        $over = @($rows | Where-Object { $_.scheme -like "proposed_d3_K16_s4*" -and [double]$_.maxInsIters -gt 1616 })
        if ($over.Count) { $out += "  FAIL: $($over.Count) rows above the proposed iteration bound 1616" }
        else { $out += "  OK: proposed maxInsIters <= 1616 = K(1+D(s+1)) for K=16,s=4,D=20" }
        $zero = @($rows | Where-Object { [double]$_.insItersPerOp -le 0 })
        if ($zero.Count) { $out += "  WARNING: $($zero.Count) rows with no iteration counts (counter-free build?)" }
    }
    if ($rows.Count -ne $expected) { $out += "  WARNING: row count differs from expected" }
    return $out
}
$check = @(Test-Sweep $csv1 $true)
if (Test-Path -LiteralPath $csv2) { $check += Test-Sweep $csv2 $false }
$check | Tee-Object -FilePath (Join-Path $OutDir "check.txt")

Write-Host "Done. Send me everything in $OutDir\ (sweep.csv, sweep_latency.csv, report*.txt, cpu.txt, check.txt)"
Write-Host "Optional plots: py plot_sweep.py $OutDir\sweep.csv $OutDir\plots   (needs pandas, matplotlib)"
