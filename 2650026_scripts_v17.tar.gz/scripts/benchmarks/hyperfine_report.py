#!/usr/bin/env python3
"""hyperfine_report.py hyperfine.csv [hyperfine_N2.csv ...] [--out PREFIX]
Reads the per-seed rows of `bench hyperfine` and writes PREFIX_report.txt, PREFIX_summary.csv and PREFIX_table.tex.
For every N, load alpha and density bin: pooled stash-routing rate with a 95% interval from resampling whole builds (seeds), the mean density of
the insertions in the bin, the mean of min(density,1)^16 (the heuristic prediction) and the mean rounds. Then, for every density bin and every pair of loads,
the difference of the rates with a 95% interval (builds of the two loads resampled independently). A bin is 'consistent with load-independence' when
that interval contains 0. Nothing here is a proof: it is the check of the paper's statement that the rate is set by the density and not by the load."""
import csv, sys, random, math, collections
args = sys.argv[1:]; prefix = "hyperfine"
if "--out" in args:
    i = args.index("--out"); prefix = args[i+1]; del args[i:i+2]
files = args
BN = ["<0.50", "0.50-0.75", "0.75-0.80", "0.80-0.85", "0.85-0.90", "0.90-0.95", "0.95-1.00", "1.00-1.10", ">=1.10"]
VN = ["<129", "129-2048", "2049-16384", ">16384"]
B = 2000; rnd = random.Random(12345)
# data[N][alpha][dbin][seed] = [n, routed, sumDens, sumRounds, sumPred]   (pooled over the size bins unless split by vbin)
def load():
    data = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(lambda: [0, 0, 0.0, 0.0, 0.0]))))
    datav = collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(lambda: collections.defaultdict(lambda: [0, 0, 0.0, 0.0, 0.0]))))
    for f in files:
        for r in csv.DictReader(open(f)):
            N = int(r["N"]); a = round(float(r["alpha"]), 4); b = int(r["dbin"]); v = int(r["vbin"]); sd = int(r["seed"])
            row = [int(r["n"]), int(r["routed"]), float(r["sumDens"]), float(r["sumRounds"]), float(r["sumPredK"])]
            for dst, key in ((data[N][a][b][sd], None), (datav[N][a][(b, v)][sd], None)):
                for k in range(5): dst[k] += row[k]
    return data, datav
data, datav = load()
def pooled(per_seed):
    t = [0, 0, 0.0, 0.0, 0.0]
    for x in per_seed.values():
        for k in range(5): t[k] += x[k]
    return t
def rate(per_seed, seeds):
    n = sum(per_seed[s][0] for s in seeds if s in per_seed); r = sum(per_seed[s][1] for s in seeds if s in per_seed)
    return r / n if n else None
def boot(per_seed, allseeds):
    out = []
    for _ in range(B):
        pick = [rnd.choice(allseeds) for _ in allseeds]
        n = sum(per_seed[s][0] for s in pick if s in per_seed); r = sum(per_seed[s][1] for s in pick if s in per_seed)
        if n: out.append(r / n)
    out.sort(); return (out[int(0.025 * len(out))], out[int(0.975 * len(out)) - 1]) if len(out) > 20 else (None, None)
def bootdiff(ps1, s1, ps2, s2):
    out = []
    for _ in range(B):
        p1 = [rnd.choice(s1) for _ in s1]; p2 = [rnd.choice(s2) for _ in s2]
        n1 = sum(ps1[s][0] for s in p1 if s in ps1); r1 = sum(ps1[s][1] for s in p1 if s in ps1)
        n2 = sum(ps2[s][0] for s in p2 if s in ps2); r2 = sum(ps2[s][1] for s in p2 if s in ps2)
        if n1 and n2: out.append(r1 / n1 - r2 / n2)
    out.sort(); return (out[int(0.025 * len(out))], out[int(0.975 * len(out)) - 1]) if len(out) > 20 else (None, None)
L = []; P = L.append; S = [["N", "alpha", "dbin", "density_bin", "n", "routed", "rate", "ci_lo", "ci_hi", "mean_density", "mean_density_pow16", "mean_rounds"]]
T = []
P("hyperfine report. Rates are stash-routed insertions / insertions in the density bin; intervals resample whole builds (seeds).")
P("density = E/V of the component the key joins just before its own hyperedge is added. pred = mean of min(density,1)^16 over the insertions of the bin (heuristic).")
for N in sorted(data):
    alphas = sorted(data[N]); seeds = {a: sorted({s for b in data[N][a] for s in data[N][a][b]}) for a in alphas}
    P(""); P("=== N=%d  loads %s  builds per load %s ===" % (N, ", ".join("%.2f" % a for a in alphas), ", ".join(str(len(seeds[a])) for a in alphas)))
    P("%-10s %-6s %10s %9s %10s %-23s %9s %9s %9s" % ("density", "alpha", "inserts", "routed", "rate", "95% CI (builds)", "meanDens", "dens^16", "meanRnds"))
    for b in range(9):
        for a in alphas:
            ps = data[N][a].get(b)
            if not ps: continue
            t = pooled(ps); lo, hi = boot(ps, seeds[a])
            ci = "[%.4g, %.4g]" % (lo, hi) if lo is not None else "n/a"
            P("%-10s %-6.2f %10d %9d %10.4g %-23s %9.4f %9.4f %9.2f" % (BN[b], a, t[0], t[1], t[1] / t[0], ci, t[2] / t[0], t[4] / t[0], t[3] / t[0]))
            S.append([N, a, b, BN[b], t[0], t[1], t[1] / t[0], lo, hi, t[2] / t[0], t[4] / t[0], t[3] / t[0]])
    P(""); P("(Every interval is 95% on its own, with no correction for the number of comparisons: with about 40 comparisons one or two intervals missing 0 can arise by chance.)")
    P(""); P("Cross-load comparison per density bin (difference of the rates, higher load minus lower load; consistent = the 95% interval contains 0; bins with fewer than 2000 insertions at either load are skipped):")
    cons = {"below0.90": [0, 0], "at_or_above0.90": [0, 0]}
    for b in range(9):
        for i in range(len(alphas)):
            for j in range(i + 1, len(alphas)):
                a1, a2 = alphas[i], alphas[j]; p1 = data[N][a1].get(b); p2 = data[N][a2].get(b)
                if not p1 or not p2: continue
                t1 = pooled(p1); t2 = pooled(p2)
                if t1[0] < 2000 or t2[0] < 2000: continue
                lo, hi = bootdiff(p2, seeds[a2], p1, seeds[a1]); d = t2[1] / t2[0] - t1[1] / t1[0]
                if lo is None: continue
                ok = lo <= 0 <= hi; grp = "below0.90" if b <= 4 else "at_or_above0.90"
                cons[grp][0] += ok; cons[grp][1] += 1
                P("  %-10s alpha %.2f vs %.2f: diff %+.4g  95%% CI [%+.4g, %+.4g]  mean density %.4f vs %.4f  -> %s" % (BN[b], a2, a1, d, lo, hi, t2[2] / t2[0], t1[2] / t1[0], "consistent with load-independence" if ok else "DIFFERS"))
    for g, (c, n) in cons.items(): P("  summary %s: %d of %d pairwise comparisons consistent with load-independence" % (g, c, n))
    # component size split for the 0.90-1.00 range
    P(""); P("Density 0.90-1.00 split by component size (slots touched), pooled over the two 0.05 bins:")
    P("%-12s %-6s %10s %10s %9s" % ("size bin", "alpha", "inserts", "rate", "meanDens"))
    for v in range(4):
        for a in alphas:
            n = r = 0; sd_ = 0.0
            for b in (5, 6):
                ps = datav[N][a].get((b, v))
                if ps:
                    t = pooled(ps); n += t[0]; r += t[1]; sd_ += t[2]
            if n: P("%-12s %-6.2f %10d %10.4g %9.4f" % (VN[v], a, n, r / n, sd_ / n))
    # formula check
    P(""); P("Heuristic check, rate in the bin against the mean of min(density,1)^16 (the bins with >= 2000 insertions): ratio observed/predicted")
    for b in range(2, 9):
        rs = []
        for a in alphas:
            ps = data[N][a].get(b)
            if ps:
                t = pooled(ps)
                if t[0] >= 2000 and t[4] > 0: rs.append("%.2f:%.2f" % (a, (t[1] / t[0]) / (t[4] / t[0])))
        if rs: P("  %-10s alpha:ratio  %s" % (BN[b], "  ".join(rs)))
    if len(alphas) >= 2:
        T.append((N, alphas, seeds))
open(prefix + "_report.txt", "w").write("\n".join(L) + "\n")
with open(prefix + "_summary.csv", "w", newline="") as fh: csv.writer(fh).writerows(S)
# LaTeX table for the first N
N0 = sorted(data)[0]; al = sorted(data[N0])
with open(prefix + "_table.tex", "w") as fh:
    fh.write("%% generated by hyperfine_report.py from N=%d; stash-routed fraction (95%% interval over builds) per density bin and load\n" % N0)
    fh.write("\\begin{tabular}{l" + "r" * len(al) + "}\n\\toprule\nDensity bin & " + " & ".join("$\\alpha=%.2f$" % a for a in al) + " \\\\\n\\midrule\n")
    for b in range(9):
        cells = []; any_ = False
        for a in al:
            ps = data[N0][a].get(b)
            if ps and pooled(ps)[0] >= 2000:
                t = pooled(ps); lo, hi = boot(ps, seeds_ := sorted({s for bb in data[N0][a] for s in data[N0][a][bb]}))
                cells.append("%.3g\\,[%.2g, %.2g]" % (t[1] / t[0], lo, hi) if lo is not None else "%.3g" % (t[1] / t[0])); any_ = True
            else: cells.append("--")
        if any_: fh.write(BN[b].replace("<", "$<$").replace(">=", "$\\ge$") + " & " + " & ".join(cells) + " \\\\\n")
    fh.write("\\bottomrule\n\\end{tabular}\n")
print("\n".join(L))
