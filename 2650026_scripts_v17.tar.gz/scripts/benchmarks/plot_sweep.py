#!/usr/bin/env python3
"""Plot bench.cpp sweep CSV. Linear axes only (no log scales). max* columns show the worst case over seeds.

Usage:  python plot_sweep.py sweep.csv [outdir]      (Windows: py plot_sweep.py sweep.csv plots)
Each metric gets one PNG with three zoom panels (N in [10,1000], [1000,100k], [100k,1M]),
because a single linear axis from 10 to 1M would squash everything below 100k into one pixel column.
Lines = mean over seeds; band = +-1 sample sd over seeds (absent when only one seed).
"""
import sys, os
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

csv = sys.argv[1] if len(sys.argv) > 1 else "sweep.csv"
out = sys.argv[2] if len(sys.argv) > 2 else "plots"
os.makedirs(out, exist_ok=True)
df = pd.read_csv(csv)
df["stashRoutedFrac"] = df.stashRoutedPerRun / df.N
df["overflowFrac"] = df.overflowPerRun / df.N

METRICS = [
    ("insNsPerOp",      "Insert time per key (ns)"),
    ("lookNsPerOp",     "Lookup time per key (ns)"),
    ("insItersPerOp",   "Insert iterations per key (mean)"),
    ("maxInsIters",     "Insert iterations, worst single insert (incl. nested rehash work)"),
    ("insItersPerRun",  "Insert iterations per full build (total)"),
    ("lookItersPerOp",  "Lookup iterations per key (mean cells/nodes visited)"),
    ("maxLookIters",    "Lookup iterations, worst single lookup"),
    ("meanInsWork",     "Legacy mixed 'work' (probes, or evictions with rehash/stash counted as the cap)"),
    ("maxInsWork",      "Max single-insert work (evictions or probes; proposed: top-level kicks only)"),
    ("meanLookProbes",  "Mean lookup probes"),
    ("maxLookProbes",   "Max lookup probes"),
    ("cellsPerKey",     "Space: table cells per key"),
    ("rehashesPerRun",  "Classical: full rehashes per run; proposed: RehashStash events per run"),
    ("stashRoutedPerRun", "Keys routed to stash per run"),
    ("overflowPerRun",  "Stash-overflow events per run"),
    ("stashRoutedFrac", "Fraction of inserts routed to the stash (proposed only)"),
    ("overflowFrac",    "Stash-overflow events per insert (proposed only)"),
]
PANELS = [(10, 1000), (1000, 100000), (100000, 1000000)]
STYLE = {  # fixed colour + marker per scheme so every figure reads the same
    "linear_probing":        ("#1f77b4", "o"),
    "chained":               ("#7f7f7f", "s"),
    "classical_short":       ("#d62728", "^"),
    "classical_prescribed":  ("#ff7f0e", "v"),
    "proposed_d3_K16_s4_a45": ("#98df8a", "D"),
    "proposed_d3_K16_s4_a80": ("#2ca02c", "D"),
    "proposed_d3_K16_s4_a88": ("#006400", "D"),
}
schemes = [s for s in STYLE if s in set(df.scheme)] + [s for s in df.scheme.unique() if s not in STYLE]

# per-(scheme,N): mean and sd across seeds
g = df.groupby(["scheme", "N"])
mean = g.mean(numeric_only=True)
maxagg = g.max(numeric_only=True)   # for columns named max*: the worst case over all seeds, not a mean of maxima
sd = g.std(numeric_only=True).fillna(0.0)

# the measured missing-key count must be zero everywhere; say so loudly if not
bad = df[df.missingMax != 0]
if len(bad):
    print("WARNING: missingMax != 0 in", len(bad), "rows -- results invalid:")
    print(bad[["scheme", "N", "seed", "missingMax"]].to_string())

for col, label in METRICS:
    if col not in df.columns:
        continue
    if "Iter" in col and df[col].abs().sum() == 0:   # latency-only (-DNO_ITERS) CSV: nothing to plot
        continue
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))
    for ax, (lo, hi) in zip(axes, PANELS):
        for s in schemes:
            if s not in mean.index.get_level_values(0):
                continue
            m = mean.loc[s]; d = sd.loc[s]
            m = m[(m.index >= lo) & (m.index <= hi)]
            if m.empty:
                continue
            d = d.loc[m.index]
            c, mk = STYLE.get(s, (None, "o"))
            if col.startswith("max"):
                y = maxagg.loc[s].loc[m.index, col]
                ax.plot(m.index, y, marker=mk, ms=4, lw=1.3, color=c, label=s)
            else:
                ax.plot(m.index, m[col], marker=mk, ms=4, lw=1.3, color=c, label=s)
                ax.fill_between(m.index, m[col] - d[col], m[col] + d[col], color=c, alpha=0.15, lw=0)
        ax.set_xlim(lo, hi)
        ax.set_xlabel("N (keys)")
        ax.grid(alpha=0.3)
        ax.set_title(f"N in [{lo:,}, {hi:,}]", fontsize=10)
    axes[0].set_ylabel(label)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=min(len(l), 4), fontsize=8, frameon=False, bbox_to_anchor=(0.5, 0.05))
    fig.suptitle(label + ("  (worst case over all seeds)" if col.startswith("max") else "  (mean over seeds, band = +-1 sd)"), fontsize=11)
    note = None
    if col.startswith("max") or col in ("rehashesPerRun", "overflowPerRun", "stashRoutedPerRun", "overflowFrac"):
        note = ("Tail/rare-event metric. Builds sampled per size = seeds x min(100000, 1e6/N): 5e5 at N=10, 5e3 at N=1000, "
                "5e2 at N=1e4, 50 at N=1e5, 5 at N=1e6. Rare events (a classical rehash) are under-sampled at large N: "
                "a missing spike there is NOT evidence of absence. Use `bench tail` for large N.")
    elif col in ("insNsPerOp", "lookNsPerOp"):
        note = "Latency: absolute ns depend on the OS/CPU state (Windows timer ~100 ns, turbo, background load). Read shapes and ordering, not exact values."
    if note:
        fig.text(0.5, 0.005, note, ha="center", va="bottom", fontsize=7, color="#444444", wrap=True)
    fig.tight_layout(rect=(0, 0.16, 1, 0.95))
    p = os.path.join(out, f"{col}.png")
    fig.savefig(p, dpi=130)
    plt.close(fig)
    print("wrote", p)
