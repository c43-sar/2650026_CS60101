# run_all.ps1 - every benchmark run of the ADSA paper in one script (Windows PowerShell 5.1 / PowerShell 7).
#
# Usage (in the folder holding bench.cpp, run_sweep.ps1, plot_sweep.py):
#   powershell -ExecutionPolicy Bypass -File .\run_all.ps1                       # all stages
#   powershell -ExecutionPolicy Bypass -File .\run_all.ps1 -Stage sens,sat       # selected stages (comma separated)
#   powershell -ExecutionPolicy Bypass -File .\run_all.ps1 -Stage tail -OutDir results_i3
# Stages (default: all):
#   info   machine description -> cpu.txt
#   build  compile bench.exe (counting build) and bench_clean.exe (-DNO_ITERS, for latency)
#   main   `bench main`   main tables at N = 2,000,000                     -> report_main.txt
#   ext    `bench ext`    multi-seed runs at the shared loads (Table of shared-load comparison)    -> report_ext.txt
#   sweep  size sweep N = 10..1,000,000 (calls run_sweep.ps1)              -> sweep.csv, sweep_latency.csv, check.txt
#   tail   rare-event sampling at N = 1e3, 1e4, 1e5                        -> tail.csv
#   sens   MaxKicks and stash-size sensitivity                   -> sens.csv, check_sens.txt
#   sat    stash routing vs table size at exact integer load               -> sat.csv
#   retrybug         the retired wrong-key retry, reproduced (correct vs retired)     -> report_retrybug.txt
#   rehashclassical  classical 2-way cuckoo: every full rehash timed, nesting depth    -> report_rehash_classical.txt, rehash_classical.csv
#   rehashcost       real RehashStash vs a full rebuild of an identical copy           -> report_rehashcost.txt, rehashcost.csv
#   window           stash-overflow bound: observed windows vs Chernoff/binomial       -> report_window.txt
#   hyper            hypergraph counters, local 2-hop view, offline minimum stash      -> report_hyper.txt
#   merge            key + occupancy merged into one array vs separate arrays          -> report_merge.txt
#   real             real trace: `bench main` and the size sweep on keys from -Keys keys.bin; skipped when -Keys is not given
#   dscan            OPTIONAL, only when named: the proposed scheme at d = -DscanD (default 4,5) with loads suited to each d (bench -d D -a LOADS):
#                    sens, sat, window, hyper, rehashcost, tail, size sweep (counting + latency), main
#                    -> sens_d4.csv, check_sens_d4.txt, sat_d4.csv, report_window_d4.txt, report_hyper_d4.txt, rehashcost_d4.csv, tail_d4.csv,
#                       sweep_d4.csv, sweep_d4_latency.csv, report_main_d4.txt (and the same for d5)
#                    loads: -DscanAlphas @{4="0.80,0.88,0.94,0.96"; 5="0.80,0.88,0.95,0.98"}; main target load: -DscanMainAlpha @{4="0.94"; 5="0.96"}
#                    offline thresholds (one key per cell): d=3 0.9179, d=4 0.9768, d=5 0.9924 -- keep every load below them
#   big              OPTIONAL, only when named: `bench main` at N = -BigN with time cap -BigCapSec -> report_big.txt
#   plots  plots of sweep.csv (py plot_sweep.py; needs pandas, matplotlib) -> plots\
# There is no perf stage: `perf stat` exists on Linux only (use run_all.sh there).
# -Quick runs tiny sizes everywhere (smoke test; numbers NOT for the paper).
# Counts (iterations, stash statistics, tail, sens, sat) are machine-independent. Latency is not.
param(
    [string[]]$Stage = @("all"),
    [int]$Seeds = 5,
    [string]$OutDir = "results_win",
    [int64]$SensN = 2000000,
    [int]$SatSeeds = 3,
    [string]$Keys = "",
    [int64]$BigN = 10000000,
    [int]$BigCapSec = 14400,
    [int[]]$DscanD = @(4, 5),
    [hashtable]$DscanAlphas = @{ 4 = "0.80,0.88,0.94,0.96"; 5 = "0.80,0.88,0.95,0.98" },
    [hashtable]$DscanMainAlpha = @{ 4 = "0.94"; 5 = "0.96" },
    [switch]$Quick
)
$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

# accept  -Stage sens,sat  (PowerShell gives an array)  and  -Stage "sens,sat"  (one string)
$stages = @($Stage | ForEach-Object { $_ -split "[,\s]+" } | Where-Object { $_ })
function Want([string]$s) {
    if ($stages -contains $s) { return $true }
    if ($s -eq "big" -or $s -eq "dscan") { return $false }          # big and dscan run only when named
    return ($stages -contains "all")
}
# sizes of the stages (full run / -Quick smoke test)
$rbSeeds = 5; $rbN = 200000; $rhcSeeds = 3; $rhcN = 2000000; $rcSeeds = 3; $rcN = 200000; $rcEvents = 50
$winSeeds = 5; $winN = 2000000; $hypSeeds = 3; $hypN = 200000; $mergeN = 2000000; $mergeReps = 7; $realN = 2000000
if ($Quick) {
    $Seeds = 1; $SatSeeds = 1; $SensN = 20000; $OutDir = "results_quick"; $BigN = 50000; $BigCapSec = 120
    $rbSeeds = 1; $rbN = 20000; $rhcSeeds = 1; $rhcN = 20000; $rcSeeds = 1; $rcN = 20000; $rcEvents = 5
    $winSeeds = 1; $winN = 20000; $hypSeeds = 1; $hypN = 20000; $mergeN = 20000; $mergeReps = 2; $realN = 20000
}
$mainN = 2000000; $maxN = 1000000
if ($Quick) { $mainN = 20000; $maxN = 2000 }

if (-not (Get-Command g++ -ErrorAction SilentlyContinue)) { throw "g++ not found on PATH (MinGW-w64 / MSYS2 g++ is required)." }
if (-not (Test-Path -LiteralPath ".\bench.cpp")) { throw "bench.cpp not found next to this script." }
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function Run([string]$exe, [string[]]$arguments) {
    & $exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "$exe $($arguments -join ' ') failed (exit code $LASTEXITCODE)." }
}

if (Want "info") {
    Write-Host "== info -> $OutDir\cpu.txt"
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $os  = Get-CimInstance Win32_OperatingSystem
    $info = @(
        "date: $(Get-Date -Format o)",
        "os: $($os.Caption) $($os.Version)",
        "cpu: $($cpu.Name)",
        "cores: $($cpu.NumberOfCores)  logical: $($cpu.NumberOfLogicalProcessors)",
        "l2_kb: $($cpu.L2CacheSize)  l3_kb: $($cpu.L3CacheSize)",
        "ram_gb: $([math]::Round($os.TotalVisibleMemorySize / 1MB, 1))",
        "power_plan: $((powercfg /getactivescheme) -join ' ')",
        "compiler: $((& g++ --version | Select-Object -First 1))",
        "seeds=$Seeds sens_n=$SensN sat_seeds=$SatSeeds"
    )
    $info | Set-Content -Encoding utf8 -LiteralPath (Join-Path $OutDir "cpu.txt")
    $info | ForEach-Object { Write-Host $_ }
}

if (Want "build") {
    Write-Host "== build"
    Run "g++" @("-O2", "-std=c++17", "-o", "bench.exe", "bench.cpp")
    Run "g++" @("-O2", "-std=c++17", "-DNO_ITERS", "-o", "bench_clean.exe", "bench.cpp")
}
if (-not ((Test-Path -LiteralPath ".\bench.exe") -and (Test-Path -LiteralPath ".\bench_clean.exe"))) {
    throw "bench.exe / bench_clean.exe missing: run the build stage first (-Stage build)."
}

if (Want "main") {
    Write-Host "== main (N=$mainN)"
    Run ".\bench.exe" @("main", "$mainN", "-o", (Join-Path $OutDir "report_main.txt"))
}
if (Want "ext") {
    Write-Host "== ext (seeds=$Seeds, N=$mainN)"
    Run ".\bench.exe" @("ext", "$Seeds", "$mainN", "-o", (Join-Path $OutDir "report_ext.txt"))
}
if (Want "sweep") {
    Write-Host "== sweep (run_sweep.ps1)"
    if (-not (Test-Path -LiteralPath ".\run_sweep.ps1")) { throw "run_sweep.ps1 not found next to this script." }
    & powershell -NoProfile -ExecutionPolicy Bypass -File .\run_sweep.ps1 -Seeds $Seeds -MaxN $maxN -OutDir $OutDir
    if ($LASTEXITCODE -ne 0) { throw "run_sweep.ps1 failed (exit code $LASTEXITCODE)." }
}
if (Want "tail") {
    Write-Host "== tail"
    $tcsv = Join-Path $OutDir "tail.csv"
    if (Test-Path -LiteralPath $tcsv) { Remove-Item -LiteralPath $tcsv }
    Run ".\bench.exe" @("tail", "1000",   "20000", "-c", $tcsv)
    Run ".\bench.exe" @("tail", "10000",  "2000",  "-c", $tcsv)
    Run ".\bench.exe" @("tail", "100000", "2000",  "-c", $tcsv)
}
if (Want "sens") {
    Write-Host "== sens (seeds=$Seeds, N=$SensN)"
    $scsv = Join-Path $OutDir "sens.csv"
    Run ".\bench.exe" @("sens", "$Seeds", "$SensN", "-c", $scsv)
    $rows = @(Import-Csv -LiteralPath $scsv)
    $miss = @($rows | Where-Object { [double]$_.missing -ne 0 })
    $over = @($rows | Where-Object { [double]$_.maxInsIters -gt ([double]$_.maxKicks * (1 + 20 * ([double]$_.stash + 1))) })
    $out = @("sens.csv: rows=$($rows.Count)")
    if ($miss.Count) { $out += "FAIL: $($miss.Count) rows with missing keys" } else { $out += "OK: no missing keys in any row" }
    if ($over.Count) { $out += "FAIL: $($over.Count) rows above K(1+D(s+1))" } else { $out += "OK: every maxInsIters <= K(1+D(s+1)), D=20" }
    $out | Tee-Object -FilePath (Join-Path $OutDir "check_sens.txt")
}
if (Want "sat") {
    Write-Host "== sat (seeds=$SatSeeds)"
    Run ".\bench.exe" @("sat", "$SatSeeds", "-c", (Join-Path $OutDir "sat.csv"))
}
if (Want "retrybug") {
    Write-Host "== retrybug (seeds=$rbSeeds, N=$rbN)"
    Run ".\bench.exe" @("retrybug", "$rbSeeds", "$rbN", "-o", (Join-Path $OutDir "report_retrybug.txt"))
}
if (Want "rehashclassical") {
    Write-Host "== rehashclassical (seeds=$rhcSeeds, N=$rhcN)  [slow at N=2,000,000]"
    Run ".\bench_clean.exe" @("rehashclassical", "$rhcSeeds", "$rhcN", "-c", (Join-Path $OutDir "rehash_classical.csv"), "-o", (Join-Path $OutDir "report_rehash_classical.txt"))
}
if (Want "rehashcost") {
    Write-Host "== rehashcost (seeds=$rcSeeds, N=$rcN, events=$rcEvents)"
    Run ".\bench.exe" @("rehashcost", "$rcSeeds", "$rcN", "$rcEvents", "-c", (Join-Path $OutDir "rehashcost.csv"), "-o", (Join-Path $OutDir "report_rehashcost.txt"))
}
if (Want "window") {
    Write-Host "== window (seeds=$winSeeds, N=$winN)"
    Run ".\bench.exe" @("window", "$winSeeds", "$winN", "-o", (Join-Path $OutDir "report_window.txt"))
}
if (Want "hyper") {
    Write-Host "== hyper (seeds=$hypSeeds, N=$hypN)"
    Run ".\bench.exe" @("hyper", "$hypSeeds", "$hypN", "-o", (Join-Path $OutDir "report_hyper.txt"))
}
if (Want "merge") {
    Write-Host "== merge (N=$mergeN, reps=$mergeReps)"
    $mrep = Join-Path $OutDir "report_merge.txt"
    Run ".\bench_clean.exe" @("merge", "$mergeN", "$mergeReps", "-o", $mrep)
    if (Select-String -LiteralPath $mrep -Pattern "identicalBehaviour=NO" -Quiet) { throw "merge: the two layouts did NOT behave identically; ignore the timings." }
}
if (Want "real") {
    if (-not $Keys -or -not (Test-Path -LiteralPath $Keys)) {
        $msg = "real: no key file (-Keys keys.bin; make one with: py pcap2flows.py trace.pcap.gz --out flows.txt --keys keys.bin --max 2000000)"
        if ($stages -contains "real") { throw $msg } else { Write-Host "== $msg  -> skipped" }
    } else {
        Write-Host "== real (keys=$Keys)"
        Run ".\bench.exe" @("main", "$realN", "-k", $Keys, "-o", (Join-Path $OutDir "report_real_main.txt"))
        Run ".\bench.exe" @("sweep", "$Seeds", "$maxN", "-k", $Keys, "-c", (Join-Path $OutDir "sweep_real.csv"), "-o", (Join-Path $OutDir "report_real_sweep.txt"))
        Run ".\bench_clean.exe" @("sweep", "$Seeds", "$maxN", "-k", $Keys, "-c", (Join-Path $OutDir "sweep_real_latency.csv"), "-o", (Join-Path $OutDir "report_real_sweep_latency.txt"))
    }
}
if (Want "dscan") {
    foreach ($d in $DscanD) {
        $A  = if ($DscanAlphas.ContainsKey($d)) { [string]$DscanAlphas[$d] } else { "0.80,0.88,0.94" }
        $MA = if ($DscanMainAlpha.ContainsKey($d)) { [string]$DscanMainAlpha[$d] } else { "0.94" }
        Write-Host "== dscan d=$d loads=$A main-load=$MA"
        $scsv = Join-Path $OutDir "sens_d$d.csv"
        Run ".\bench.exe" @("-d", "$d", "-a", $A, "sens", "$Seeds", "$SensN", "-c", $scsv)
        $rows = @(Import-Csv -LiteralPath $scsv)
        $miss = @($rows | Where-Object { [double]$_.missing -ne 0 })
        $over = @($rows | Where-Object { [double]$_.maxInsIters -gt ([double]$_.maxKicks * (1 + 20 * ([double]$_.stash + 1))) })
        $out = @("sens_d$d.csv: rows=$($rows.Count)")
        if ($miss.Count) { $out += "FAIL: $($miss.Count) rows with missing keys" } else { $out += "OK: no missing keys in any row" }
        if ($over.Count) { $out += "FAIL: $($over.Count) rows above K(1+D(s+1))" } else { $out += "OK: every maxInsIters <= K(1+D(s+1)), D=20" }
        $out | Tee-Object -FilePath (Join-Path $OutDir "check_sens_d$d.txt")
        Run ".\bench.exe" @("-d", "$d", "-a", $A, "sat", "$SatSeeds", "-c", (Join-Path $OutDir "sat_d$d.csv"))
        Run ".\bench.exe" @("-d", "$d", "-a", $A, "window", "$winSeeds", "$winN", "-o", (Join-Path $OutDir "report_window_d$d.txt"))
        Run ".\bench.exe" @("-d", "$d", "-a", $A, "hyper", "$hypSeeds", "$hypN", "-o", (Join-Path $OutDir "report_hyper_d$d.txt"))
        Run ".\bench.exe" @("-d", "$d", "-a", $A, "rehashcost", "$rcSeeds", "$rcN", "$rcEvents", "-c", (Join-Path $OutDir "rehashcost_d$d.csv"), "-o", (Join-Path $OutDir "report_rehashcost_d$d.txt"))
        $tcsv = Join-Path $OutDir "tail_d$d.csv"
        if (Test-Path -LiteralPath $tcsv) { Remove-Item -LiteralPath $tcsv }
        Run ".\bench.exe" @("-d", "$d", "-a", $A, "tail", "100000", "$(if ($Quick) { 20 } else { 2000 })", "-c", $tcsv)
        Run ".\bench.exe" @("-d", "$d", "-a", $A, "sweep", "$Seeds", "$maxN", "-c", (Join-Path $OutDir "sweep_d$d.csv"), "-o", (Join-Path $OutDir "report_sweep_d$d.txt"))
        Run ".\bench_clean.exe" @("-d", "$d", "-a", $A, "sweep", "$Seeds", "$maxN", "-c", (Join-Path $OutDir "sweep_d${d}_latency.csv"), "-o", (Join-Path $OutDir "report_sweep_d${d}_latency.txt"))
        Run ".\bench.exe" @("-d", "$d", "-a", $MA, "main", "$mainN", "-o", (Join-Path $OutDir "report_main_d$d.txt"))
    }
}
if (Want "big") {
    Write-Host "== big (N=$BigN, time cap $BigCapSec s)"
    $brep = Join-Path $OutDir "report_big.txt"
    $bargs = @("main", "$BigN")
    if ($BigCapSec -gt 0) { $bargs += @("-T", "$BigCapSec") }
    $bargs += @("-o", $brep)
    Run ".\bench.exe" $bargs
    if (Select-String -LiteralPath $brep -Pattern "SKIPPED/ABORTED" -Quiet) {
        Write-Warning "the time cap ($BigCapSec s) was hit: blocks marked SKIPPED/ABORTED have no numbers (raise -BigCapSec to complete them)."
    }
}
if (Want "plots") {
    Write-Host "== plots"
    $sw = Join-Path $OutDir "sweep.csv"
    if (Test-Path -LiteralPath $sw) {
        & py plot_sweep.py $sw (Join-Path $OutDir "plots")
        if ($LASTEXITCODE -ne 0) { Write-Warning "plot_sweep.py failed (pip install pandas matplotlib)." }
    } else { Write-Host "no $sw yet (run the sweep stage)" }
}
Compress-Archive -Path $OutDir -DestinationPath "$OutDir.zip" -Force
Write-Host "Done. Everything is in $OutDir\ and packed in $OutDir.zip : send me that zip."
