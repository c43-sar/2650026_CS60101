#!/usr/bin/env bash
# run_sweep.sh - compile bench.cpp (v5) and run the size sweep N = 10,20,...,90,100,...,1000000.
# Usage:  bash run_sweep.sh [seeds=5] [maxN=1000000] [outdir=results]
#         SKIP_CLEAN=1 bash run_sweep.sh        # skip the second, counter-free latency pass
# Two passes:
#   1. counting build  -> sweep.csv          latencies + iteration columns
#   2. clean build     -> sweep_latency.csv  latencies only (built with -DNO_ITERS, no counters in the timed loops)
# Use sweep_latency.csv for latency numbers in the paper, sweep.csv for iterations.
set -euo pipefail
cd "$(dirname "$0")"
SEEDS="${1:-5}"; MAXN="${2:-1000000}"; OUT="${3:-results}"

command -v g++ >/dev/null 2>&1 || { echo "g++ not found. Debian/Ubuntu: sudo apt install g++" >&2; exit 1; }
[ -f bench.cpp ] || { echo "bench.cpp not found next to this script" >&2; exit 1; }
mkdir -p "$OUT"

echo "== Compiling =="
g++ -O2 -std=c++17 -o bench bench.cpp
[ "${SKIP_CLEAN:-0}" = "1" ] || g++ -O2 -std=c++17 -DNO_ITERS -o bench_clean bench.cpp

echo "== Machine info -> $OUT/cpu.txt =="
{
  echo "date: $(date -Is)"; echo "kernel: $(uname -sr)"; g++ --version | head -n 1
  lscpu 2>/dev/null | grep -E "Model name|^CPU\(s\)|Thread|MHz" || true
  free -h 2>/dev/null | head -n 2 || true
  echo "seeds=$SEEDS maxN=$MAXN"
} > "$OUT/cpu.txt"
cat "$OUT/cpu.txt"

echo "== Pass 1: counting build (iterations + latency) =="
S1=$(date +%s)
./bench sweep "$SEEDS" "$MAXN" -o "$OUT/report.txt" -c "$OUT/sweep.csv"
echo "Pass 1 elapsed: $(( $(date +%s)-S1 )) s"

if [ "${SKIP_CLEAN:-0}" != "1" ]; then
  echo "== Pass 2: clean build (latency only) =="
  S2=$(date +%s)
  ./bench_clean sweep "$SEEDS" "$MAXN" -o "$OUT/report_latency.txt" -c "$OUT/sweep_latency.csv"
  echo "Pass 2 elapsed: $(( $(date +%s)-S2 )) s"
fi

echo "== Checking -> $OUT/check.txt =="
check() {  # $1 = csv, $2 = 1 if iteration columns must be filled
awk -F, -v seeds="$SEEDS" -v it="$2" -v f="$1" '
  NR==1 { for(i=1;i<=NF;i++){ if($i=="missingMax") mc=i; if($i=="maxInsIters") xc=i; if($i=="insItersPerOp") ic=i }; next }
  { rows++; sizes[$3]=1
    if($mc+0!=0){ bad++; print "MISSING KEYS in " f " row " NR }
    if(it==1 && $1 ~ /^proposed_d3_K16_s4/ && $xc+0>1616){ over++; print "ITERATION BOUND EXCEEDED row " NR ": " $xc }
    if(it==1 && $ic+0<=0) zero++ }
  END { n=0; for(k in sizes) n++;
    print f ": rows=" rows " distinct N=" n " expected=" n*seeds*7;
    print (bad? "  FAIL: " bad " rows with missingMax != 0" : "  OK: missingMax is 0 in every row");
    if(it==1){ print (over? "  FAIL: " over " rows above the proposed iteration bound 1616" : "  OK: proposed maxInsIters <= 1616 = K(1+D(s+1)) for K=16,s=4,D=20");
               if(zero) print "  WARNING: " zero " rows with no iteration counts (counter-free build?)" }
    if (rows != n*seeds*7) print "  WARNING: row count differs from expected" }' "$1"
}
{ check "$OUT/sweep.csv" 1; [ -f "$OUT/sweep_latency.csv" ] && check "$OUT/sweep_latency.csv" 0 || true; } | tee "$OUT/check.txt"

echo "Done. Send me everything in $OUT/ (sweep.csv, sweep_latency.csv, report*.txt, cpu.txt, check.txt)"
echo "Optional plots: python3 plot_sweep.py $OUT/sweep.csv $OUT/plots"
