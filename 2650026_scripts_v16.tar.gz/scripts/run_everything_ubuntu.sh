#!/usr/bin/env bash
# run_everything_ubuntu.sh -- ONE script: installs everything, runs every run of the paper from start to end on an Ubuntu LTS PC, plots, and packs the results.
# Paper: "Cuckoo Hashing with Bounded Displacement for Exact-Match Flow Tables".  Repository: https://github.com/c43-sar/2650026_CS60101
#
# Usage (inside tmux, so that a closed terminal does not stop it; the script keeps the PC awake with systemd-inhibit):
#   tmux new -s all
#   bash run_everything_ubuntu.sh              all steps in order (asks for the sudo password once at the start)
#   bash run_everything_ubuntu.sh --list       the plan: every step, its class and its estimated hours; nothing is run
#   bash run_everything_ubuntu.sh --only satcomp,sdn_R      only these steps        --from bench_core   start at this step        --skip thp,big   leave these out
#   QUICK=1 bash run_everything_ubuntu.sh      smoke test of the WHOLE pipeline in about an hour (numbers are NOT for the paper; skips the steps that need the whole trace)
#   FORCE=1 ...                                redo steps that are already marked done (a step that finished is never repeated otherwise: re-running the script resumes)
#
# Order of the steps (the order you asked for):
#   0  setup           packages, Mininet, the patched OpenFlow switch, its tests
#   1  red-text runs   satcomp (why p-hat changes with m), hyperfine (local density against load), sdn_slow (the four SDN stages that ran on a slowed machine), sdn_R (R = 0 / 1 / 2), red_report
#   2  data            first 2,000,000 flows of the MAWI trace (keys.bin, flows_400k.txt) and the flow-sampled churn residence times
#   3  Fedora repeat   every run of the paper again: benchmarks (core, stash, real, perf, d-scan), model check, every other SDN stage
#   4  extras          thp (huge-page test), big (N = 10^7), exact whole-trace churn and the SDN churn on its residence times
#   5  finish          extract (CSV / Excel / LaTeX tables), pack
# After EVERY step the script prints: time used by the step, total time so far, and the estimated hours remaining. The estimate starts from the
# durations measured on the Fedora i3 laptop (benchmarks 23 Oct, SDN 24 to 25 Oct 2026; steps never run before are marked "est.") and is multiplied, per class
# of step (bench / sdn / net / sys), by (actual time so far) / (baseline time) of the steps of that class already finished, so it follows this PC's speed.
# SDN steps are mostly wall-clock bound (seconds of traffic per run), so they will not be much faster than on the laptop; bench steps will.
#
# Environment (all optional):  TRACE_FILE=<path to 202610181400.pcap.gz, used instead of the download>  EMPLOYEE_CODE=<code> (work folder $HOME/<code>; or W=<folder>)  QUICK=0  FORCE=0  MEM_LIMIT_MB (memory limit of the exact churn run, default 85 % of free RAM, at most 28000)
#   BIG_N=10000000  BIG_CAP=14400 (seconds)   PIN=<cpu> (pin timed benchmarks; default: first P-core of a hybrid CPU)   SEEDS / other run_all.sh variables are passed through.
# Results (all under $W): adsa/results_full  adsa/results_dscan  adsa/results_big  results_sdn  results_tinycheck  mawi/*  extracted/  red_items_report.txt
#   and, at the end, ubuntu_everything_results.tar.gz  (send that one file; the trace itself is never stored, it is streamed).
# Nothing here is a paper number until it has been read and added to the paper. Latencies of this PC are not comparable with those of the test laptop.
set -uo pipefail
SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"; S="$(dirname "$SELF")"
# ALL files of this run live in ONE folder, ~/<EMPLOYEE CODE>: the work folder W is $HOME/$EMPLOYEE_CODE (set EMPLOYEE_CODE, or W=<folder>, or the script asks once).
# Unpack the scripts inside it too (~/<EMPLOYEE CODE>/scripts). Only the apt packages, which apt itself puts under /usr, /etc and /var, are outside it.
if [ -z "${W:-}" ]; then
  if [[ " $* " == *" --list "* ]]; then EMPLOYEE_CODE="${EMPLOYEE_CODE:-<EMPLOYEE CODE>}"
  elif [ -z "${EMPLOYEE_CODE:-}" ]; then
    if [ -t 0 ]; then read -r -p "Employee code [2650026] (the work folder will be ~/<code>): " EMPLOYEE_CODE; EMPLOYEE_CODE="${EMPLOYEE_CODE:-2650026}"; else echo "set EMPLOYEE_CODE=<your code> (the work folder is ~/<code>)"; exit 1; fi
  fi
  [[ " $* " == *" --list "* ]] || case "$EMPLOYEE_CODE" in ""|*[!A-Za-z0-9._-]*|.|..) echo "the employee code may contain only letters, digits, . _ - (got: '$EMPLOYEE_CODE')"; exit 1;; esac
  W="$HOME/$EMPLOYEE_CODE"; export EMPLOYEE_CODE
fi
export W
if [ -z "${R_INHIBITED:-}" ] && [[ " $* " != *" --list "* ]] && command -v systemd-inhibit >/dev/null 2>&1 && systemd-inhibit --what=sleep:idle true >/dev/null 2>&1; then
  export R_INHIBITED=1; exec systemd-inhibit --what=sleep:idle --who=2650026 --why="long benchmark run" bash "$SELF" "$@"
fi
QUICK="${QUICK:-0}"; FORCE="${FORCE:-0}"; BIG_N="${BIG_N:-10000000}"; BIG_CAP="${BIG_CAP:-14400}"
URL="http://mawi.nezu.wide.ad.jp/mawi/samplepoint-F/2026/202610181400.pcap.gz"
# TRACE_FILE=/path/202610181400.pcap.gz  uses a trace you already have (read in place, nothing is downloaded and nothing is copied); without it the trace is streamed from $URL.
# Or put keys.bin, flows_400k.txt and churn_res_sample8.txt (made by an earlier run) into $W/mawi before starting: step data then finds them and does nothing.
SRC="${TRACE_FILE:-$URL}"
if [ -n "${TRACE_FILE:-}" ] && [[ " $* " != *" --list "* ]] && [ ! -r "$TRACE_FILE" ]; then echo "TRACE_FILE is not a readable file: $TRACE_FILE"; exit 1; fi
ADSA="$W/adsa"; MAWI="$W/mawi"; SDNPKG="$W/sdn_pkg"; OF="$W/openflow"; SDN_OUT="$W/results_sdn"; TC="$W/results_tinycheck"; STATE="$W/state"; LOGS="$W/logs"
mkdir -p "$W" "$ADSA" "$MAWI" "$W/tools" "$STATE" "$LOGS"

# ----------------------------------------------------------------------------------------------------------------- the plan
declare -A CLASS BASE DESC; ORDER=()
step() { ORDER+=("$1"); CLASS[$1]=$2; BASE[$1]=$3; DESC[$1]=$4; }       # name class baseline-minutes description
step setup          sys    20  "packages, Mininet, patched OpenFlow switch, unit and self tests (est.)"
step satcomp        bench   6  "RED: bench satcomp, the sat builds with standard errors and component sizes, for the red p-hat-against-m sentence (est.)"
step hyperfine     bench   5  "RED: bench hyperfine, finer density bins x loads 0.84 / 0.88 / 0.90 / 0.92 with build-resampled intervals, for the red local-density statement (est.)"
step sdn_slow       sdn   165  "RED: SDN stages sweep_cycle, resize, resize_big, reactive again, with the clock-read check (Fedora: 2.7 h)"
step sdn_R          sdn    12  "RED: SDN stage sweep_R, R = 0 / 1 / 2 x K = 4 / 16 x load 0.90 / 0.95 / 0.98 (est.)"
step red_report     sys     1  "RED: summary of satcomp, sweep_R and hyperfine -> red_items_report.txt"
step data           net    60  "MAWI trace streamed: 2,000,000 flows, keys.bin, flows_400k.txt, flow-sampled churn residence times (Fedora: 44 min for the sampled pass)"
step bench_core     bench  15  "benchmarks main ext sweep tail sens sat + plots (Fedora: 14.8 min)"
step bench_stash    bench   7  "benchmarks retrybug rehashclassical rehashcost window hyper merge (Fedora: 6.6 min)"
step bench_real     bench   9  "benchmark real: the same on the real trace keys (Fedora: 8.3 min)"
step bench_perf     bench   6  "benchmark perf: hardware counters of the lookup loop (Fedora: 5.6 min)"
step bench_dscan    bench  36  "benchmark dscan: d = 4 and 5 (Fedora: 35 min)"
step tinycheck      bench  10  "exhaustive model check of tiny tables, six runs incl. the mutant (the paper's run was on Windows; est.)"
step sdn_compare    sdn    70  "SDN compare: 6 backends x 6 loads x 3 topologies x 3 seeds (Fedora: 1.2 h)"
step sdn_sweeps     sdn    66  "SDN sweep_d sweep_K sweep_s sweep_m (Fedora: 1.1 h)"
step sdn_ceil_res   sdn    95  "SDN ceiling_d and resize_d, d = 3 4 5 (Fedora: 1.6 h)"
step sdn_churn      sdn    90  "SDN churn: Poisson arrivals, hard timeouts (Fedora: 1.5 h)"
step sdn_trace      sdn   122  "SDN trace and reactive_trace on real microflows (Fedora: 2.0 h)"
step sdn_trace2     sdn    96  "SDN ceiling_trace and resize_trace on real microflows (Fedora: 1.6 h)"
step sdn_churn_tr   sdn   210  "SDN churn_trace on the flow-sampled residence times (Fedora: 3.5 h)"
step thp            bench  14  "huge-page test: THP never / madvise / madvise+malloc / always (Fedora: 13 min; it reported 0 kB in every mode)"
step big            bench  40  "bench main at N = 10^7 (est.; capped at BIG_CAP seconds)"
step exact_churn    net    75  "exact whole-trace churn model: one entry per flow, streams the whole 6.1 GB trace (est.; needs about 25 GB RAM)"
step sdn_churn_ex   sdn   210  "SDN churn_trace on the exact residence times (tag churn_trace_exact)"
step extract        sys     3  "extract_results.py: one CSV per table, text_values.csv, paper_values.xlsx; SDN plots (est.)"
step pack           sys     2  "pack everything into ubuntu_everything_results.tar.gz (est.)"
QUICK_SKIP=" exact_churn sdn_churn_tr sdn_churn_ex "     # QUICK=1 skips the steps that stream the whole trace

fmt_h() { awk -v m="$1" 'BEGIN{ if(m<0)m=0; t=int(m+0.5); printf "%d h %02d min", int(t/60), t%60 }'; }
list_plan() {
  local tot=0 n b
  printf '%-14s %-6s %9s  %s\n' STEP CLASS "EST. TIME" DESCRIPTION
  for n in "${ORDER[@]}"; do b=${BASE[$n]}; tot=$((tot+b)); printf '%-14s %-6s %9s  %s\n' "$n" "${CLASS[$n]}" "$(fmt_h "$b")" "${DESC[$n]}"; done
  echo "total of the baseline estimates: $(fmt_h "$tot") (a PC faster than the laptop shortens the bench steps only; steps marked est. have no earlier measurement)"
}

ONLY=""; FROM=""; SKIP=""
while [ $# -gt 0 ]; do case "$1" in
  --list) list_plan; exit 0;; --only) ONLY=",$2,"; shift 2;; --from) FROM="$2"; shift 2;; --skip) SKIP=",$2,"; shift 2;;
  -h|--help) sed -n 2,34p "$SELF"; exit 0;; *) echo "unknown argument $1 (try --list)"; exit 2;; esac; done

# ----------------------------------------------------------------------------------------------------------------- helpers
SUDO_KEEP=""
cleanup() { [ -n "$SUDO_KEEP" ] && kill "$SUDO_KEEP" 2>/dev/null; return 0; }
trap cleanup EXIT
MAINPID=$$
keep_sudo() {   # one background refresher for the whole run; it ends when this script ends
  sudo -v || { echo "sudo is needed"; return 1; }
  if [ -e "$STATE/.sudo_keep" ] && kill -0 "$(cat "$STATE/.sudo_keep" 2>/dev/null)" 2>/dev/null; then return 0; fi
  ( while kill -0 "$MAINPID" 2>/dev/null; do sudo -n true 2>/dev/null; sleep 50; done ) >/dev/null 2>&1 & echo $! > "$STATE/.sudo_keep"
}
need_file() { local f; for f in "$@"; do [ -s "$f" ] || { echo "missing or empty: $f"; return 1; }; done; }
mem_limit() { local free; free=$(awk '/MemAvailable/{print int($2/1024*0.85)}' /proc/meminfo); [ "${MEM_LIMIT_MB:-0}" -gt 0 ] 2>/dev/null && { echo "$MEM_LIMIT_MB"; return; }; [ "$free" -gt 28000 ] && free=28000; echo "$free"; }
runall() { ( cd "$ADSA" && env OUT=results_full OUT_QUICK=results_full "$@" ); }          # run_all.sh in $ADSA; QUICK keeps the result folder name
KEYS="$MAWI/keys.bin"
sdn() {   # sdn STAGE...   (env: TRACE_ARG RES_ARG CT_TAG_ARG)
  ( cd "$SDNPKG" && sudo mn -c >/dev/null 2>&1; sudo env OUT="$SDN_OUT" QUICK="$QUICK" TRACE="${TRACE_ARG:-}" RES="${RES_ARG:-}" CT_TAG="${CT_TAG_ARG:-churn_trace}" CHURN_T="${CHURN_T:-15}" \
      bash sdn_sweep.sh "$OF" "$@" ); local rc=$?
  sudo chown -R "$USER": "$SDN_OUT" 2>/dev/null
  [ -s "$SDN_OUT/failures.txt" ] && echo "WARNING: $(wc -l < "$SDN_OUT/failures.txt") failed SDN runs, see $SDN_OUT/failures.txt (re-running this step retries them)"
  return $rc
}
clock_check() {   # clock_check TAG...   median clock-read cost of the switch self-benchmark per stage; about 17 ns on the laptop at normal speed
  python3 -I - "$SDN_OUT/runs" "$@" <<'EOF'
import glob, os, statistics, sys
runs = sys.argv[1]
for tag in sys.argv[2:]:
    v = []
    for f in glob.glob(os.path.join(runs, tag + "_*", "s1.stats")):
        for line in open(f):
            if line.startswith("selfbench_clock_ns="):
                try: v.append(float(line.split("=", 1)[1]))
                except ValueError: pass
    if v:
        m = statistics.median(v)
        print(f"clock-read cost, stage {tag}: median {m:.0f} ns over {len(v)} runs" + ("   <-- WARNING: the machine looked slow during this stage (the laptop's normal value is about 17 ns); its absolute times are inflated" if m > 25 else "   (normal)"))
    else:
        print(f"clock-read cost, stage {tag}: no runs found")
EOF
}

# ----------------------------------------------------------------------------------------------------------------- steps
step_setup() {
  keep_sudo
  sudo apt-get update
  sudo apt-get install -y build-essential g++ git curl wget python3 python3-numpy python3-pandas python3-matplotlib python3-openpyxl autoconf automake libtool \
       libpcap-dev libssl-dev help2man iproute2 iputils-ping net-tools tmux mininet || return 1
  sudo apt-get install -y linux-tools-common linux-tools-generic "linux-tools-$(uname -r)" || echo "WARNING: perf could not be installed for kernel $(uname -r); the perf and thp steps will fail"
  sudo modprobe tun
  cp "$S"/benchmarks/{bench.cpp,run_all.sh,run_sweep.sh,run_thp.sh,perf_summarize.py,plot_sweep.py} "$ADSA"/ || return 1
  cp "$S"/tools/pcap2flows.py "$W/tools/" || return 1
  local pk; pk=$(ls "$S"/sdn_pkg_v*.tar.gz 2>/dev/null | sort -V | tail -n 1); [ -n "$pk" ] || { echo "no sdn_pkg_v*.tar.gz next to this script"; return 1; }
  tar xzf "$pk" -C "$W" || return 1; echo "SDN package: $pk"
  cp -r "$S"/extract_pkg "$S"/tinycheck "$W/" 2>/dev/null
  [ -d "$OF/.git" ] || git clone https://github.com/mininet/openflow.git "$OF" || return 1
  bash "$SDNPKG/patch/apply_patch.sh" "$OF" || return 1
  ( cd "$OF" && ./boot.sh && ./configure CFLAGS="-O2 -g -std=gnu89 -Wno-error -Wno-implicit-function-declaration -Wno-int-conversion -Wno-incompatible-pointer-types" \
      && make -j"$(nproc)" udatapath/ofdatapath secchan/ofprotocol utilities/dpctl ) || return 1
  ls -l "$OF"/udatapath/ofdatapath "$OF"/secchan/ofprotocol "$OF"/utilities/dpctl || return 1
  ( cd "$OF" && gcc -std=gnu99 -O1 -g -fsanitize=address,undefined -DHAVE_CONFIG_H -I. -Iinclude -Ilib -Iudatapath "$SDNPKG/patch/oft_unittest.c" udatapath/table-oft.c lib/list.c -o "$W/tools/oft_ut" \
      && "$W/tools/oft_ut" | tail -n 1 | tee /dev/stderr | grep -q "ALL UNIT TESTS PASSED" ) || { echo "unit test of the table code FAILED"; return 1; }
  ( cd "$SDNPKG" && python3 selftest_of10.py && python3 selftest_harness.py ) || { echo "controller self-tests FAILED"; return 1; }
  ( cd "$SDNPKG" && sudo python3 live_switch_test.py "$OF" proposed 0.9 2048 ) || { echo "live switch test FAILED"; return 1; }
  ( cd "$SDNPKG" && sudo mn -c >/dev/null 2>&1; timeout 3600 sudo python3 selftest_pipeline.py "$OF" ) || echo "NOTE: selftest_pipeline did not finish cleanly (it is a check of the pipeline, not a result)"
  sudo chown -R "$USER": "$SDNPKG"
  { echo "# $(date -Is)"; lsb_release -a 2>/dev/null; uname -r; lscpu | head -25; free -m; g++ --version | head -n 1; python3 --version; } > "$W/sysinfo.txt"
}
step_satcomp()   { runall env QUICK="$QUICK" bash run_all.sh satcomp && need_file "$ADSA/results_full/satcomp.csv"; }
step_hyperfine() { runall env QUICK="$QUICK" bash run_all.sh hyperfine && need_file "$ADSA/results_full/hyperfine_report.txt"; }
step_sdn_slow()  { keep_sudo; sdn sweep_cycle resize resize_big reactive; local rc=$?; clock_check sweep_cycle resize resize_big reactive; return $rc; }
step_sdn_R()     { keep_sudo; sdn sweep_R; local rc=$?; clock_check sweep_R; return $rc; }
step_red_report() {
  python3 -I - "$ADSA/results_full/satcomp.csv" "$SDN_OUT/runs" > "$W/red_items_report.txt" <<'EOF'
import csv, glob, os, re, sys, collections
sat, runs = sys.argv[1], sys.argv[2]
print("RED-TEXT RUNS: summary (read these before editing the paper; nothing here is a paper number yet)\n")
print("1. satcomp: stash routing rate per table size m, with its standard error over the builds (the red sentence says the rate rises with m for MaxKicks <= 16 and not for 64)")
if os.path.exists(sat):
    rows = list(csv.DictReader(open(sat)))
    for a in sorted({r["alpha"] for r in rows}):
        for K in ("4", "16", "64"):
            rs = [r for r in rows if r["alpha"] == a and r["maxKicks"] == K]
            if not rs: continue
            print(f"\n  alpha={float(a):.2f} MaxKicks={K}")
            print("    m        builds  routedFrac  +-SE        compMean   share of slots   compMax")
            for r in rs:
                if int(r["m"]) not in (8, 32, 128, 512, 2048, 8192, 32768, 131072, 262144): continue
                slots = 3 * int(r["m"])
                print(f"    {int(r['m']):<8d} {r['builds']:>6}  {float(r['routedFrac']):.5f}   {float(r['routedFracSE']):.5f}   {float(r['compMean']):9.1f}   {float(r['compMean'])/slots:12.3f}   {r['compMax']:>8}")
    print("\n  How to read: the +-SE column answers whether sampling noise explains the non-monotone rate at MaxKicks = 64 (differences below about two SE are noise), and the rows show where the rate saturates for MaxKicks <= 16.")
    print("  The component a key joins is a large share of all slots and grows in proportion to m (see 'share of slots'), so component size cannot separate m from local structure; the per-bin counts are in satcomp.csv (bin0..bin6) but are confounded with m.")
    print("  This run may therefore not explain WHY the rate rises with m; if it does not, the sentence stays red (cause not explained) and only the noise statement can be made black.")
else:
    print("  satcomp.csv not found")
print("\n2. sweep_R: does the work bound K(1+D(s+1)) hold with R = 0 (reject instead of rebuild)? (one line per R, K, load; max over the seeds)")
g = collections.defaultdict(list)
for d in glob.glob(os.path.join(runs, "sweep_R_*")):
    f = os.path.join(d, "s1.stats")
    if not os.path.exists(f): continue
    st = dict(l.strip().split("=", 1) for l in open(f) if "=" in l)
    m = re.search(r"_a([0-9.]+)_", os.path.basename(d))
    if not m: continue
    g[(int(st["R"]), int(st["K"]), float(m.group(1)))].append(st)
if g:
    print("    R  K   load   runs  bound K(1+D(s+1))  max_ins_rounds  bound held  insert_fail(rejected)  rebuilds  rebuild_fail  guard_trips  stash_overflow")
    allheld = True
    for (R, K, a) in sorted(g):
        L = g[(R, K, a)]; D = int(L[0]["D"]); s = int(L[0]["s"]); bound = K * (1 + D * (s + 1))
        mx = max(int(x["max_ins_rounds"]) for x in L); held = mx <= bound; allheld &= held
        print(f"    {R}  {K:<3d} {a:.2f}  {len(L):4d}  {bound:17d}  {mx:14d}  {'yes' if held else 'NO':>10}  {sum(int(x['insert_fail']) for x in L):21d}  {sum(int(x['rebuilds']) for x in L):8d}  {sum(int(x['rebuild_fail']) for x in L):12d}  {sum(int(x['guard_trips']) for x in L):11d}  {sum(int(x['stash_overflow']) for x in L):14d}")
    print("\n    The bound held in every configuration." if allheld else "\n    The bound was EXCEEDED in at least one configuration: do not write that it holds.")
else:
    print("    no sweep_R runs found")
EOF
  { echo; echo "3. hyperfine: is the stash-routing rate set by the local density and not by the load? (full text: adsa/results_full/hyperfine_report.txt; table: hyperfine_table.tex)"
    if [ -s "$ADSA/results_full/hyperfine_report.txt" ]; then
      grep -E '^===|summary |DIFFERS' "$ADSA/results_full/hyperfine_report.txt" | head -60
      echo "  Reading: 'summary below0.90' / 'summary at_or_above0.90' count the load pairs whose rates in the same density bin are indistinguishable (interval of the difference contains 0). The heuristic ratios (observed / mean density^16) are at the end of the full report."
    else echo "  hyperfine_report.txt not found"; fi; } >> "$W/red_items_report.txt"
  cat "$W/red_items_report.txt"; [ -s "$W/red_items_report.txt" ]
}
step_data() {
  cd "$MAWI" || return 1
  local n=2000000; [ "$QUICK" = 1 ] && n=200000
  if [ "$QUICK" != 1 ] && [ -s keys.bin ] && [ -s flows_400k.txt ] && [ -s churn_res_sample8.txt ]; then
    echo "keys.bin, flows_400k.txt and churn_res_sample8.txt are already in $MAWI: nothing is read or downloaded in this step"; sha256sum keys.bin | tee keys.sha256; return 0
  fi
  if [ -n "${TRACE_FILE:-}" ]; then python3 "$W/tools/pcap2flows.py" "$TRACE_FILE" --out flows.txt --keys keys.bin --max "$n" 2>&1 | tee flows_stats.txt
  else ( set +o pipefail; curl -sS -L "$URL" | python3 "$W/tools/pcap2flows.py" - --out flows.txt --keys keys.bin --max "$n" 2>&1 | tee flows_stats.txt ); fi   # curl may print (23): the early stop
  need_file keys.bin flows.txt || return 1
  sha256sum keys.bin | tee keys.sha256; head -n 400000 flows.txt > flows_400k.txt
  if [ "$QUICK" != 1 ]; then
    python3 "$W/tools/pcap2flows.py" "$SRC" --out /dev/null --churn 5,15,30,60 --flow-sample 8 --mem-limit-mb 8000 --allow-truncated \
        --churn-out churn_sample8.txt --res-out churn_res_sample8.txt 2>&1 | tee whole_stats_sample8.txt
    need_file churn_res_sample8.txt || return 1
  fi
}
step_bench_core()  { runall env QUICK="$QUICK" KEYS="$KEYS" PIN="${PIN:-}" bash run_all.sh info build main ext sweep tail sens sat plots; }
step_bench_stash() { runall env QUICK="$QUICK" PIN="${PIN:-}" bash run_all.sh retrybug rehashclassical rehashcost window hyper merge; }
step_bench_real()  { need_file "$KEYS" || return 1; runall env QUICK="$QUICK" KEYS="$KEYS" PIN="${PIN:-}" bash run_all.sh real; }
step_bench_perf()  { keep_sudo; runall env QUICK="$QUICK" SETUP=1 PIN="${PIN:-}" bash run_all.sh perf; }
step_bench_dscan() { ( cd "$ADSA" && env OUT_QUICK=results_dscan OUT=results_dscan QUICK="$QUICK" PIN="${PIN:-}" bash run_all.sh dscan ); }
step_tinycheck() {
  mkdir -p "$TC"; cd "$W/tinycheck" || return 1
  g++ -O2 -std=c++17 -o tinycheck tinycheck.cpp || return 1
  local out="$TC/tinycheck_results.txt" r
  echo "tinycheck v1  $(date +%Y-%m-%dT%H:%M:%S)  $(hostname)" > "$out"
  for r in "-d 2 -m 2 -s 1 -K 2 -D 2 -u 6" "-d 2 -m 3 -s 1 -K 2 -D 1 -u 7" "-d 3 -m 2 -s 1 -K 1 -D 2 -u 7" "-d 3 -m 2 -s 1 -K 2 -D 1 -u 7" "-d 3 -m 2 -s 2 -K 1 -D 1 -u 8" \
           "-d 2 -m 2 -s 1 -K 2 -D 2 -u 6 --mutant retry-original"; do
    echo "=== $r"; printf '\n### %s\n' "$r" >> "$out"
    # shellcheck disable=SC2086
    ./tinycheck $r 2>&1 | tee -a "$out"; echo "exit code ${PIPESTATUS[0]}" >> "$out"
  done
  grep -c "exit code" "$out"
}
step_sdn_compare()  { keep_sudo; sdn compare; }
step_sdn_sweeps()   { keep_sudo; sdn sweep_d sweep_K sweep_s sweep_m; }
step_sdn_ceil_res() { keep_sudo; sdn ceiling_d resize_d; }
step_sdn_churn()    { keep_sudo; sdn churn; }
step_sdn_trace()    { keep_sudo; need_file "$MAWI/flows_400k.txt" || return 1; TRACE_ARG="$MAWI/flows_400k.txt" sdn trace reactive_trace; }
step_sdn_trace2()   { keep_sudo; need_file "$MAWI/flows_400k.txt" || return 1; TRACE_ARG="$MAWI/flows_400k.txt" sdn ceiling_trace resize_trace; }
step_sdn_churn_tr() { keep_sudo; need_file "$MAWI/flows_400k.txt" "$MAWI/churn_res_sample8.txt" || return 1; TRACE_ARG="$MAWI/flows_400k.txt" RES_ARG="$MAWI/churn_res_sample8.txt" sdn churn_trace; }
step_thp()          { keep_sudo; runall env QUICK="$QUICK" SETUP=1 PIN="${PIN:-}" bash run_all.sh thp; }
step_big()          { ( cd "$ADSA" && env OUT_QUICK=results_big OUT=results_big QUICK="$QUICK" BIG=1 BIG_N="$BIG_N" BIG_CAP="$BIG_CAP" PIN="${PIN:-}" bash run_all.sh big ); }
step_exact_churn()  {
  cd "$MAWI" || return 1
  local lim; lim=$(mem_limit); echo "memory limit for the exact run: $lim MB"
  ( while true; do date -Is; free -m | sed -n 2p; sleep 30; done ) > mem.log 2>&1 & local MEM=$!
  python3 "$W/tools/pcap2flows.py" "$SRC" --out /dev/null --churn 5,15,30,60 --mem-limit-mb "$lim" --allow-truncated --churn-out churn.txt --res-out churn_res.txt 2>&1 | tee whole_stats.txt
  local rc=${PIPESTATUS[0]}; kill "$MEM" 2>/dev/null
  [ "$rc" = 3 ] && echo "memory limit reached: nothing was written. Raise MEM_LIMIT_MB, or keep the flow-sampled result of step data (the paper's choice)."
  return "$rc"
}
step_sdn_churn_ex() { keep_sudo; need_file "$MAWI/flows_400k.txt" "$MAWI/churn_res.txt" || return 1; TRACE_ARG="$MAWI/flows_400k.txt" RES_ARG="$MAWI/churn_res.txt" CT_TAG_ARG=churn_trace_exact sdn churn_trace; }
step_extract() {
  cd "$W/extract_pkg" || return 1
  local args=(--out "$W/extracted") f
  [ -d "$ADSA/results_full" ]  && args+=(--full "$ADSA/results_full")
  [ -d "$ADSA/results_dscan" ] && args+=(--dscan "$ADSA/results_dscan")
  [ -s "$SDN_OUT/results.jsonl" ] && args+=(--sdn "$SDN_OUT")
  [ -s "$TC/tinycheck_results.txt" ] && args+=(--tinycheck "$TC/tinycheck_results.txt")
  local tr=(); for f in flows_stats.txt whole_stats_sample8.txt churn_res_sample8.txt; do [ -s "$MAWI/$f" ] && tr+=("$MAWI/$f"); done
  [ ${#tr[@]} -gt 0 ] && args+=(--trace "${tr[@]}")
  python3 extract_results.py "${args[@]}"; local rc=$?
  [ -s "$SDN_OUT/results.jsonl" ] && ( cd "$SDNPKG" && python3 sdn_plot.py "$SDN_OUT/results.jsonl" "$SDN_OUT/plots" ) || echo "NOTE: SDN plots not made"
  return $rc
}
step_pack() {
  cd "$W" || return 1
  [ -d "$ADSA/results_dscan" ] && tar czf "$ADSA/results_dscan.tar.gz" -C "$ADSA" results_dscan
  [ -d "$ADSA/results_full" ]  && tar czf "$ADSA/results_full.tar.gz"  -C "$ADSA" results_full
  [ -d "$ADSA/results_big" ]   && tar czf "$ADSA/results_big.tar.gz"   -C "$ADSA" results_big
  [ -d "$SDN_OUT" ] && tar czf "$W/sdn_results_all.tar.gz" -C "$W" results_sdn/results.jsonl results_sdn/failures.txt results_sdn/plots $(cd "$W" && ls results_sdn/runs/*/*.stats 2>/dev/null) 2>/dev/null
  local f=() x
  for x in adsa/results_full.tar.gz adsa/results_dscan.tar.gz adsa/results_big.tar.gz sdn_results_all.tar.gz results_tinycheck/tinycheck_results.txt red_items_report.txt sysinfo.txt \
           mawi/flows_stats.txt mawi/whole_stats_sample8.txt mawi/churn_sample8.txt mawi/churn_res_sample8.txt mawi/whole_stats.txt mawi/churn.txt mawi/churn_res.txt mawi/keys.sha256 mawi/mem.log extracted; do
    [ -e "$x" ] && f+=("$x"); done
  [ ${#f[@]} -gt 0 ] || { echo "nothing to pack"; return 1; }
  find "${f[@]}" -type f -print0 | xargs -0 sha256sum > SHA256SUMS
  tar czf ubuntu_everything_results.tar.gz "${f[@]}" SHA256SUMS && ls -l ubuntu_everything_results.tar.gz
  echo "the SDN logs and every step log are in $LOGS"
}

# DRYRUN=1 replaces every step by a short sleep (checks the plan and the time estimate without running anything; DRY_SLEEP seconds per step)
if [ "${DRYRUN:-0}" = 1 ]; then for n in "${ORDER[@]}"; do eval "step_$n() { echo \"dry run of step $n\"; sleep \${DRY_SLEEP:-1}; }"; done; fi
# ----------------------------------------------------------------------------------------------------------------- driver with the time estimate
declare -A FACT_ACT FACT_BAS; DONE_STEPS=(); FAILED_STEPS=(); T_START=$(date +%s); GL_ACT=0; GL_BAS=0
factor() { local c=$1 a=${FACT_ACT[$1]:-0} b=${FACT_BAS[$1]:-0}
  awk -v a="$a" -v b="$b" -v ga="$GL_ACT" -v gb="$GL_BAS" 'BEGIN{ if(b>0) print a/b; else if(gb>0) print ga/gb; else print 1 }'; }
declare -A SEL; FROM_REACHED=0
for n in "${ORDER[@]}"; do   # which steps run: --only / --skip / --from, QUICK skips, and steps already marked done
  SEL[$n]=1
  [ -n "$ONLY" ] && [[ "$ONLY" != *",$n,"* ]] && SEL[$n]=0
  [ -n "$SKIP" ] && [[ "$SKIP" == *",$n,"* ]] && SEL[$n]=0
  [ "$QUICK" = 1 ] && [[ "$QUICK_SKIP" == *" $n "* ]] && SEL[$n]=0
  if [ -n "$FROM" ]; then if [ "$n" = "$FROM" ]; then FROM_REACHED=1; fi; [ "$FROM_REACHED" = 1 ] || SEL[$n]=0; fi
  [ "$FORCE" != 1 ] && [ -e "$STATE/$n.done" ] && SEL[$n]=0
done
selected() { [ "${SEL[$1]:-0}" = 1 ]; }
pending_after() {   # minutes still to do after step $1, with the per-class factors
  local seen=0 tot=0 n f
  for n in "${ORDER[@]}"; do
    if [ "$seen" = 1 ] && selected "$n"; then f=$(factor "${CLASS[$n]}"); tot=$(awk -v t="$tot" -v b="${BASE[$n]}" -v f="$f" 'BEGIN{print t+b*f}'); fi
    [ "$n" = "$1" ] && seen=1
  done; echo "$tot"
}
echo "run_everything_ubuntu.sh   work folder $W   QUICK=$QUICK   $(date -Is)"
[ -n "${TMUX:-}${STY:-}" ] || echo "tip: run this inside tmux (tmux new -s all) so that a closed terminal does not stop it"
TOTAL_PLAN=0; for n in "${ORDER[@]}"; do selected "$n" && TOTAL_PLAN=$((TOTAL_PLAN + BASE[$n])); done
echo "steps to run: $(for n in "${ORDER[@]}"; do selected "$n" && printf '%s ' "$n"; done)"
echo "baseline estimate for the selected steps: $(fmt_h "$TOTAL_PLAN") (it is corrected after every step)"
for n in "${ORDER[@]}"; do
  selected "$n" || continue
  echo; echo "================ step $n [${CLASS[$n]}]  $(date +%H:%M)  ${DESC[$n]}"
  t0=$(date +%s)
  { "step_$n"; } 2>&1 | tee -a "$LOGS/$n.log"; rc=${PIPESTATUS[0]}
  el=$(( $(date +%s) - t0 ))
  [ "${DRYRUN:-0}" = 1 ] && el=$(awk -v b="${BASE[$n]}" -v f="${DRY_SPEED:-1}" 'BEGIN{printf "%d", b*60*f}')   # dry run: pretend the step took DRY_SPEED x its baseline
  if [ "$rc" -eq 0 ]; then touch "$STATE/$n.done"; DONE_STEPS+=("$n"); st=OK; else FAILED_STEPS+=("$n"); st="FAILED (rc=$rc; the step is repeated when you run the script again)"; fi
  FACT_ACT[${CLASS[$n]}]=$(( ${FACT_ACT[${CLASS[$n]}]:-0} + el )); FACT_BAS[${CLASS[$n]}]=$(( ${FACT_BAS[${CLASS[$n]}]:-0} + BASE[$n]*60 ))
  GL_ACT=$(( GL_ACT + el )); GL_BAS=$(( GL_BAS + BASE[$n]*60 ))
  rem=$(pending_after "$n"); now=$(date +%s)
  echo "---------------- step $n: $st in $(fmt_h $((el/60))) | total so far $(fmt_h $(( (now-T_START)/60 ))) | speed vs the laptop baseline for class ${CLASS[$n]}: x$(factor "${CLASS[$n]}")"
  echo "---------------- ESTIMATED REMAINING: $(fmt_h "$rem")  (about $(awk -v r="$rem" 'BEGIN{printf "%.1f", r/60}') hours; expected finish about $(date -d "@$(( now + ${rem%.*}*60 ))" +'%a %d %b %H:%M'))"
done
echo; echo "================ SUMMARY  (total $(fmt_h $(( ($(date +%s)-T_START)/60 ))))"
for n in "${DONE_STEPS[@]}"; do echo "  OK      $n"; done
for n in "${FAILED_STEPS[@]}"; do echo "  FAILED  $n   (log: $LOGS/$n.log)"; done
[ ${#FAILED_STEPS[@]} -eq 0 ] && { echo "all selected steps finished. Send $W/ubuntu_everything_results.tar.gz (made by the pack step) and, if you like, $W/red_items_report.txt"; exit 0; }
echo "run the script again to retry only the failed steps (finished steps are skipped)"; exit 1
