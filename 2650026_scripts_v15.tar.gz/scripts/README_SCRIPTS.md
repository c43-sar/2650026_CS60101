# Scripts of "Cuckoo Hashing with Bounded Displacement for Exact-Match Flow Tables"

| Path | What it does | Used for |
|---|---|---|
| `benchmarks/bench.cpp`, `run_all.sh` (Linux), `run_all.ps1` (Windows), `run_sweep.sh/.ps1`, `perf_summarize.py`, `plot_sweep.py` | all benchmark stages (`main`, `ext`, `sweep`, `tail`, `sens`, `sat`, `perf`, `retrybug`, `rehashclassical`, `rehashcost`, `window`, `hyper`, `merge`, `real`, `dscan`, `big`) | Section VI-A to VI-L (guide 1, part B) |
| `sdn_pkg_v4.tar.gz` | patched OpenFlow 1.0 reference switch, Mininet harness, `sdn_sweep.sh`, `sdn_run.py`, `sdn_plot.py`, `pcap2flows.py` (v6) | Section VI-M (guide 1, parts A, C, D) |
| `tools/pcap2flows.py` | MAWI trace to flow keys, flow-sampled and exact churn model | trace statistics, `keys.bin`, `flows_400k.txt`, residence times |
| `tinycheck/` | exhaustive model check of tiny tables (C++17) and its PowerShell runner | Section VI-K (guide 1, part E) |
| `extract_pkg/extract_results.py` (+ `make_tables_*.py`, `prose_values.py`) | takes the folders of the extracted archives, writes one CSV per table, `text_values.csv` and `paper_values.xlsx` | every table and quoted number (guide 1, part F) |
| `run_everything_ubuntu.sh` | ONE script for an Ubuntu LTS PC: installs everything, runs every run of the paper (red-text runs first, then the runs of the Fedora laptop, then huge pages, N = 10^7 and the exact whole-trace churn), prints the hours remaining after every step, extracts the tables, packs the results | Ubuntu run (`bash run_everything_ubuntu.sh --list` shows the plan) |
| `benchmarks/run_thp.sh` | huge-page test (rewritten: samples the benchmark process itself and the system AnonHugePages) | stage `thp` of `run_all.sh` (opt-in) |
| `run_ubuntu_future.sh` | the deferred runs: exact whole-trace churn and N = 10^7 | future work, not in the paper (guide 2) |
| `guides/` | `RUN_GUIDE_1_fedora_i3_v4.md`, `RUN_GUIDE_2_ubuntu_v4.md` | step by step |

The THP/AnonHugePages test is not in the paper: on the Fedora laptop it showed 0 kB of huge pages in every mode, so it was inconclusive. `run_thp.sh` was rewritten for the Ubuntu run (it now samples the benchmark process itself and `/proc/meminfo`); it is the last benchmark step of `run_everything_ubuntu.sh`. An old `results_full` archive still contains a `thp/` folder; the extraction ignores it.
Repository: https://github.com/c43-sar/2650026_CS60101

## Changes since the previous archive
- `extract_pkg/prose_values.py` now also reads `runs/*/s1.stats` of the SDN directory and writes the lower-load work-bound values (`sdn.lowload.*`), the values of R used (`sdn.R_values`) and the median clock-read cost per stage (`sdn.clock_ns.*`, about 17 ns on a normal machine).
- `guides/RUN_GUIDE_1_fedora_i3_v4.md`, part C2: rerun of the SDN stages `sweep_cycle`, `resize`, `resize_big` and `reactive`, which ran on a slowed machine in the 24 Oct run.

## Changes in this archive (v15)
- `benchmarks/bench.cpp` v5.8: new mode `bench hyperfine [seeds=20] [N=200000]`: the builds and the density statistic of `hyper` (it reproduces the `hyper` bins exactly when the finer bins are merged) at the loads 0.84 / 0.88 / 0.90 / 0.92, one CSV row per (load, build, density bin, component-size bin); nine density bins (steps of 0.05 from 0.75 to 1.00) and four component-size bins.
- `benchmarks/hyperfine_report.py` (new): rates per density bin and load with 95% intervals that resample whole builds, the cross-load comparison of the rates in the same density bin, the split by component size, and the ratio of the observed rate to the mean of min(density,1)^16 (a heuristic, not a result). Writes `hyperfine_report.txt`, `hyperfine_summary.csv`, `hyperfine_table.tex`.
- `benchmarks/run_all.sh`: stage `hyperfine` (in the default run; N = 200000 with 20 builds and N = 10^6 with 10 builds).
- `run_everything_ubuntu.sh`: everything lives in one folder, `~/<EMPLOYEE CODE>` (give `EMPLOYEE_CODE=<code>`, or the script asks once; `W=<folder>` overrides); unpack the scripts in it as `~/<EMPLOYEE CODE>/scripts`. The unit-test binary now goes to that folder instead of `/tmp`. `run_ubuntu_future.sh` and RUN_GUIDE_2 use the same variable.
- `run_everything_ubuntu.sh`: step `hyperfine` (red-text group, about 5 min) and a section 3 in `red_items_report.txt`.

## Changes in the archive before (v14)
- `run_everything_ubuntu.sh` (new): see the table above. Steps resume after a stop (finished steps are marked in `state/`); `--list`, `--only`, `--from`, `--skip`, `QUICK=1` (smoke test of the whole pipeline), `FORCE=1`, `DRYRUN=1` (checks the plan and the time estimate with no run).
- `benchmarks/bench.cpp` v5.7: new mode `bench satcomp` (the `sat` builds with a union-find over the slots: routing rate with its standard error per m, component size at insertion, routing rate per component-size bin). It reproduces `sat` exactly (all 51 rows of one sandbox check). At the loads of `sat` the component a key joins is about half of all slots and grows in proportion to m, so it separates m from local structure only weakly.
- `benchmarks/run_all.sh`: stages `satcomp` (in the default run) and `thp` (opt-in, `THP=1`); `benchmarks/run_thp.sh` (new).
- `sdn_pkg_v5.tar.gz`: stage `sweep_R` (R = 0 / 1 / 2) in `sdn_sweep.sh`.
